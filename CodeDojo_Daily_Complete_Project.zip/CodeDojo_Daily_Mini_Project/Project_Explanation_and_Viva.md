# CodeDojo Daily – Easy Project Explanation

## 1. What is the project?
CodeDojo Daily is a website where students practise one coding challenge at a time, work in small teams and compare team scores.

## 2. How to start it
1. Install Node.js LTS.
2. Open the extracted project folder in VS Code.
3. Open Terminal.
4. Type `npm install` and press Enter.
5. Type `npm start` and press Enter.
6. Open `http://localhost:3000` in Chrome.

## 3. Explain each file
- `server.js`: starts the Express server and handles API requests.
- `public/index.html`: contains the website sections.
- `public/style.css`: controls colours, spacing and responsive layout.
- `public/app.js`: loads problems, creates teams and sends submissions.
- `data/store.json`: stores sample problems, teams and submissions.

## 4. Explain the project flow
The student opens the website. The frontend requests problem data from the backend. The backend reads the JSON file and sends the data to the browser. The student selects a challenge and enters code. The demo submission API returns a result. Teams and scores are shown on the leaderboard.

## 5. Important functions
- `readStore()` reads the JSON database.
- `saveStore()` saves updated information.
- `GET /api/problems` returns coding problems and supports filters.
- `POST /api/teams` creates a team.
- `POST /api/submissions` records a demo submission.
- `GET /api/stats` returns dashboard counts.

## 6. What to say about the test runner
This is a beginner hackathon prototype. It uses a safe mock evaluator to demonstrate the Accepted/Wrong Answer flow. It does not execute arbitrary code. A real application needs a secure isolated execution sandbox.

## 7. Short presentation speech
"Good morning everyone. My project is CodeDojo Daily – DailyDebug Derby. The main aim is to help students maintain daily coding practice and prepare for placements. Students can view coding challenges, filter them by topic and difficulty, write solutions in the browser workspace, create teams and view the team leaderboard. I used HTML, CSS and JavaScript for the frontend, Node.js and Express for the backend, and JSON for data storage. This project encourages consistency, teamwork and problem-solving. Thank you."

## 8. Viva questions and answers
1. What is CodeDojo Daily? — A daily coding challenge and team leaderboard web application.
2. What is the main objective? — To improve coding consistency and encourage teamwork.
3. What is frontend? — The part of a website that users see and interact with.
4. What is backend? — The server-side part that processes requests and manages data.
5. What is Node.js? — A JavaScript runtime used to run JavaScript outside the browser.
6. What is Express? — A Node.js framework used to create web servers and APIs.
7. What is JSON? — A text format used to store and exchange structured data.
8. What is an API? — A way for two software parts to communicate.
9. What is a leaderboard? — A ranking of teams based on their scores.
10. Why use filters? — To find problems by topic or difficulty.
11. What is a test case? — An input with an expected output used to check a solution.
12. Does this prototype execute arbitrary code? — No. It uses a mock evaluator for safe demonstration.
13. How can it be improved? — Add login, a secure code runner, database, AI hints and live contests.
14. What is the use of a team? — Team members practise together and contribute to a shared score.
15. What is the conclusion? — The project makes coding practice more regular and collaborative.
