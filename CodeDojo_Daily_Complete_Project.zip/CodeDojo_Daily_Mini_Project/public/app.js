let selectedProblem = null;
const $ = id => document.getElementById(id);

async function api(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Request failed");
  return data;
}

async function loadProblems() {
  const tag = $("tagFilter").value;
  const difficulty = $("difficultyFilter").value;
  const query = new URLSearchParams();
  if (tag) query.set("tag", tag);
  if (difficulty) query.set("difficulty", difficulty);
  const problems = await api("/api/problems?" + query.toString());
  $("problemList").innerHTML = problems.map(p => `
    <article class="problem" data-id="${p.id}">
      <span class="difficulty">${p.difficulty}</span><span class="tag">#${p.tags[0]}</span>
      <h3>${p.title}</h3><p>${p.statement}</p><small>⭐ ${p.points} points · ${p.tags.join(", ")}</small>
    </article>`).join("") || "<p>No challenges match these filters.</p>";
  document.querySelectorAll(".problem").forEach(card => card.addEventListener("click", () => chooseProblem(Number(card.dataset.id), problems)));
}
function chooseProblem(id, problems) {
  selectedProblem = problems.find(p => p.id === id);
  $("editorTitle").textContent = selectedProblem.title;
  $("problemStatement").textContent = selectedProblem.statement + " Constraints: " + selectedProblem.constraints;
  $("sampleInput").textContent = selectedProblem.input;
  $("sampleOutput").textContent = selectedProblem.output;
  $("result").textContent = "Selected: " + selectedProblem.title + ". Write your solution and run the demo tests.";
  if (id === 1) $("code").value = `function twoSum(nums, target) {\n  const map = new Map();\n  for (let i = 0; i < nums.length; i++) {\n    const need = target - nums[i];\n    if (map.has(need)) return [map.get(need), i];\n    map.set(nums[i], i);\n  }\n}`;
}
async function loadStats() {
  const s = await api("/api/stats");
  $("problemCount").textContent=s.problems; $("teamCount").textContent=s.teams;
  $("submissionCount").textContent=s.submissions; $("acceptedCount").textContent=s.accepted;
}
async function loadTeams() {
  const teams = await api("/api/teams");
  $("teamList").innerHTML = teams.map(t => `<article class="team"><span>${t.avatar}</span><h3>${t.name}</h3><p>${t.members.join(" · ")}</p><b>${t.score} points</b></article>`).join("");
  const sorted = [...teams].sort((a,b)=>b.score-a.score);
  $("leaderboardList").innerHTML = sorted.map((t,i)=>`<div class="rank-row"><span class="rank">#${i+1}</span><b>${t.avatar} ${t.name}</b><span class="score">${t.score} pts</span></div>`).join("");
}
async function runSubmission() {
  if (!selectedProblem) { $("result").textContent = "Please select a challenge first."; return; }
  const code = $("code").value;
  const name = $("studentName").value.trim();
  if (!name || !code.trim()) { $("result").textContent = "Enter your name and solution code."; return; }
  $("result").textContent = "Checking sample test cases...";
  try {
    const result = await api("/api/submissions", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({student:name,problemId:selectedProblem.id,code})});
    $("result").textContent = result.status + " — " + result.passed + "/" + result.total + " demo test cases passed.";
    await loadStats(); await loadTeams();
  } catch (err) { $("result").textContent = err.message; }
}
$("tagFilter").addEventListener("change",loadProblems);
$("difficultyFilter").addEventListener("change",loadProblems);
$("runBtn").addEventListener("click",runSubmission);
$("submitBtn").addEventListener("click",runSubmission);
$("createTeam").addEventListener("click",async()=>{
  const name=$("teamName").value.trim();
  const members=$("teamMembers").value.split(",").map(x=>x.trim()).filter(Boolean);
  try {
    await api("/api/teams",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,members})});
    $("teamName").value=""; $("teamMembers").value=""; await loadTeams(); await loadStats();
  } catch(err) { alert(err.message); }
});
(async()=>{try{await loadProblems();await loadStats();await loadTeams();}catch(e){console.error(e);alert("Could not connect to the server. Start it using npm start.");}})();
