# CodeDojo Daily – DailyDebug Derby

A beginner-friendly mini project based on the supplied problem brief.

## Features
- Daily challenge hub with sample problems
- Filter by algorithmic tag and difficulty
- Browser code workspace with language selector
- Safe mock test-runner result (does not execute arbitrary user code)
- Create teams with 1–4 members
- Team leaderboard and score updates
- Basic daily streak display

## Technology
- Frontend: HTML, CSS and JavaScript
- Backend: Node.js and Express
- Data store: JSON file (`data/store.json`)

This is a simplified learning prototype of the PDF's suggested React/TypeScript, Express and SQLite/JSON architecture. The code runner is intentionally mocked for safety and hackathon demonstration; it is not a secure production execution sandbox.

## How to run
1. Install Node.js (LTS) on your computer.
2. Extract the ZIP file.
3. Open the `CodeDojo_Daily_Mini_Project` folder in VS Code.
4. Open Terminal in VS Code.
5. Run: `npm install`
6. Run: `npm start`
7. Open `http://localhost:3000` in your browser.

## Demo steps
1. View the daily challenge cards.
2. Filter by Arrays or Easy.
3. Select “Two Sum Variant”.
4. Keep the default JavaScript starter solution and click “Run tests”.
5. The demo evaluator returns Accepted (4/4) for the prepared Two Sum sample.
6. Create a team by entering a team name and comma-separated members.
7. View the team leaderboard and observe the score.

## Important implementation note
The evaluator checks for expected identifiers in the submitted text. It does not compile or run JavaScript/Python. A real deployment must use an isolated server-side sandbox or a trusted code-execution service with CPU, memory and time limits. Never use `eval()` or execute untrusted code directly on the server.

## Project structure
- `server.js` – Express API and server
- `public/index.html` – page structure
- `public/style.css` – user interface styling
- `public/app.js` – browser-side logic
- `data/store.json` – sample problems, teams and submissions
