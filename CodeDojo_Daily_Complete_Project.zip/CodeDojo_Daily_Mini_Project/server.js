const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(__dirname, "data", "store.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function readStore() {
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}
function saveStore(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

app.get("/api/problems", (req, res) => {
  const store = readStore();
  let problems = store.problems;
  if (req.query.tag) problems = problems.filter(p => p.tags.includes(req.query.tag));
  if (req.query.difficulty) problems = problems.filter(p => p.difficulty === req.query.difficulty);
  res.json(problems);
});

app.get("/api/teams", (req, res) => res.json(readStore().teams));

app.post("/api/teams", (req, res) => {
  const { name, members } = req.body;
  if (!name || !Array.isArray(members) || members.length < 1 || members.length > 4) {
    return res.status(400).json({ message: "Enter a team name and 1–4 members." });
  }
  const store = readStore();
  const team = { id: Date.now(), name, members, score: 0, avatar: "⚡" };
  store.teams.push(team);
  saveStore(store);
  res.status(201).json(team);
});

app.post("/api/submissions", (req, res) => {
  const { student, problemId, code } = req.body;
  if (!student || !problemId || !code) {
    return res.status(400).json({ message: "Student, problem and code are required." });
  }
  const store = readStore();
  const problem = store.problems.find(p => p.id === Number(problemId));
  if (!problem) return res.status(404).json({ message: "Problem not found." });

  // Safe hackathon prototype: this is a mock evaluator, not an arbitrary code executor.
  // It checks that a submitted solution contains expected starter identifiers.
  const accepted = code.includes("twoSum") && code.includes("target") && code.length > 35;
  const result = {
    id: Date.now(), student, problemId: Number(problemId),
    status: accepted ? "Accepted" : "Wrong Answer",
    passed: accepted ? 4 : 0, total: 4, submittedAt: new Date().toISOString()
  };
  store.submissions.push(result);

  // Award points only for the first accepted submission by a student for a problem.
  const alreadySolved = store.submissions.some(s =>
    s.id !== result.id && s.student.toLowerCase() === student.toLowerCase() &&
    s.problemId === Number(problemId) && s.status === "Accepted"
  );
  if (accepted && !alreadySolved) {
    const team = store.teams.find(t => t.members.some(m => m.toLowerCase() === student.toLowerCase()));
    if (team) team.score += 10;
  }
  saveStore(store);
  res.json(result);
});

app.get("/api/stats", (req, res) => {
  const store = readStore();
  res.json({
    problems: store.problems.length,
    teams: store.teams.length,
    submissions: store.submissions.length,
    accepted: store.submissions.filter(s => s.status === "Accepted").length
  });
});

app.listen(PORT, () => console.log(`CodeDojo Daily running at http://localhost:${PORT}`));
