
const express = require("express");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { spawn } = require("child_process");

const app = express();
const PORT = 3000;

// ==================================
// BASIC SETTINGS
// ==================================

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "store.json");

const ADMIN_USERNAME = "KOUSHIK";

const sessions = new Map();

// ==================================
// DATA MANAGEMENT
// ==================================

function readStore() {
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    if (!fs.existsSync(DATA_FILE)) {
        const initialData = {
            problems: [],
            users: [],
            teams: [],
            submissions: []
        };

        fs.writeFileSync(
            DATA_FILE,
            JSON.stringify(initialData, null, 2)
        );

        return initialData;
    }

    const store = JSON.parse(
        fs.readFileSync(DATA_FILE, "utf8")
    );

    store.problems = Array.isArray(store.problems) ? store.problems : [];
    store.users = Array.isArray(store.users) ? store.users : [];
    store.teams = Array.isArray(store.teams) ? store.teams : [];
    store.submissions = Array.isArray(store.submissions)
        ? store.submissions
        : [];

    return store;
}

function saveStore(store) {
    const tempFile = DATA_FILE + ".tmp";

    fs.writeFileSync(
        tempFile,
        JSON.stringify(store, null, 2)
    );

    fs.renameSync(tempFile, DATA_FILE);
}

// ==================================
// PASSWORD SECURITY
// ==================================

function hashPassword(password, salt) {
    return crypto
        .scryptSync(password, salt, 64)
        .toString("hex");
}

function verifyPassword(password, user) {
    if (!user.salt || !user.passwordHash) {
        return false;
    }

    const hashedPassword = hashPassword(password, user.salt);

    const savedBuffer = Buffer.from(user.passwordHash, "hex");
    const enteredBuffer = Buffer.from(hashedPassword, "hex");

    return (
        savedBuffer.length === enteredBuffer.length &&
        crypto.timingSafeEqual(savedBuffer, enteredBuffer)
    );
}

// ==================================
// AUTHENTICATION MIDDLEWARE
// ==================================

function authenticate(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({
            message: "Please login first"
        });
    }

    const token = authHeader.split(" ")[1];
    const userId = sessions.get(token);

    if (!userId) {
        return res.status(401).json({
            message: "Invalid or expired login session"
        });
    }

    const store = readStore();

    const user = store.users.find(
        item => item.id === userId
    );

    if (!user) {
        sessions.delete(token);

        return res.status(401).json({
            message: "User not found"
        });
    }

    req.user = user;
    req.token = token;

    next();
}

function requireAdmin(req, res, next) {
    if (
        req.user.username.toLowerCase() !==
        ADMIN_USERNAME.toLowerCase()
    ) {
        return res.status(403).json({
            message: "Admin access required"
        });
    }

    next();
}

// ==================================
// REGISTER API
// ==================================

app.post("/api/register", (req, res) => {
    try {
        const { username, password } = req.body;

        if (
            typeof username !== "string" ||
            typeof password !== "string" ||
            username.trim().length < 3 ||
            password.length < 4
        ) {
            return res.status(400).json({
                message: "Username must have 3 characters and password 4 characters"
            });
        }

        const store = readStore();

        const cleanUsername = username.trim();

        const existingUser = store.users.find(
            user =>
                user.username.toLowerCase() ===
                cleanUsername.toLowerCase()
        );

        if (existingUser) {
            return res.status(409).json({
                message: "Username already exists"
            });
        }

        const salt = crypto.randomBytes(16).toString("hex");

        const newUser = {
            id: Date.now().toString(),
            username: cleanUsername,
            salt,
            passwordHash: hashPassword(password, salt),
            createdAt: new Date().toISOString()
        };

        store.users.push(newUser);
        saveStore(store);

        res.status(201).json({
            message: "Registration successful"
        });

    } catch (error) {
        console.error("Register error:", error);

        res.status(500).json({
            message: "Registration failed"
        });
    }
});

// ==================================
// LOGIN API
// ==================================

app.post("/api/login", (req, res) => {
    try {
        const { username, password } = req.body;

        if (
            typeof username !== "string" ||
            typeof password !== "string"
        ) {
            return res.status(400).json({
                message: "Enter username and password"
            });
        }

        const store = readStore();

        const user = store.users.find(
            item =>
                item.username.toLowerCase() ===
                username.trim().toLowerCase()
        );

        if (!user || !verifyPassword(password, user)) {
            return res.status(401).json({
                message: "Invalid username or password"
            });
        }

        const token = crypto.randomBytes(32).toString("hex");

        sessions.set(token, user.id);

        const isAdmin =
            user.username.toLowerCase() ===
            ADMIN_USERNAME.toLowerCase();

        res.json({
            message: "Login successful",
            token,
            user: {
                id: user.id,
                username: user.username,
                isAdmin
            }
        });

    } catch (error) {
        console.error("Login error:", error);

        res.status(500).json({
            message: "Login failed"
        });
    }
});

// ==================================
// CHECK CURRENT USER
// ==================================

app.get("/api/me", authenticate, (req, res) => {
    res.json({
        user: {
            id: req.user.id,
            username: req.user.username,
            createdAt: req.user.createdAt
        },
        isAdmin:
            req.user.username.toLowerCase() ===
            ADMIN_USERNAME.toLowerCase()
    });
});

// ==================================
// LOGOUT API
// ==================================

app.post("/api/logout", authenticate, (req, res) => {
    sessions.delete(req.token);

    res.json({
        message: "Logged out successfully"
    });
});

// ==================================
// GET ALL PROBLEMS
// ==================================

app.get("/api/problems", (req, res) => {
    try {
        const store = readStore();

        res.json({
            problems: store.problems
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            message: "Unable to load problems"
        });
    }
});

// ==================================
// ADMIN - ADD NEW PROBLEM
// ==================================

app.post(
    "/api/problems",
    authenticate,
    requireAdmin,
    (req, res) => {
        try {
            const {
                title,
                description,
                difficulty,
                points
            } = req.body;

            const validDifficulties = [
                "Easy",
                "Medium",
                "Hard"
            ];

            if (
                typeof title !== "string" ||
                !title.trim() ||
                typeof description !== "string" ||
                !description.trim() ||
                !validDifficulties.includes(difficulty) ||
                !Number.isFinite(Number(points)) ||
                Number(points) <= 0
            ) {
                return res.status(400).json({
                    message: "Please enter valid problem details"
                });
            }

            const store = readStore();

            const newProblem = {
                id: Date.now().toString(),
                title: title.trim(),
                description: description.trim(),
                difficulty,
                points: Number(points)
            };

            store.problems.push(newProblem);
            saveStore(store);

            res.status(201).json({
                message: "Problem added successfully",
                problem: newProblem
            });

        } catch (error) {
            console.error("Add problem error:", error);

            res.status(500).json({
                message: "Unable to add problem"
            });
        }
    }
);

// ==================================
// GET ALL TEAMS
// ==================================

app.get("/api/teams", (req, res) => {
    try {
        const store = readStore();

        res.json({
            teams: store.teams
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            message: "Unable to load teams"
        });
    }
});

// ==================================
// CREATE TEAM
// ==================================

app.post("/api/teams", (req, res) => {
    try {
        const { name, members } = req.body;

        if (
            typeof name !== "string" ||
            !name.trim() ||
            !Array.isArray(members) ||
            members.length === 0 ||
            !members.every(member =>
                typeof member === "string" && member.trim()
            )
        ) {
            return res.status(400).json({
                message: "Enter a team name and valid members"
            });
        }

        const store = readStore();

        const newTeam = {
            id: Date.now().toString(),
            name: name.trim(),
            members: members.map(member => member.trim()),
            score: 0
        };

        store.teams.push(newTeam);
        saveStore(store);

        res.status(201).json({
            message: "Team created successfully",
            team: newTeam
        });

    } catch (error) {
        console.error("Team error:", error);

        res.status(500).json({
            message: "Unable to create team"
        });
    }
});

// ==================================
// CODE RUNNER
// ==================================

function runCommand(command, args, cwd, timeout = 5000) {
    return new Promise(resolve => {
        let output = "";
        let finished = false;

        const child = spawn(command, args, {
            cwd,
            windowsHide: true
        });

        const timer = setTimeout(() => {
            if (!finished) {
                child.kill();

                finished = true;

                resolve({
                    output: output + "\nExecution timed out",
                    error: "Time limit exceeded"
                });
            }
        }, timeout);

        child.stdout.on("data", chunk => {
            output += chunk.toString();

            if (output.length > 20000) {
                output = output.slice(0, 20000);
                child.kill();
            }
        });

        child.stderr.on("data", chunk => {
            output += chunk.toString();

            if (output.length > 20000) {
                output = output.slice(0, 20000);
                child.kill();
            }
        });

        child.on("error", error => {
            if (finished) return;

            finished = true;
            clearTimeout(timer);

            resolve({
                output: "",
                error: error.message
            });
        });

        child.on("close", code => {
            if (finished) return;

            finished = true;
            clearTimeout(timer);

            resolve({
                output: output || (
                    code === 0
                        ? "Program executed successfully."
                        : ""
                ),
                error: code === 0 ? "" : output
            });
        });
    });
}

app.post("/api/run", async (req, res) => {
    let tempDir;

    try {
        const { code, language } = req.body;

        if (
            typeof code !== "string" ||
            !code.trim() ||
            typeof language !== "string"
        ) {
            return res.status(400).json({
                message: "Enter code and select a language"
            });
        }

        tempDir = fs.mkdtempSync(
            path.join(os.tmpdir(), "codedojo-")
        );

        let result;

        if (language.toLowerCase() === "javascript") {
            const file = path.join(tempDir, "main.js");

            fs.writeFileSync(file, code);

            result = await runCommand(
                process.execPath,
                [file],
                tempDir
            );

        } else if (language.toLowerCase() === "python") {
            const file = path.join(tempDir, "main.py");

            fs.writeFileSync(file, code);

            result = await runCommand(
                "python",
                ["-I", file],
                tempDir
            );

        } else if (language.toLowerCase() === "c") {
            const file = path.join(tempDir, "main.c");
            const executable = path.join(
                tempDir,
                process.platform === "win32" ? "main.exe" : "main"
            );

            fs.writeFileSync(file, code);

            const compileResult = await runCommand(
                "gcc",
                [file, "-o", executable],
                tempDir
            );

            if (compileResult.error) {
                return res.json({
                    output: compileResult.output,
                    error: compileResult.error
                });
            }

            result = await runCommand(
                executable,
                [],
                tempDir
            );

        } else {
            return res.status(400).json({
                message: "Supported languages: JavaScript, Python, C"
            });
        }

        res.json(result);

    } catch (error) {
        console.error("Code runner error:", error);

        res.status(500).json({
            output: "",
            error: "Code execution failed"
        });

    } finally {
        if (tempDir) {
            try {
                fs.rmSync(tempDir, {
                    recursive: true,
                    force: true
                });
            } catch (error) {
                console.error("Temporary folder cleanup failed:", error);
            }
        }
    }
});

// ==================================
// SUBMIT CODE
// ==================================

app.post("/api/submissions", authenticate, (req, res) => {
    try {
        const {
            code,
            language,
            problemId
        } = req.body;

        if (
            typeof code !== "string" ||
            !code.trim() ||
            typeof language !== "string" ||
            !language.trim()
        ) {
            return res.status(400).json({
                message: "Please enter code and language"
            });
        }

        const store = readStore();

        const problem = store.problems.find(
            item => String(item.id) === String(problemId)
        );

        if (!problem) {
            return res.status(404).json({
                message: "Problem not found"
            });
        }

        // Demo submission status.
        // This does not verify hidden test cases.
        const submission = {
            id: Date.now().toString(),
            userId: req.user.id,
            userName: req.user.username,
            problemId: String(problemId),
            language,
            code,
            status: "Accepted",
            date: new Date().toISOString()
        };

        store.submissions.push(submission);

        // Demo scoring: add points only once per user/problem.
        const alreadyAccepted = store.submissions.some(item =>
            item.id !== submission.id &&
            item.userId === req.user.id &&
            String(item.problemId) === String(problemId) &&
            item.status === "Accepted"
        );

        if (!alreadyAccepted) {
            const team = store.teams.find(item =>
                Array.isArray(item.members) &&
                item.members.some(member =>
                    member.toLowerCase() ===
                    req.user.username.toLowerCase()
                )
            );

            if (team) {
                team.score = Number(team.score || 0) +
                    Number(problem.points || 0);
            }
        }

        saveStore(store);

        res.status(201).json({
            message: "Submission saved successfully",
            submission: {
                id: submission.id,
                problemId: submission.problemId,
                language: submission.language,
                status: submission.status,
                date: submission.date
            }
        });

    } catch (error) {
        console.error("Submission error:", error);

        res.status(500).json({
            message: "Unable to save submission"
        });
    }
});

// ==================================
// PROJECT STATISTICS
// ==================================

app.get("/api/stats", (req, res) => {
    try {
        const store = readStore();

        const accepted = store.submissions.filter(
            item => item.status === "Accepted"
        ).length;

        res.json({
            totalProblems: store.problems.length,
            totalTeams: store.teams.length,
            totalSubmissions: store.submissions.length,
            acceptedSubmissions: accepted
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            message: "Unable to load statistics"
        });
    }
});

// ==================================
// LEADERBOARD
// ==================================

app.get("/api/leaderboard", (req, res) => {
    try {
        const store = readStore();

        const leaderboard = [...store.teams].sort(
            (a, b) => Number(b.score || 0) - Number(a.score || 0)
        );

        res.json({
            leaderboard,
            teams: leaderboard
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            message: "Unable to load leaderboard"
        });
    }
});

// ==================================
// ADMIN DASHBOARD
// ==================================

app.get(
    "/api/admin/dashboard",
    authenticate,
    requireAdmin,
    (req, res) => {
        try {
            const store = readStore();

            const acceptedSubmissions =
                store.submissions.filter(
                    item => item.status === "Accepted"
                ).length;

            const failedSubmissions =
                store.submissions.filter(
                    item => item.status !== "Accepted"
                ).length;

            const users = store.users.map(user => ({
                id: user.id,
                username: user.username,
                createdAt: user.createdAt || ""
            }));

            const teams = store.teams.map(team => ({
                id: team.id,
                name: team.name,
                members: team.members || [],
                score: team.score || 0
            }));

            const submissions = store.submissions.map(item => ({
                id: item.id,
                userName: item.userName || "",
                problemId: item.problemId || "",
                language: item.language || "",
                status: item.status || "",
                date: item.date || ""
            }));

            res.json({
                admin: req.user.username,

                totalUsers: store.users.length,
                totalProblems: store.problems.length,
                totalTeams: store.teams.length,
                totalSubmissions: store.submissions.length,

                acceptedSubmissions,
                failedSubmissions,

                users,
                teams,
                submissions
            });

        } catch (error) {
            console.error("Admin dashboard error:", error);

            res.status(500).json({
                message: "Unable to load admin dashboard"
            });
        }
    }
);

// ==================================
// SERVER ERROR HANDLER
// ==================================

app.use((err, req, res, next) => {
    console.error("Server error:", err);

    res.status(500).json({
        message: "Internal server error"
    });
});

// ==================================
// START SERVER
// ==================================

app.listen(PORT, () => {
    console.log(
        `CodeDojo Daily running at http://localhost:${PORT}`
    );
});
