
// ==========================================
// CODEDOJO DAILY - COMPLETE APP.JS
// ==========================================

const API = "/api";

let authToken = localStorage.getItem("codedojoToken");
let currentUsername = "";
let isAdmin = false;
let allProblems = [];

// ==========================================
// COMMON HELPERS
// ==========================================

function authHeaders() {
    return authToken
        ? { Authorization: `Bearer ${authToken}` }
        : {};
}

async function apiRequest(endpoint, options = {}) {
    const response = await fetch(`${API}${endpoint}`, {
        ...options,
        headers: {
            ...(options.body ? { "Content-Type": "application/json" } : {}),
            ...authHeaders(),
            ...(options.headers || {})
        }
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
        throw new Error(data.message || "Something went wrong");
    }

    return data;
}

function showMessage(id, message, success = false) {
    const box = document.getElementById(id);
    if (!box) return;

    box.textContent = message;
    box.style.color = success ? "green" : "red";
}

function formatDate(dateValue) {
    if (!dateValue) return "Not Available";

    const date = new Date(dateValue);

    if (Number.isNaN(date.getTime())) {
        return "Not Available";
    }

    return date.toLocaleString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
    });
}

function makeElement(tag, text, className = "") {
    const element = document.createElement(tag);

    if (text !== undefined && text !== null) {
        element.textContent = text;
    }

    if (className) {
        element.className = className;
    }

    return element;
}

// ==========================================
// AUTHENTICATION SCREEN
// ==========================================

function updateAuthScreen(username = "", admin = false) {
    currentUsername = username;
    isAdmin = admin;

    const authSection = document.getElementById("authSection");
    const loggedInSection = document.getElementById("loggedInSection");
    const adminNavLink = document.getElementById("adminNavLink");
    const adminDashboard = document.getElementById("adminDashboard");

    if (authSection) {
        authSection.style.display = username ? "none" : "block";
    }

    if (loggedInSection) {
        loggedInSection.style.display = username ? "block" : "none";
    }

    const userBox = document.getElementById("loggedInUser");
    const roleBox = document.getElementById("accountRole");

    if (userBox) userBox.textContent = username || "";
    if (roleBox) roleBox.textContent = admin ? "Administrator" : "Regular User";

    if (adminNavLink) {
        adminNavLink.style.display = admin ? "inline-block" : "none";
    }

    if (adminDashboard && !admin) {
        adminDashboard.style.display = "none";
    }

    updateProfile();
}

// ==========================================
// CHECK LOGIN
// ==========================================

async function checkLogin() {
    if (!authToken) {
        updateAuthScreen();
        return;
    }

    try {
        const data = await apiRequest("/me");

        updateAuthScreen(
            data.user.username,
            data.isAdmin
        );

    } catch (error) {
        localStorage.removeItem("codedojoToken");
        authToken = null;
        updateAuthScreen();
    }
}

// ==========================================
// REGISTER
// ==========================================

const registerForm = document.getElementById("registerForm");

if (registerForm) {
    registerForm.addEventListener("submit", async event => {
        event.preventDefault();

        const username = document
            .getElementById("registerUsername").value.trim();

        const password = document
            .getElementById("registerPassword").value;

        try {
            const data = await apiRequest("/register", {
                method: "POST",
                body: JSON.stringify({ username, password })
            });

            showMessage("authMessage", data.message, true);
            registerForm.reset();

        } catch (error) {
            showMessage("authMessage", error.message);
        }
    });
}

// ==========================================
// LOGIN
// ==========================================

const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", async event => {
        event.preventDefault();

        const username = document
            .getElementById("loginUsername").value.trim();

        const password = document
            .getElementById("loginPassword").value;

        try {
            const data = await apiRequest("/login", {
                method: "POST",
                body: JSON.stringify({ username, password })
            });

            authToken = data.token;
            localStorage.setItem("codedojoToken", authToken);

            updateAuthScreen(
                data.user.username,
                data.user.isAdmin
            );

            loginForm.reset();

            showMessage("authMessage", "Login successful!", true);

            await refreshData();

            if (isAdmin) {
                await loadAdminDashboard();
            }

        } catch (error) {
            showMessage("authMessage", error.message);
        }
    });
}

// ==========================================
// LOGOUT
// ==========================================

const logoutButton = document.getElementById("logoutButton");

if (logoutButton) {
    logoutButton.addEventListener("click", async () => {
        try {
            if (authToken) {
                await apiRequest("/logout", {
                    method: "POST"
                });
            }
        } catch (error) {
            console.error("Logout error:", error);
        }

        localStorage.removeItem("codedojoToken");
        authToken = null;
        currentUsername = "";
        isAdmin = false;

        updateAuthScreen();
        await refreshData();
    });
}

// ==========================================
// PROJECT STATISTICS
// ==========================================

async function loadStats() {
    const box = document.getElementById("stats");
    if (!box) return;

    try {
        const data = await apiRequest("/stats");

        box.innerHTML = "";

        const statistics = [
            ["Total Problems", data.totalProblems ?? 0],
            ["Total Teams", data.totalTeams ?? 0],
            ["Submissions", data.totalSubmissions ?? 0],
            ["Accepted", data.acceptedSubmissions ?? 0]
        ];

        statistics.forEach(([label, value]) => {
            const card = makeElement("div", "", "stat-box");
            card.appendChild(makeElement("h3", value));
            card.appendChild(makeElement("p", label));
            box.appendChild(card);
        });

    } catch (error) {
        box.textContent = "Unable to load statistics.";
        console.error(error);
    }
}

// ==========================================
// LOAD CODING PROBLEMS
// ==========================================

async function loadProblems() {
    const box = document.getElementById("problems");
    const selector = document.getElementById("problemId");

    try {
        const data = await apiRequest("/problems");
        allProblems = data.problems || [];

        if (box) {
            box.innerHTML = "";

            if (allProblems.length === 0) {
                box.textContent = "No coding problems available.";
            }

            allProblems.forEach(problem => {
                const card = makeElement("div", "", "problem-card");

                card.appendChild(makeElement("h3", problem.title));
                card.appendChild(makeElement("p", problem.description));
                card.appendChild(
                    makeElement(
                        "p",
                        `Difficulty: ${problem.difficulty} | Points: ${problem.points}`
                    )
                );

                const selectButton = makeElement(
                    "button",
                    "Solve This Problem"
                );

                selectButton.type = "button";

                selectButton.addEventListener("click", () => {
                    if (selector) {
                        selector.value = String(problem.id);
                    }

                    document.getElementById("codingSection")
                        ?.scrollIntoView({ behavior: "smooth" });
                });

                card.appendChild(selectButton);
                box.appendChild(card);
            });
        }

        if (selector) {
            const previousValue = selector.value;

            selector.innerHTML = "";

            selector.appendChild(
                makeElement("option", "Select a problem")
            );

            selector.options[0].value = "";

            allProblems.forEach(problem => {
                const option = makeElement(
                    "option",
                    `${problem.title} (${problem.difficulty})`
                );

                option.value = String(problem.id);
                selector.appendChild(option);
            });

            if (allProblems.some(
                problem => String(problem.id) === previousValue
            )) {
                selector.value = previousValue;
            }
        }

    } catch (error) {
        if (box) box.textContent = "Unable to load problems.";
        console.error(error);
    }
}

// ==========================================
// TEAMS
// ==========================================

async function loadTeams() {
    const box = document.getElementById("teams");
    if (!box) return;

    try {
        const data = await apiRequest("/teams");
        const teams = data.teams || [];

        box.innerHTML = "";

        if (teams.length === 0) {
            box.textContent = "No teams available.";
            return;
        }

        teams.forEach(team => {
            const card = makeElement("div", "", "team-card");

            card.appendChild(makeElement("h3", team.name));
            card.appendChild(
                makeElement(
                    "p",
                    "Members: " + (team.members || []).join(", ")
                )
            );
            card.appendChild(
                makeElement("p", `Score: ${team.score || 0}`)
            );

            box.appendChild(card);
        });

    } catch (error) {
        box.textContent = "Unable to load teams.";
        console.error(error);
    }
}

// ==========================================
// CREATE TEAM
// ==========================================

const teamForm = document.getElementById("teamForm");

if (teamForm) {
    teamForm.addEventListener("submit", async event => {
        event.preventDefault();

        const name = document.getElementById("teamName").value.trim();

        const members = document
            .getElementById("teamMembers")
            .value
            .split(",")
            .map(member => member.trim())
            .filter(Boolean);

        try {
            const data = await apiRequest("/teams", {
                method: "POST",
                body: JSON.stringify({ name, members })
            });

            showMessage("teamMessage", data.message, true);
            teamForm.reset();

            await refreshData();

        } catch (error) {
            showMessage("teamMessage", error.message);
        }
    });
}

// ==========================================
// LEADERBOARD
// ==========================================

async function loadLeaderboard() {
    const box = document.getElementById("leaderboard");
    if (!box) return;

    try {
        const data = await apiRequest("/leaderboard");
        const teams = data.leaderboard || data.teams || [];

        box.innerHTML = "";

        if (teams.length === 0) {
            box.textContent = "No leaderboard data available.";
            return;
        }

        teams.forEach((team, index) => {
            const item = makeElement(
                "div",
                `${index + 1}. ${team.name} - ${team.score || 0} points`,
                "leaderboard-item"
            );

            box.appendChild(item);
        });

    } catch (error) {
        box.textContent = "Unable to load leaderboard.";
        console.error(error);
    }
}

// ==========================================
// RUN CODE
// ==========================================

async function runCode() {
    const code = document.getElementById("codeEditor")?.value || "";
    const language = document.getElementById("language")?.value || "";
    const output = document.getElementById("output");

    if (!code.trim()) {
        if (output) output.textContent = "Please write your code first.";
        return;
    }

    if (output) output.textContent = "Running code...";

    try {
        const data = await apiRequest("/run", {
            method: "POST",
            body: JSON.stringify({ code, language })
        });

        if (output) {
            output.textContent =
                data.output || data.error || "Program executed successfully.";
        }

    } catch (error) {
        if (output) output.textContent = error.message;
    }
}

document.getElementById("runButton")
    ?.addEventListener("click", runCode);

// ==========================================
// SUBMIT CODE
// ==========================================

document.getElementById("submitButton")
    ?.addEventListener("click", async () => {

        if (!authToken) {
            showMessage(
                "submissionMessage",
                "Please login before submitting."
            );
            return;
        }

        const code = document.getElementById("codeEditor").value;
        const language = document.getElementById("language").value;
        const problemId = document.getElementById("problemId").value;

        if (!problemId) {
            showMessage(
                "submissionMessage",
                "Please select a coding problem."
            );
            return;
        }

        if (!code.trim()) {
            showMessage(
                "submissionMessage",
                "Please write your code first."
            );
            return;
        }

        try {
            const data = await apiRequest("/submissions", {
                method: "POST",
                body: JSON.stringify({
                    code,
                    language,
                    problemId
                })
            });

            showMessage("submissionMessage", data.message, true);

            await refreshData();
            await loadSubmissionHistory();

        } catch (error) {
            showMessage("submissionMessage", error.message);
        }
    });

// ==========================================
// USER PROFILE
// ==========================================

function updateProfile(submissions = []) {
    const usernameBox = document.getElementById("profileUsername");
    const roleBox = document.getElementById("profileRole");
    const countBox = document.getElementById("profileSubmissionCount");
    const acceptedBox = document.getElementById("profileAcceptedCount");

    if (usernameBox) {
        usernameBox.textContent = currentUsername || "Please login";
    }

    if (roleBox) {
        roleBox.textContent = !currentUsername
            ? "Guest"
            : isAdmin ? "Administrator" : "Regular User";
    }

    if (countBox) {
        countBox.textContent = submissions.length;
    }

    if (acceptedBox) {
        acceptedBox.textContent = submissions.filter(
            item => item.status === "Accepted"
        ).length;
    }
}

// ==========================================
// MY SUBMISSION HISTORY
// ==========================================

async function loadSubmissionHistory() {
    const box = document.getElementById("submissionHistory");
    if (!box) return;

    if (!authToken) {
        box.textContent = "Please login to view your submissions.";
        updateProfile();
        return;
    }

    try {
        const data = await apiRequest("/my-submissions");
        const submissions = data.submissions || [];

        updateProfile(submissions);
        box.innerHTML = "";

        if (submissions.length === 0) {
            box.textContent = "You have not submitted any code yet.";
            return;
        }

        const table = document.createElement("table");
        const header = document.createElement("tr");

        ["Problem ID", "Language", "Status", "Date"].forEach(label => {
            header.appendChild(makeElement("th", label));
        });

        table.appendChild(header);

        submissions.forEach(item => {
            const row = document.createElement("tr");

            [
                item.problemId,
                item.language,
                item.status,
                formatDate(item.date)
            ].forEach(value => {
                row.appendChild(makeElement("td", value || "Not Available"));
            });

            table.appendChild(row);
        });

        const wrapper = makeElement("div", "", "table-container");
        wrapper.appendChild(table);
        box.appendChild(wrapper);

    } catch (error) {
        box.textContent = error.message;
        updateProfile();
        console.error("Submission history:", error);
    }
}

// ==========================================
// ADMIN TABLE CREATOR
// ==========================================

function createAdminTable(containerId, columns, rows) {
    const box = document.getElementById(containerId);
    if (!box) return;

    box.innerHTML = "";

    if (!rows || rows.length === 0) {
        box.textContent = "No data available.";
        return;
    }

    const table = document.createElement("table");
    const header = document.createElement("tr");

    columns.forEach(column => {
        header.appendChild(makeElement("th", column.label));
    });

    table.appendChild(header);

    rows.forEach(item => {
        const row = document.createElement("tr");

        columns.forEach(column => {
            let value = item[column.key];

            if (column.key === "createdAt" || column.key === "date") {
                value = formatDate(value);
            }

            if (Array.isArray(value)) {
                value = value.join(", ");
            }

            row.appendChild(
                makeElement("td", value ?? "Not Available")
            );
        });

        table.appendChild(row);
    });

    const wrapper = makeElement("div", "", "table-container");
    wrapper.appendChild(table);
    box.appendChild(wrapper);
}

// ==========================================
// ADMIN DASHBOARD
// ==========================================

async function loadAdminDashboard() {
    const dashboard = document.getElementById("adminDashboard");

    if (!dashboard || !isAdmin) return;

    dashboard.style.display = "block";

    try {
        const data = await apiRequest("/admin/dashboard");

        const values = {
            adminTotalUsers: data.totalUsers,
            adminTotalProblems: data.totalProblems,
            adminTotalTeams: data.totalTeams,
            adminTotalSubmissions: data.totalSubmissions,
            adminAccepted: data.acceptedSubmissions,
            adminFailed: data.failedSubmissions
        };

        Object.entries(values).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) element.textContent = value ?? 0;
        });

        createAdminTable(
            "adminUsers",
            [
                { key: "username", label: "Username" },
                { key: "createdAt", label: "Joined Date" }
            ],
            data.users
        );

        createAdminTable(
            "adminTeams",
            [
                { key: "name", label: "Team Name" },
                { key: "members", label: "Members" },
                { key: "score", label: "Score" }
            ],
            data.teams
        );

        createAdminTable(
            "adminSubmissions",
            [
                { key: "userName", label: "User" },
                { key: "problemId", label: "Problem ID" },
                { key: "language", label: "Language" },
                { key: "status", label: "Status" },
                { key: "date", label: "Date" }
            ],
            data.submissions
        );

        showMessage(
            "adminMessage",
            "Admin dashboard updated successfully!",
            true
        );

    } catch (error) {
        showMessage("adminMessage", error.message);
        console.error(error);
    }
}

// ==========================================
// ADD NEW PROBLEM
// ==========================================

const addProblemForm = document.getElementById("addProblemForm");

if (addProblemForm) {
    addProblemForm.addEventListener("submit", async event => {
        event.preventDefault();

        if (!authToken || !isAdmin) {
            showMessage(
                "addProblemMessage",
                "Only admin can add problems."
            );
            return;
        }

        const title = document
            .getElementById("newProblemTitle").value.trim();

        const description = document
            .getElementById("newProblemDescription").value.trim();

        const difficulty = document
            .getElementById("newProblemDifficulty").value;

        const points = Number(
            document.getElementById("newProblemPoints").value
        );

        if (!title || !description || points <= 0) {
            showMessage(
                "addProblemMessage",
                "Please fill all details correctly."
            );
            return;
        }

        try {
            const data = await apiRequest("/problems", {
                method: "POST",
                body: JSON.stringify({
                    title,
                    description,
                    difficulty,
                    points
                })
            });

            showMessage("addProblemMessage", data.message, true);

            addProblemForm.reset();

            await refreshData();
            await loadAdminDashboard();

        } catch (error) {
            showMessage("addProblemMessage", error.message);
        }
    });
}

// ==========================================
// REFRESH BUTTON
// ==========================================

document.getElementById("refreshAdminButton")
    ?.addEventListener("click", async () => {
        await refreshData();
        await loadAdminDashboard();
    });

// ==========================================
// REFRESH ALL WEBSITE DATA
// ==========================================

async function refreshData() {
    await Promise.all([
        loadStats(),
        loadProblems(),
        loadTeams(),
        loadLeaderboard(),
        loadSubmissionHistory()
    ]);
}

// ==========================================
// START WEBSITE
// ==========================================

async function startWebsite() {
    await checkLogin();
    await refreshData();

    if (isAdmin) {
        await loadAdminDashboard();
    }
}

startWebsite();
