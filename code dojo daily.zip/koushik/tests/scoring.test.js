const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const db = require('../src/database/db');
const { seedDatabase } = require('../src/database/seedData');
const { getProblemBasePoints, calculateUserStreak, getUserScoreAndSolves, getTeamLeaderboard } = require('../src/services/scoringService');

describe('Scoring Logic & Anti-Manipulation Tests', () => {
  before(async () => {
    await db.initDatabase();
    await seedDatabase();
  });

  it('should return correct base points per problem difficulty tier', () => {
    assert.strictEqual(getProblemBasePoints('Easy'), 20);
    assert.strictEqual(getProblemBasePoints('Medium'), 50);
    assert.strictEqual(getProblemBasePoints('Hard'), 100);
  });

  it('should calculate active consecutive day streak for a user', () => {
    // User 1 has seeded consecutive entries in activity_log
    const streak = calculateUserStreak(1);
    assert.ok(streak >= 1, `Expected streak >= 1, got ${streak}`);
  });

  it('should award 0 duplicate points for redundant solved submissions', () => {
    const statsBefore = getUserScoreAndSolves(1);

    // Insert redundant duplicate accepted solve for problem 1
    db.run(
      `INSERT INTO submissions (problem_id, user_id, team_id, language, code, status, execution_time_ms, passed_count, total_count)
       VALUES (1, 1, 1, 'javascript', 'redundant code', 'Accepted', 10.0, 5, 5)`
    );

    const statsAfter = getUserScoreAndSolves(1);
    // Base score should remain strictly unchanged because points are only awarded on distinct first solves!
    assert.strictEqual(statsAfter.baseScore, statsBefore.baseScore);
  });

  it('should compute team leaderboard using formula: sum(MemberScores) * Multiplier + StreakBonus', () => {
    const { leaderboard, activeContest } = getTeamLeaderboard();
    assert.ok(Array.isArray(leaderboard));
    assert.ok(leaderboard.length >= 2);

    const topSquad = leaderboard[0];
    assert.ok(topSquad.rank === 1);
    assert.ok(topSquad.totalScore >= topSquad.sumMemberScores);
    assert.ok(topSquad.memberCount >= 1);
  });
});
