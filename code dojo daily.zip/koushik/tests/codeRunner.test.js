const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { runTestCases, areOutputsEqual, parseInputs } = require('../src/services/codeRunnerService');

describe('Code Runner Service & Sandbox Tests', () => {
  it('should evaluate a correct solution and return Accepted', async () => {
    const code = `
      function twoSum(nums, target) {
        const map = new Map();
        for (let i = 0; i < nums.length; i++) {
          const comp = target - nums[i];
          if (map.has(comp)) return [map.get(comp), i];
          map.set(nums[i], i);
        }
        return [];
      }
    `;

    const testCases = [
      { input: JSON.stringify([[2, 7, 11, 15], 9]), expected_output: JSON.stringify([0, 1]), is_hidden: 0 },
      { input: JSON.stringify([[3, 2, 4], 6]), expected_output: JSON.stringify([1, 2]), is_hidden: 1 }
    ];

    const result = await runTestCases(code, testCases);
    assert.strictEqual(result.verdict, 'Accepted');
    assert.strictEqual(result.passedCount, 2);
    assert.strictEqual(result.totalCount, 2);
    assert.strictEqual(result.testCaseResults.length, 2);
    assert.strictEqual(result.testCaseResults[0].passed, true);
    assert.strictEqual(result.testCaseResults[1].passed, true);
  });

  it('should evaluate an incorrect solution and return Wrong Answer', async () => {
    const code = `
      function twoSum(nums, target) {
        return [0, 0]; // Intentional wrong answer
      }
    `;

    const testCases = [
      { input: JSON.stringify([[2, 7, 11, 15], 9]), expected_output: JSON.stringify([0, 1]), is_hidden: 0 }
    ];

    const result = await runTestCases(code, testCases);
    assert.strictEqual(result.verdict, 'Wrong Answer');
    assert.strictEqual(result.passedCount, 0);
    assert.strictEqual(result.totalCount, 1);
    assert.strictEqual(result.testCaseResults[0].passed, false);
  });

  it('should intercept infinite loops and return Time Limit Exceeded', async () => {
    const code = `
      function infiniteLoop(nums) {
        while (true) {} // Infinite loop trap
      }
    `;

    const testCases = [
      { input: JSON.stringify([[1, 2]]), expected_output: JSON.stringify([1, 2]), is_hidden: 0 }
    ];

    const result = await runTestCases(code, testCases, 500); // 500ms timeout
    assert.strictEqual(result.verdict, 'Time Limit Exceeded');
    assert.strictEqual(result.passedCount, 0);
  });

  it('should intercept runtime exceptions and return Runtime Error', async () => {
    const code = `
      function faulty(nums) {
        return nums.nonExistentMethod();
      }
    `;

    const testCases = [
      { input: JSON.stringify([[1, 2]]), expected_output: JSON.stringify([1, 2]), is_hidden: 0 }
    ];

    const result = await runTestCases(code, testCases);
    assert.strictEqual(result.verdict, 'Runtime Error');
    assert.strictEqual(result.passedCount, 0);
    assert.ok(result.errorMessage.includes('is not a function'));
  });

  it('should block sandbox escapes and security violations', async () => {
    const maliciousCode = `
      function exploit() {
        const fs = require('fs');
        return fs.readdirSync('/');
      }
    `;

    const testCases = [
      { input: JSON.stringify([]), expected_output: JSON.stringify([]), is_hidden: 0 }
    ];

    const result = await runTestCases(maliciousCode, testCases);
    assert.strictEqual(result.verdict, 'Security Violation');
    assert.strictEqual(result.passedCount, 0);
    assert.ok(result.errorMessage.includes('restricted identifier'));
  });

  it('should correctly evaluate deep equality of arrays and numbers', () => {
    assert.strictEqual(areOutputsEqual([1, 2], [1, 2]), true);
    assert.strictEqual(areOutputsEqual(3.141592, 3.14159), true);
    assert.strictEqual(areOutputsEqual(true, true), true);
    assert.strictEqual(areOutputsEqual([1, 2], [1, 3]), false);
  });
});
