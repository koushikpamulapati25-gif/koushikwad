const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');
const app = require('../src/app');
const db = require('../src/database/db');
const { seedDatabase } = require('../src/database/seedData');

describe('Full REST API Integration Tests', () => {
  let authToken = '';

  before(async () => {
    await db.initDatabase();
    await seedDatabase();
  });

  it('POST /api/v1/auth/login - should authenticate demo user and return JWT', async () => {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({ username: 'alex_coder', password: 'Password123!' });

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.success, true);
    assert.ok(res.body.token);
    assert.strictEqual(res.body.user.username, 'alex_coder');
    authToken = res.body.token;
  });

  it('GET /api/v1/problems/daily - should return today curated challenge', async () => {
    const res = await request(app)
      .get('/api/v1/problems/daily')
      .set('Authorization', `Bearer ${authToken}`);

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.success, true);
    assert.ok(res.body.problem);
    assert.ok(res.body.problem.title);
    assert.ok(Array.isArray(res.body.problem.sampleTestCases));
  });

  it('GET /api/v1/problems - should return paginated list of 25+ problems', async () => {
    const res = await request(app)
      .get('/api/v1/problems?page=1&limit=10');

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.success, true);
    assert.strictEqual(res.body.problems.length, 10);
    assert.ok(res.body.pagination.total >= 25);
    assert.ok(res.body.pagination.totalPages >= 3);
  });

  it('GET /api/v1/problems - should filter by difficulty tier', async () => {
    const res = await request(app)
      .get('/api/v1/problems?difficulty=Hard');

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.success, true);
    assert.ok(res.body.problems.every(p => p.difficulty === 'Hard'));
  });

  it('POST /api/v1/submissions/run - should execute sample tests without database record', async () => {
    const solutionCode = `
      function twoSum(nums, target) {
        const map = new Map();
        for (let i = 0; i < nums.length; i++) {
          const comp = target - nums[i];
          if (map.has(comp)) return [map.get(comp), i];
          map.set(nums[i], i);
        }
        return [];
      }
    `;

    const res = await request(app)
      .post('/api/v1/submissions/run')
      .send({
        problemId: 1,
        code: solutionCode,
        language: 'javascript'
      });

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.success, true);
    assert.strictEqual(res.body.result.verdict, 'Accepted');
    assert.ok(res.body.result.passedCount > 0);
  });

  it('POST /api/v1/submissions/submit - should evaluate all test cases and update score', async () => {
    const solutionCode = `
      function twoSum(nums, target) {
        const map = new Map();
        for (let i = 0; i < nums.length; i++) {
          const comp = target - nums[i];
          if (map.has(comp)) return [map.get(comp), i];
          map.set(nums[i], i);
        }
        return [];
      }
    `;

    const res = await request(app)
      .post('/api/v1/submissions/submit')
      .set('Authorization', `Bearer ${authToken}`)
      .send({
        problemId: 1,
        code: solutionCode,
        language: 'javascript'
      });

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.success, true);
    assert.strictEqual(res.body.verdict, 'Accepted');
    assert.strictEqual(res.body.passedCount, 5); // All 5 test cases passed
    assert.strictEqual(res.body.totalCount, 5);
    assert.ok(res.body.submissionId > 0);
  });

  it('GET /api/v1/contests/leaderboard - should return live squad standings', async () => {
    const res = await request(app)
      .get('/api/v1/contests/leaderboard');

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.success, true);
    assert.ok(Array.isArray(res.body.leaderboard));
    assert.ok(res.body.leaderboard.length >= 2);
  });

  it('GET /api/v1/contests/active - should return live 60-min sprint details', async () => {
    const res = await request(app)
      .get('/api/v1/contests/active');

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.success, true);
    assert.strictEqual(res.body.hasActiveContest, true);
    assert.ok(res.body.contest.remainingSeconds > 0);
    assert.strictEqual(res.body.contest.multiplier, 1.5);
  });

  it('GET /api/v1/plagiarism/check - should analyze submission similarity', async () => {
    const res = await request(app)
      .get('/api/v1/plagiarism/check');

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.success, true);
    assert.ok(res.body.data.totalCompared !== undefined);
  });

  it('GET /api/v1/hints/1 - should return progressive non-spoiler clues', async () => {
    const res = await request(app)
      .get('/api/v1/hints/1')
      .set('Authorization', `Bearer ${authToken}`);

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.success, true);
    assert.ok(Array.isArray(res.body.data.hints));
    assert.strictEqual(res.body.data.hints.length, 3);
  });
});
