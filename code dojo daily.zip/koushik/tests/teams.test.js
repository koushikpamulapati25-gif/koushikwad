const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const db = require('../src/database/db');
const { seedDatabase } = require('../src/database/seedData');
const config = require('../src/config');

describe('Team & Squad Roster Rules', () => {
  before(async () => {
    await db.initDatabase();
    await seedDatabase();
  });

  it('should enforce maximum squad roster limit of 4 members', () => {
    // Find squad 1 (Binary Beasts) which has 3 members initially
    const countRow = db.get('SELECT COUNT(*) as count FROM team_members WHERE team_id = 1');
    assert.strictEqual(countRow.count, 3);

    // Add 4th member (user 6 - demo_user)
    db.run('INSERT INTO team_members (team_id, user_id, role) VALUES (1, 6, "member")');
    const updatedCount = db.get('SELECT COUNT(*) as count FROM team_members WHERE team_id = 1').count;
    assert.strictEqual(updatedCount, 4);

    // Verify limit constraint check
    const isAtCapacity = updatedCount >= config.TEAM_MAX_MEMBERS;
    assert.strictEqual(isAtCapacity, true);

    // Cleanup: remove 4th member
    db.run('DELETE FROM team_members WHERE team_id = 1 AND user_id = 6');
  });

  it('should guarantee uniqueness of squad invite codes', () => {
    const teams = db.all('SELECT invite_code FROM teams');
    const codes = teams.map(t => t.invite_code);
    const uniqueCodes = new Set(codes);
    assert.strictEqual(uniqueCodes.size, codes.length);
  });
});
