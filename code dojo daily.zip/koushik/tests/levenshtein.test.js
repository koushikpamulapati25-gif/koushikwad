const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { computeLevenshteinDistance, calculateSimilarity, normalizeCode } = require('../src/utils/levenshtein');

describe('Levenshtein Plagiarism Distance Tests', () => {
  it('should compute exact 100% similarity for identical code', () => {
    const code = 'function twoSum(nums, target) { return [0, 1]; }';
    const similarity = calculateSimilarity(code, code);
    assert.strictEqual(similarity, 100);
  });

  it('should normalize variable names, comments, and whitespace differences', () => {
    const codeA = `
      // Student A implementation
      function twoSum(nums, target) {
        /* Hash map lookup */
        const map = new Map();
        for (let i = 0; i < nums.length; i++) {
          const comp = target - nums[i];
          if (map.has(comp)) return [map.get(comp), i];
          map.set(nums[i], i);
        }
        return [];
      }
    `;

    const codeB = `
      function twoSum(nums, target) {
        const map = new Map();
        for (let i = 0; i < nums.length; i++) {
          const comp = target - nums[i];
          if (map.has(comp)) return [map.get(comp), i];
          map.set(nums[i], i);
        }
        return [];
      }
    `;

    const similarity = calculateSimilarity(codeA, codeB);
    assert.ok(similarity >= 95, `Expected >= 95%, got ${similarity}%`);
  });

  it('should compute low similarity for completely distinct algorithms', () => {
    const code1 = `
      function twoSum(nums, target) {
        return [0, 1];
      }
    `;

    const code2 = `
      function reverseString(s) {
        let left = 0, right = s.length - 1;
        while (left < right) {
          let t = s[left];
          s[left++] = s[right];
          s[right--] = t;
        }
        return s;
      }
    `;

    const similarity = calculateSimilarity(code1, code2);
    assert.ok(similarity < 40, `Expected < 40%, got ${similarity}%`);
  });

  it('should compute correct raw Levenshtein edit distance matrix', () => {
    assert.strictEqual(computeLevenshteinDistance('kitten', 'sitting'), 3);
    assert.strictEqual(computeLevenshteinDistance('flaw', 'lawn'), 2);
    assert.strictEqual(computeLevenshteinDistance('', 'hello'), 5);
  });
});
