/**
 * In-Browser Code Workspace & Test Runner Manager
 */

const Editor = {
  editorEl: null,
  lineNumbersEl: null,
  webWorker: null,

  init() {
    this.editorEl = document.getElementById('code-editor');
    this.lineNumbersEl = document.getElementById('editor-line-numbers');

    if (!this.editorEl) return;

    // Line number syncing and auto-indent
    this.editorEl.addEventListener('input', () => this.updateLineNumbers());
    this.editorEl.addEventListener('scroll', () => {
      this.lineNumbersEl.scrollTop = this.editorEl.scrollTop;
    });

    // Handle Tab key for 2-space indentation
    this.editorEl.addEventListener('keydown', (e) => {
      if (e.key === 'Tab') {
        e.preventDefault();
        const start = this.editorEl.selectionStart;
        const end = this.editorEl.selectionEnd;
        this.editorEl.value = this.editorEl.value.substring(0, start) + '  ' + this.editorEl.value.substring(end);
        this.editorEl.selectionStart = this.editorEl.selectionEnd = start + 2;
        this.updateLineNumbers();
      }
    });

    // Language switcher
    const langSelect = document.getElementById('editor-language');
    if (langSelect) {
      langSelect.addEventListener('change', () => this.handleLanguageChange());
    }

    // Reset code button
    const btnReset = document.getElementById('btn-reset-code');
    if (btnReset) {
      btnReset.addEventListener('click', () => this.resetStarterCode());
    }

    // Run sample tests button
    const btnRun = document.getElementById('btn-run-tests');
    if (btnRun) {
      btnRun.addEventListener('click', () => this.runSampleTests());
    }

    // Submit solution button
    const btnSubmit = document.getElementById('btn-submit-code');
    if (btnSubmit) {
      btnSubmit.addEventListener('click', () => this.submitSolution());
    }

    // Hint button
    const btnHint = document.getElementById('btn-request-hint');
    if (btnHint) {
      btnHint.addEventListener('click', () => this.openHintsModal());
    }

    // State listener
    State.on('problem:changed', (problem) => this.renderProblem(problem));
  },

  updateLineNumbers() {
    if (!this.editorEl || !this.lineNumbersEl) return;
    const lines = this.editorEl.value.split('\n').length;
    let numbers = '';
    for (let i = 1; i <= Math.max(lines, 1); i++) {
      numbers += i + '\n';
    }
    this.lineNumbersEl.textContent = numbers;
  },

  renderProblem(problem) {
    if (!problem) return;

    document.getElementById('ws-problem-title').textContent = problem.title;
    document.getElementById('ws-problem-description').textContent = problem.description;

    const diffBadge = document.getElementById('ws-difficulty');
    diffBadge.textContent = problem.difficulty;
    diffBadge.className = `badge badge-${problem.difficulty.toLowerCase()}`;

    document.getElementById('ws-domain').textContent = problem.domain_tag;

    let pts = 20;
    if (problem.difficulty === 'Medium') pts = 50;
    if (problem.difficulty === 'Hard') pts = 100;
    document.getElementById('ws-points').textContent = `${pts} pts`;

    // Examples
    const examplesContainer = document.getElementById('ws-examples-list');
    examplesContainer.innerHTML = '';
    (problem.examples || []).forEach((ex, idx) => {
      const box = document.createElement('div');
      box.className = 'example-box';
      box.innerHTML = `<strong>Example ${idx + 1}:</strong>
<pre>Input: ${ex.input}
Output: ${ex.output}${ex.explanation ? `\nExplanation: ${ex.explanation}` : ''}</pre>`;
      examplesContainer.appendChild(box);
    });

    // Constraints
    const constraintsList = document.getElementById('ws-constraints-list');
    constraintsList.innerHTML = '';
    (problem.constraints || []).forEach(c => {
      const li = document.createElement('li');
      li.textContent = c;
      constraintsList.appendChild(li);
    });

    // Populate initial starter code
    this.handleLanguageChange();

    // Populate initial test cases tabs
    this.renderTestCaseTabs(problem.sampleTestCases || []);
  },

  handleLanguageChange() {
    const lang = document.getElementById('editor-language').value;
    const starter = State.currentProblem?.starterCode || {};
    this.editorEl.value = starter[lang] || `// Write your ${lang} solution here...`;
    this.updateLineNumbers();
  },

  resetStarterCode() {
    if (confirm('Reset editor to original starter code?')) {
      this.handleLanguageChange();
    }
  },

  renderTestCaseTabs(testCases, results = null) {
    const tabsContainer = document.getElementById('testcase-tab-buttons');
    tabsContainer.innerHTML = '';

    const list = results ? results.testCaseResults : testCases;
    if (!list || !list.length) return;

    list.forEach((tc, idx) => {
      const btn = document.createElement('button');
      btn.className = `tc-tab-btn ${idx === State.selectedTestCaseIndex ? 'active' : ''}`;

      if (results && tc) {
        btn.classList.add(tc.passed ? 'passed' : 'failed');
        btn.innerHTML = `${tc.passed ? '✓' : '✗'} Case ${idx + 1}`;
      } else {
        btn.textContent = `Case ${idx + 1}`;
      }

      btn.addEventListener('click', () => {
        State.selectedTestCaseIndex = idx;
        this.selectTestCase(idx, list);
        this.renderTestCaseTabs(testCases, results);
      });

      tabsContainer.appendChild(btn);
    });

    this.selectTestCase(State.selectedTestCaseIndex, list);
  },

  selectTestCase(index, list) {
    if (!list || !list[index]) return;
    const tc = list[index];

    document.getElementById('tc-input').textContent = tc.input || '--';
    document.getElementById('tc-expected').textContent = typeof tc.expected === 'object' ? JSON.stringify(tc.expected) : (tc.expected || tc.expected_output || '--');
    document.getElementById('tc-actual').textContent = tc.actual !== undefined ? (typeof tc.actual === 'object' ? JSON.stringify(tc.actual) : tc.actual) : 'Not evaluated yet';
    document.getElementById('tc-execution-time').textContent = tc.executionTimeMs !== undefined ? `Execution Time: ${tc.executionTimeMs} ms` : 'Execution Time: -- ms';
  },

  setVerdictBanner(verdict, passedCount, totalCount) {
    const banner = document.getElementById('verdict-tag');
    banner.className = 'results-verdict-tag';

    if (verdict === 'Accepted') {
      banner.classList.add('accepted');
      banner.textContent = `✓ Accepted (${passedCount}/${totalCount} Passed)`;
    } else {
      banner.classList.add(verdict.toLowerCase().replace(/\s+/g, '-'));
      banner.textContent = `✗ ${verdict} (${passedCount}/${totalCount} Passed)`;
    }
  },

  async runSampleTests() {
    if (!State.currentProblem) return;
    const code = this.editorEl.value;
    const lang = document.getElementById('editor-language').value;
    const useClientWorker = document.getElementById('toggle-client-runner').checked;

    const banner = document.getElementById('verdict-tag');
    banner.textContent = 'Executing Tests...';
    banner.className = 'results-verdict-tag';

    try {
      let result;
      if (useClientWorker && lang === 'javascript') {
        // Run in sandboxed Web Worker
        result = await this.executeInWebWorker(code, State.currentProblem.sampleTestCases);
        showToast('Executed locally via Sandboxed Web Worker!', 'info');
      } else {
        // Run via backend isolated VM
        const res = await API.runSampleTests(State.currentProblem.id, code, lang);
        result = res.result;
      }

      State.currentTestResults = result;
      this.setVerdictBanner(result.verdict, result.passedCount, result.totalCount);
      this.renderTestCaseTabs(null, result);

      if (result.verdict === 'Accepted') {
        showToast('All sample test cases passed! Submit solution to verify hidden cases.', 'success');
      } else {
        showToast(`Sample run verdict: ${result.verdict}`, 'error');
      }
    } catch (err) {
      banner.textContent = 'Execution Failed';
      showToast(err.message || 'Execution error', 'error');
    }
  },

  executeInWebWorker(code, testCases) {
    return new Promise((resolve) => {
      if (this.webWorker) this.webWorker.terminate();
      this.webWorker = new Worker('js/worker.js');

      const timeoutId = setTimeout(() => {
        this.webWorker.terminate();
        resolve({
          verdict: 'Time Limit Exceeded',
          passedCount: 0,
          totalCount: testCases.length,
          totalExecutionTimeMs: 2500,
          errorMessage: 'Web Worker execution timed out (Infinite loop protection).',
          testCaseResults: []
        });
      }, 3000);

      this.webWorker.onmessage = (e) => {
        clearTimeout(timeoutId);
        resolve(e.data);
      };

      this.webWorker.postMessage({ code, testCases, timeoutMs: 2500 });
    });
  },

  async submitSolution() {
    if (!State.currentUser) {
      showToast('Please sign in to submit code and earn team score!', 'error');
      openAuthModal();
      return;
    }

    if (!State.currentProblem) return;
    const code = this.editorEl.value;
    const lang = document.getElementById('editor-language').value;

    const banner = document.getElementById('verdict-tag');
    banner.textContent = 'Submitting & Evaluating against All Test Cases...';
    banner.className = 'results-verdict-tag';

    try {
      const res = await API.submitSolution(State.currentProblem.id, code, lang);
      this.setVerdictBanner(res.verdict, res.passedCount, res.totalCount);
      this.renderTestCaseTabs(null, res);

      if (res.verdict === 'Accepted') {
        if (res.scoring.isFirstAcceptedSolve) {
          showToast(`🎉 Accepted! Earned +${res.scoring.pointsAwarded} points for your squad!`, 'success');
        } else {
          showToast('✓ Accepted! (Subsequent solve - streak updated, no duplicate points awarded)', 'info');
        }
        // Refresh leaderboard & profile
        Leaderboard.load();
        refreshUserProfile();
      } else {
        showToast(`Submission Verdict: ${res.verdict} (${res.passedCount}/${res.totalCount} test cases passed)`, 'error');
      }
    } catch (err) {
      banner.textContent = 'Submission Failed';
      showToast(err.message || 'Submission error', 'error');
    }
  },

  async openHintsModal() {
    if (!State.currentProblem) return;
    const modal = document.getElementById('hint-modal');
    const accordion = document.getElementById('hints-accordion');
    accordion.innerHTML = 'Loading AI clues...';
    modal.classList.remove('hidden');

    try {
      const res = await API.getProblemHints(State.currentProblem.id);
      accordion.innerHTML = '';

      if (!res.data.hints || !res.data.hints.length) {
        accordion.innerHTML = '<p>No hints available for this problem.</p>';
        return;
      }

      res.data.hints.forEach(h => {
        const item = document.createElement('div');
        item.className = 'hint-item';
        item.innerHTML = `
          <div class="hint-header">
            <strong>Level ${h.level}: ${h.title}</strong>
            <span class="badge ${h.unlocked ? 'badge-success' : 'badge-neutral'}">
              ${h.unlocked ? 'Unlocked' : 'Locked'}
            </span>
          </div>
          <div class="hint-content">
            ${h.unlocked ? `<p>${h.text}</p>` : `<p class="text-dim">🔒 ${h.reason}</p>`}
          </div>
        `;
        accordion.appendChild(item);
      });
    } catch (err) {
      accordion.innerHTML = `<p class="text-danger">Failed to load hints: ${err.message}</p>`;
    }
  }
};
