/**
 * Plagiarism & Levenshtein Similarity Inspector
 */

const Plagiarism = {
  init() {
    this.bindEvents();
  },

  bindEvents() {
    const btnInspect = document.getElementById('btn-run-plagiarism-check');
    if (btnInspect) {
      btnInspect.addEventListener('click', () => this.runCheck());
    }
  },

  async runCheck() {
    const select = document.getElementById('plagiarism-problem-filter');
    const problemId = select ? select.value : '';
    const tbody = document.getElementById('plagiarism-table-body');

    tbody.innerHTML = '<tr><td colspan="5" class="text-center">Analyzing code token similarity across submissions...</td></tr>';

    try {
      const res = await API.checkPlagiarism(problemId || null, 60);
      const data = res.data;

      document.getElementById('plag-total-compared').textContent = data.totalCompared;
      document.getElementById('plag-flagged-count').textContent = data.flaggedCount;

      if (!data.comparisons || !data.comparisons.length) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center">No comparable accepted submissions found.</td></tr>';
        return;
      }

      tbody.innerHTML = '';
      data.comparisons.forEach(c => {
        let badgeClass = 'badge-neutral';
        if (c.similarityPercentage >= 85) badgeClass = 'badge-hard';
        else if (c.similarityPercentage >= 70) badgeClass = 'badge-accent';
        else if (c.similarityPercentage >= 50) badgeClass = 'badge-secondary';

        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td><strong>${c.problemTitle}</strong></td>
          <td>
            ${c.submissionA.username} 
            <span class="badge badge-neutral" style="font-size: 0.65rem;">${c.submissionA.teamName}</span>
          </td>
          <td>
            ${c.submissionB.username} 
            <span class="badge badge-neutral" style="font-size: 0.65rem;">${c.submissionB.teamName}</span>
          </td>
          <td>
            <span class="badge ${badgeClass}" style="font-family: var(--font-mono); font-size: 0.85rem;">
              ${c.similarityPercentage}% Match
            </span>
          </td>
          <td>
            <span style="font-weight: 600; color: ${c.flagged ? '#ef4444' : '#10b981'};">
              ${c.status}
            </span>
          </td>
        `;
        tbody.appendChild(tr);
      });

      showToast(`Plagiarism analysis complete: ${data.totalCompared} pairs compared, ${data.flaggedCount} flagged.`, 'info');
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="5" class="text-center text-danger">Analysis failed: ${err.message}</td></tr>`;
    }
  }
};
