/**
 * Client-Side Sandboxed Web Worker Code Runner
 * Executes user JavaScript code in an isolated Worker thread.
 */

self.onmessage = function (e) {
  const { code, testCases, timeoutMs = 2500 } = e.data;

  // Extract function name
  const fnMatch = code.match(/function\s+([a-zA-Z0-9_$]+)\s*\(/) || 
                  code.match(/(?:const|let|var)\s+([a-zA-Z0-9_$]+)\s*=\s*(?:\([^)]*\)|[a-zA-Z0-9_$]+)\s*=>/);

  if (!fnMatch) {
    self.postMessage({
      verdict: 'Compilation Error',
      passedCount: 0,
      totalCount: testCases.length,
      totalExecutionTimeMs: 0,
      errorMessage: 'Could not detect a valid entry function in your solution.',
      testCaseResults: []
    });
    return;
  }

  const fnName = fnMatch[1];
  let passedCount = 0;
  let totalTime = 0;
  let overallVerdict = 'Accepted';
  let firstError = null;
  const results = [];

  for (let i = 0; i < testCases.length; i++) {
    const tc = testCases[i];
    let args;
    try {
      const p = JSON.parse(tc.input);
      args = Array.isArray(p) ? p : [p];
    } catch {
      args = [tc.input];
    }

    let expected;
    try {
      expected = JSON.parse(tc.expected_output);
    } catch {
      expected = tc.expected_output;
    }

    const startTime = performance.now();
    let actual;
    let tcPassed = false;
    let tcError = null;

    try {
      // Evaluate function in worker scope
      const runner = new Function(
        'code',
        'fnName',
        'args',
        `
        ${code}
        return ${fnName}(...args);
        `
      );
      actual = runner(code, fnName, args);

      // Deep compare
      const actStr = JSON.stringify(actual);
      const expStr = JSON.stringify(expected);
      tcPassed = (actStr === expStr) || (typeof actual === 'number' && typeof expected === 'number' && Math.abs(actual - expected) < 1e-5);

      if (!tcPassed && overallVerdict === 'Accepted') {
        overallVerdict = 'Wrong Answer';
      }
    } catch (err) {
      tcError = err.message || String(err);
      if (overallVerdict === 'Accepted') {
        overallVerdict = 'Runtime Error';
      }
      if (!firstError) firstError = tcError;
    }

    const elapsed = performance.now() - startTime;
    totalTime += elapsed;
    if (tcPassed) passedCount++;

    results.push({
      testCaseIndex: i + 1,
      input: tc.is_hidden ? '[Hidden Test Case]' : tc.input,
      expected: tc.is_hidden ? '[Hidden Test Case]' : expected,
      actual: tc.is_hidden ? (tcPassed ? '[Hidden Passed]' : '[Hidden Failed]') : (tcError || actual),
      passed: tcPassed,
      isHidden: !!tc.is_hidden,
      executionTimeMs: Math.round(elapsed * 100) / 100,
      errorMessage: tcError
    });
  }

  self.postMessage({
    verdict: passedCount === testCases.length ? 'Accepted' : overallVerdict,
    passedCount,
    totalCount: testCases.length,
    totalExecutionTimeMs: Math.round(totalTime * 100) / 100,
    errorMessage: firstError,
    testCaseResults: results,
    isClientWorker: true
  });
};
