/**
 * Global Frontend Reactive State
 */

const State = {
  currentUser: null,
  currentProblem: null,
  activeContest: null,
  problemsCache: [],
  selectedTestCaseIndex: 0,
  currentTestResults: null,
  listeners: {},

  on(event, callback) {
    if (!this.listeners[event]) this.listeners[event] = [];
    this.listeners[event].push(callback);
  },

  emit(event, data) {
    if (this.listeners[event]) {
      this.listeners[event].forEach(cb => cb(data));
    }
  },

  setUser(user) {
    this.currentUser = user;
    this.emit('user:changed', user);
  },

  setProblem(problem) {
    this.currentProblem = problem;
    this.selectedTestCaseIndex = 0;
    this.currentTestResults = null;
    this.emit('problem:changed', problem);
  },

  setContest(contest) {
    this.activeContest = contest;
    this.emit('contest:changed', contest);
  }
};
