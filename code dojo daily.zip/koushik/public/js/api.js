/**
 * Central API Client for CodeDojo Daily
 */

const API = {
  baseUrl: '/api/v1',

  getToken() {
    return localStorage.getItem('codedojo_token');
  },

  setToken(token) {
    if (token) localStorage.setItem('codedojo_token', token);
    else localStorage.removeItem('codedojo_token');
  },

  async request(endpoint, options = {}) {
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers
    };

    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers
    });

    const data = await response.json();
    if (!response.ok) {
      const err = new Error(data.error || 'API Request Failed');
      err.status = response.status;
      err.data = data;
      throw err;
    }

    return data;
  },

  // Auth
  login: (username, password) => API.request('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) }),
  register: (payload) => API.request('/auth/register', { method: 'POST', body: JSON.stringify(payload) }),
  getProfile: () => API.request('/auth/profile'),

  // Problems
  getDailyProblem: () => API.request('/problems/daily'),
  getProblems: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return API.request(`/problems?${qs}`);
  },
  getProblemById: (id) => API.request(`/problems/${id}`),
  getFilterMetadata: () => API.request('/problems/metadata/filters'),

  // Submissions
  runSampleTests: (problemId, code, language) => API.request('/submissions/run', { method: 'POST', body: JSON.stringify({ problemId, code, language }) }),
  submitSolution: (problemId, code, language) => API.request('/submissions/submit', { method: 'POST', body: JSON.stringify({ problemId, code, language }) }),
  getSubmissions: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return API.request(`/submissions?${qs}`);
  },
  getUserHeatmap: (userId) => API.request(`/submissions/heatmap/${userId || ''}`),

  // Teams & Squads
  listTeams: () => API.request('/teams'),
  getTeamDetails: (id) => API.request(`/teams/${id}`),
  createTeam: (name, avatar) => API.request('/teams/create', { method: 'POST', body: JSON.stringify({ name, avatar }) }),
  joinTeam: (inviteCode) => API.request('/teams/join', { method: 'POST', body: JSON.stringify({ inviteCode }) }),
  leaveTeam: () => API.request('/teams/leave', { method: 'POST' }),

  // Contests & Leaderboard
  getActiveContest: () => API.request('/contests/active'),
  getLeaderboard: () => API.request('/contests/leaderboard'),

  // Plagiarism & Hints
  checkPlagiarism: (problemId, threshold) => {
    const qs = new URLSearchParams({ ...(problemId && { problemId }), ...(threshold && { threshold }) }).toString();
    return API.request(`/plagiarism/check?${qs}`);
  },
  getProblemHints: (problemId) => API.request(`/hints/${problemId}`)
};
