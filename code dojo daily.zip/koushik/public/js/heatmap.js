/**
 * GitHub-Style Daily Challenge Streak Calendar Heatmap
 */

const Heatmap = {
  async init() {
    await this.render();
    State.on('user:changed', () => this.render());
  },

  async render() {
    const container = document.getElementById('svg-heatmap-container');
    if (!container) return;

    try {
      const res = await API.getUserHeatmap();
      const activityMap = new Map();
      let totalSolves = 0;

      (res.activity || []).forEach(a => {
        activityMap.set(a.activity_date, a.solve_count);
        totalSolves += a.solve_count;
      });

      document.getElementById('heatmap-current-streak').textContent = `${res.currentStreak || 0} Days`;
      document.getElementById('heatmap-total-solves').textContent = `${totalSolves} Solves`;

      // Render 52-week SVG grid
      const weeks = 26; // Last 6 months
      const cellSize = 13;
      const cellGap = 3;
      const width = weeks * (cellSize + cellGap) + 50;
      const height = 7 * (cellSize + cellGap) + 20;

      const today = new Date();
      // Start 26 weeks ago on Sunday
      const startDate = new Date(today);
      startDate.setDate(today.getDate() - (weeks * 7) + (7 - today.getDay()));

      let rects = '';
      const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

      for (let w = 0; w < weeks; w++) {
        for (let d = 0; d < 7; d++) {
          const current = new Date(startDate);
          current.setDate(startDate.getDate() + (w * 7 + d));
          const dateStr = current.toISOString().split('T')[0];

          if (current > today) continue;

          const count = activityMap.get(dateStr) || 0;
          let levelClass = 'level-0';
          let fill = '#1e293b';

          if (count === 1) fill = '#0e4429';
          else if (count === 2) fill = '#006d32';
          else if (count === 3) fill = '#26a641';
          else if (count >= 4) fill = '#39d353';

          const x = 30 + w * (cellSize + cellGap);
          const y = 10 + d * (cellSize + cellGap);

          rects += `
            <rect x="${x}" y="${y}" width="${cellSize}" height="${cellSize}" rx="2" ry="2" 
                  fill="${fill}" data-date="${dateStr}" data-count="${count}">
              <title>${dateStr}: ${count} problems solved</title>
            </rect>
          `;
        }
      }

      // Day labels
      let dayLabels = '';
      [1, 3, 5].forEach(d => {
        dayLabels += `<text x="5" y="${10 + d * (cellSize + cellGap) + 10}" fill="#64748b" font-size="10">${days[d]}</text>`;
      });

      container.innerHTML = `
        <svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" style="display: block; margin: 0 auto;">
          ${dayLabels}
          ${rects}
        </svg>
      `;
    } catch (err) {
      container.innerHTML = `<p class="text-danger">Failed to render activity calendar: ${err.message}</p>`;
    }
  }
};
