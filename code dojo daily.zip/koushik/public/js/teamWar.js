/**
 * Live Countdown Team War Sprint Manager
 */

const TeamWar = {
  remainingSeconds: 0,
  timerInterval: null,

  async init() {
    await this.checkActiveContest();
  },

  async checkActiveContest() {
    try {
      const res = await API.getActiveContest();
      const banner = document.getElementById('contest-banner');

      if (res.hasActiveContest && res.contest && !res.contest.isExpired) {
        State.setContest(res.contest);
        this.remainingSeconds = res.contest.remainingSeconds;

        banner.classList.remove('hidden');
        document.getElementById('banner-contest-title').textContent = res.contest.title;
        document.getElementById('war-title').textContent = res.contest.title;
        document.getElementById('war-desc').textContent = res.contest.description;

        this.startTimer();
      } else {
        banner.classList.add('hidden');
        document.getElementById('war-status-text').textContent = 'NO SPRINT CURRENTLY RUNNING';
        document.getElementById('war-timer-display').textContent = '00:00';
      }
    } catch (err) {
      console.error('Failed to load contest info:', err);
    }
  },

  startTimer() {
    if (this.timerInterval) clearInterval(this.timerInterval);

    this.updateDisplays();
    this.timerInterval = setInterval(() => {
      if (this.remainingSeconds > 0) {
        this.remainingSeconds--;
        this.updateDisplays();
      } else {
        clearInterval(this.timerInterval);
        document.getElementById('banner-countdown').textContent = '00:00';
        document.getElementById('war-timer-display').textContent = '00:00';
        document.getElementById('war-status-text').textContent = 'SPRINT ENDED';
        showToast('The 60-minute Sprint War has concluded! Final scores tallied.', 'info');
      }
    }, 1000);
  },

  updateDisplays() {
    const mins = Math.floor(this.remainingSeconds / 60);
    const secs = this.remainingSeconds % 60;
    const formatted = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

    const bannerTime = document.getElementById('banner-countdown');
    const heroTime = document.getElementById('war-timer-display');

    if (bannerTime) bannerTime.textContent = formatted;
    if (heroTime) heroTime.textContent = formatted;
  }
};
