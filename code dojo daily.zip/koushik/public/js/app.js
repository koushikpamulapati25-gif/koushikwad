/**
 * Main CodeDojo Application Orchestrator
 */

function navigateToTab(targetId) {
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.classList.toggle('active', tab.getAttribute('data-target') === targetId);
  });

  document.querySelectorAll('.view-panel').forEach(panel => {
    panel.classList.toggle('active', panel.id === targetId);
  });

  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Refresh view-specific data when activated
  if (targetId === 'leaderboard-view') Leaderboard.load();
  if (targetId === 'teams-view') Teams.loadSquads();
  if (targetId === 'heatmap-view') Heatmap.render();
  if (targetId === 'workspace-view') Editor.updateLineNumbers();
}

function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span>${type === 'success' ? '✓' : type === 'error' ? '⚠' : 'ℹ'}</span>
    <span>${message}</span>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 200);
  }, 4000);
}

function openAuthModal() {
  document.getElementById('auth-modal').classList.remove('hidden');
}

function closeAuthModal() {
  document.getElementById('auth-modal').classList.add('hidden');
}

async function quickLogin(username) {
  try {
    const res = await API.login(username, 'Password123!');
    API.setToken(res.token);
    await refreshUserProfile();
    closeAuthModal();
    showToast(`Logged in as ${username}`, 'success');
  } catch (err) {
    showToast(`Quick login failed: ${err.message}`, 'error');
  }
}

async function refreshUserProfile() {
  const profileWidget = document.getElementById('user-profile-widget');
  const token = API.getToken();

  if (!token) {
    State.setUser(null);
    profileWidget.innerHTML = `
      <button class="btn btn-sm btn-primary" onclick="openAuthModal()">
        <span>👤</span> Sign In
      </button>
    `;
    return;
  }

  try {
    const res = await API.getProfile();
    State.setUser(res.user);

    profileWidget.innerHTML = `
      <div class="user-badge" onclick="openAuthModal()" title="Click to view details or switch account">
        <div class="user-avatar-circle">${res.user.username[0].toUpperCase()}</div>
        <span class="user-name-text">${res.user.username}</span>
        <span class="user-score-badge">★ ${res.user.stats.totalScore}</span>
      </div>
      <button class="btn btn-xs btn-outline" onclick="logout()" title="Logout">Logout</button>
    `;
  } catch (err) {
    API.setToken(null);
    State.setUser(null);
    profileWidget.innerHTML = `
      <button class="btn btn-sm btn-primary" onclick="openAuthModal()">
        <span>👤</span> Sign In
      </button>
    `;
  }
}

function logout() {
  API.setToken(null);
  State.setUser(null);
  refreshUserProfile();
  showToast('Logged out successfully', 'info');
}

document.addEventListener('DOMContentLoaded', async () => {
  // 1. Tab Navigation
  document.querySelectorAll('.nav-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.getAttribute('data-target');
      navigateToTab(target);
    });
  });

  // 2. Modals
  document.getElementById('btn-close-auth-modal')?.addEventListener('click', closeAuthModal);
  document.getElementById('btn-close-hint-modal')?.addEventListener('click', () => {
    document.getElementById('hint-modal').classList.add('hidden');
  });

  // 3. Auth Form Tabs
  const tabLogin = document.getElementById('tab-auth-login');
  const tabRegister = document.getElementById('tab-auth-register');
  const formLogin = document.getElementById('form-login');
  const formRegister = document.getElementById('form-register');

  tabLogin?.addEventListener('click', () => {
    tabLogin.classList.add('active');
    tabRegister.classList.remove('active');
    formLogin.classList.remove('hidden');
    formRegister.classList.add('hidden');
  });

  tabRegister?.addEventListener('click', () => {
    tabRegister.classList.add('active');
    tabLogin.classList.remove('active');
    formRegister.classList.remove('hidden');
    formLogin.classList.add('hidden');
  });

  // 4. Form Submissions
  formLogin?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const u = document.getElementById('login-username').value;
    const p = document.getElementById('login-password').value;
    try {
      const res = await API.login(u, p);
      API.setToken(res.token);
      await refreshUserProfile();
      closeAuthModal();
      showToast(`Welcome back, ${res.user.username}!`, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  formRegister?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('reg-username').value;
    const email = document.getElementById('reg-email').value;
    const password = document.getElementById('reg-password').value;
    try {
      const res = await API.register({ username, email, password });
      API.setToken(res.token);
      await refreshUserProfile();
      closeAuthModal();
      showToast('Registration successful! Welcome to CodeDojo Daily.', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // 5. Initialize Sub-modules
  Editor.init();
  await Problems.init();
  Teams.init();
  Leaderboard.init();
  await TeamWar.init();
  Plagiarism.init();
  await Heatmap.init();

  // 6. Try initial login as demo user if no token exists yet
  if (!API.getToken()) {
    await quickLogin('alex_coder');
  } else {
    await refreshUserProfile();
  }
});
