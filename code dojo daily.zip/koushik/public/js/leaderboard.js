/**
 * Live Team Contest Leaderboard with 5s Polling
 */

const Leaderboard = {
  pollingInterval: null,

  init() {
    this.bindEvents();
    this.load();
    this.startPolling();
  },

  bindEvents() {
    const btnRefresh = document.getElementById('btn-refresh-leaderboard');
    if (btnRefresh) {
      btnRefresh.addEventListener('click', () => {
        this.load();
        showToast('Refreshed leaderboard data', 'info');
      });
    }
  },

  startPolling() {
    if (this.pollingInterval) clearInterval(this.pollingInterval);
    // Poll every 5 seconds as specified in problem brief tip
    this.pollingInterval = setInterval(() => {
      this.load(true);
    }, 5000);
  },

  async load(isSilent = false) {
    const tbody = document.getElementById('leaderboard-table-body');
    if (!tbody) return;

    if (!isSilent && !tbody.children.length) {
      tbody.innerHTML = '<tr><td colspan="7" class="text-center">Loading live squad rankings...</td></tr>';
    }

    try {
      const res = await API.getLeaderboard();
      const list = res.leaderboard || [];

      if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center">No squads on the leaderboard yet.</td></tr>';
        return;
      }

      tbody.innerHTML = '';
      list.forEach((entry) => {
        const isUserTeam = State.currentUser?.team && State.currentUser.team.id === entry.teamId;

        let rankBadge = `<span class="rank-pill">${entry.rank}</span>`;
        if (entry.rank === 1) rankBadge = `<span class="rank-pill rank-1">🥇 1</span>`;
        if (entry.rank === 2) rankBadge = `<span class="rank-pill rank-2">🥈 2</span>`;
        if (entry.rank === 3) rankBadge = `<span class="rank-pill rank-3">🥉 3</span>`;

        const tr = document.createElement('tr');
        if (isUserTeam) {
          tr.style.backgroundColor = 'rgba(99, 102, 241, 0.12)';
          tr.style.borderLeft = '3px solid var(--primary)';
        }

        tr.innerHTML = `
          <td>${rankBadge}</td>
          <td>
            <strong style="color: #fff; font-size: 0.95rem;">${entry.teamName}</strong>
            ${isUserTeam ? '<span class="badge badge-accent" style="margin-left: 6px;">Your Squad</span>' : ''}
          </td>
          <td><span class="badge badge-primary">${entry.memberCount} Members</span></td>
          <td><strong style="color: #38bdf8;">${entry.distinctProblemsSolved}</strong></td>
          <td>${entry.sumMemberScores} pts</td>
          <td><span style="color: #34d399;">+${entry.streakBonus} pts</span></td>
          <td>
            <strong style="font-family: var(--font-mono); font-size: 1.1rem; color: #fbbf24;">
              ${entry.totalScore}
            </strong>
          </td>
        `;
        tbody.appendChild(tr);
      });
    } catch (err) {
      if (!isSilent) {
        tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Failed to load leaderboard: ${err.message}</td></tr>`;
      }
    }
  }
};
