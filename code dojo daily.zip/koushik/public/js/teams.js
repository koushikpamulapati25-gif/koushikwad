/**
 * Squads & Roster Management View
 */

const Teams = {
  init() {
    this.bindEvents();
    this.loadSquads();
  },

  bindEvents() {
    const createForm = document.getElementById('form-create-squad');
    if (createForm) {
      createForm.addEventListener('submit', (e) => this.handleCreateSquad(e));
    }

    const joinForm = document.getElementById('form-join-squad');
    if (joinForm) {
      joinForm.addEventListener('submit', (e) => this.handleJoinSquad(e));
    }

    State.on('user:changed', () => this.loadSquads());
  },

  async loadSquads() {
    const mySquadContainer = document.getElementById('my-squad-container');
    const allSquadsGrid = document.getElementById('all-squads-grid');

    // 1. Render Current User's Squad
    if (State.currentUser && State.currentUser.team) {
      try {
        const teamRes = await API.getTeamDetails(State.currentUser.team.id);
        const team = teamRes.team;

        mySquadContainer.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 1rem;">
            <div>
              <span class="badge badge-accent">YOUR SQUAD</span>
              <h2 style="color: #fff; margin: 0.35rem 0;">${team.name}</h2>
              <div style="display: flex; gap: 0.75rem; align-items: center; margin-top: 0.5rem;">
                <span class="badge badge-primary">${team.memberCount} / 4 Members</span>
                <span style="font-size: 0.85rem; color: #cbd5e1;">Invite Code: <strong style="font-family: var(--font-mono); color: #fef08a;">${team.inviteCode}</strong></span>
                <button class="btn btn-xs btn-outline" onclick="Teams.copyInviteCode('${team.inviteCode}')">Copy</button>
              </div>
            </div>
            <button class="btn btn-sm btn-outline text-danger" onclick="Teams.handleLeaveSquad()">Leave Squad</button>
          </div>

          <div style="margin-top: 1.25rem;">
            <h4 style="font-size: 0.85rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.5rem;">Squad Roster (3-4 Members)</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 0.75rem;">
              ${team.members.map(m => `
                <div style="background: var(--bg-dark); border: 1px solid var(--border-color); border-radius: 8px; padding: 0.75rem; display: flex; align-items: center; gap: 0.75rem;">
                  <div class="user-avatar-circle">${m.username[0].toUpperCase()}</div>
                  <div style="flex: 1;">
                    <div style="font-weight: 600; font-size: 0.9rem; color: #fff;">
                      ${m.username} ${m.role === 'leader' ? '👑' : ''}
                    </div>
                    <div style="font-size: 0.75rem; color: var(--text-muted);">
                      ${m.solveCount} solves • 🔥 ${m.streak}d streak
                    </div>
                  </div>
                  <div style="font-family: var(--font-mono); font-size: 0.85rem; color: #fbbf24; font-weight: 700;">
                    ${m.score} pts
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      } catch (err) {
        mySquadContainer.innerHTML = `<p class="text-danger">Failed to load squad details: ${err.message}</p>`;
      }
    } else {
      mySquadContainer.innerHTML = `
        <div style="text-align: center; padding: 1.5rem 0;">
          <h3 style="color: #fff; margin-bottom: 0.5rem;">You are not currently in a squad</h3>
          <p style="color: var(--text-muted); max-width: 500px; margin: 0 auto 1.25rem;">
            Create your own 3–4 member peer squad below or join an existing squad using an invite code to compete on the Campus Leaderboard!
          </p>
        </div>
      `;
    }

    // 2. Render Campus Squads Directory
    try {
      const res = await API.listTeams();
      if (!res.teams || !res.teams.length) {
        allSquadsGrid.innerHTML = '<p class="text-dim">No squads formed yet. Be the first to create one!</p>';
        return;
      }

      allSquadsGrid.innerHTML = res.teams.map(t => `
        <div class="squad-tile">
          <div>
            <div class="squad-tile-header">
              <span class="squad-avatar-img">🛡️</span>
              <div>
                <div class="squad-tile-title">${t.name}</div>
                <span class="badge ${t.memberCount >= 4 ? 'badge-hard' : 'badge-primary'}">${t.memberCount} / 4 Members</span>
              </div>
            </div>
            <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 0.5rem;">
              Invite: <span style="font-family: var(--font-mono); color: #cbd5e1;">${t.inviteCode}</span>
            </p>
          </div>
          ${(!State.currentUser?.team && t.memberCount < 4) ? `
            <button class="btn btn-xs btn-secondary btn-block" onclick="Teams.quickJoin('${t.inviteCode}')">
              Join Squad
            </button>
          ` : ''}
        </div>
      `).join('');
    } catch (err) {
      allSquadsGrid.innerHTML = `<p class="text-danger">Failed to load squads: ${err.message}</p>`;
    }
  },

  async handleCreateSquad(e) {
    e.preventDefault();
    if (!State.currentUser) {
      showToast('Please sign in first to create a squad.', 'error');
      openAuthModal();
      return;
    }

    const name = document.getElementById('create-squad-name').value;
    const avatar = document.getElementById('create-squad-avatar').value;

    try {
      const res = await API.createTeam(name, avatar);
      showToast(res.message, 'success');
      document.getElementById('form-create-squad').reset();
      await refreshUserProfile();
      await this.loadSquads();
      Leaderboard.load();
    } catch (err) {
      showToast(err.message || 'Squad creation failed', 'error');
    }
  },

  async handleJoinSquad(e) {
    e.preventDefault();
    if (!State.currentUser) {
      showToast('Please sign in first to join a squad.', 'error');
      openAuthModal();
      return;
    }

    const code = document.getElementById('join-squad-code').value;
    try {
      const res = await API.joinTeam(code);
      showToast(res.message, 'success');
      document.getElementById('form-join-squad').reset();
      await refreshUserProfile();
      await this.loadSquads();
      Leaderboard.load();
    } catch (err) {
      showToast(err.message || 'Squad join failed', 'error');
    }
  },

  async quickJoin(inviteCode) {
    if (!State.currentUser) {
      showToast('Please sign in first to join a squad.', 'error');
      openAuthModal();
      return;
    }

    try {
      const res = await API.joinTeam(inviteCode);
      showToast(res.message, 'success');
      await refreshUserProfile();
      await this.loadSquads();
      Leaderboard.load();
    } catch (err) {
      showToast(err.message || 'Squad join failed', 'error');
    }
  },

  async handleLeaveSquad() {
    if (!confirm('Are you sure you want to leave your squad?')) return;
    try {
      const res = await API.leaveTeam();
      showToast(res.message, 'info');
      await refreshUserProfile();
      await this.loadSquads();
      Leaderboard.load();
    } catch (err) {
      showToast(err.message || 'Failed to leave squad', 'error');
    }
  },

  copyInviteCode(code) {
    navigator.clipboard.writeText(code);
    showToast(`Invite code ${code} copied to clipboard!`, 'info');
  }
};
