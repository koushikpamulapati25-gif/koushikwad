/**
 * Problem Repository & Filtering View
 */

const Problems = {
  currentPage: 1,
  limit: 10,
  totalPages: 1,

  async init() {
    this.bindEvents();
    await this.loadFilterMetadata();
    await this.loadProblems();
    await this.loadDailyProblem();
  },

  bindEvents() {
    const searchInput = document.getElementById('problem-search');
    const diffSelect = document.getElementById('filter-difficulty');
    const domainSelect = document.getElementById('filter-domain');
    const btnPrev = document.getElementById('btn-problems-prev');
    const btnNext = document.getElementById('btn-problems-next');

    let debounceTimer;
    if (searchInput) {
      searchInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
          this.currentPage = 1;
          this.loadProblems();
        }, 300);
      });
    }

    if (diffSelect) {
      diffSelect.addEventListener('change', () => {
        this.currentPage = 1;
        this.loadProblems();
      });
    }

    if (domainSelect) {
      domainSelect.addEventListener('change', () => {
        this.currentPage = 1;
        this.loadProblems();
      });
    }

    if (btnPrev) {
      btnPrev.addEventListener('click', () => {
        if (this.currentPage > 1) {
          this.currentPage--;
          this.loadProblems();
        }
      });
    }

    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (this.currentPage < this.totalPages) {
          this.currentPage++;
          this.loadProblems();
        }
      });
    }

    // Daily View buttons
    const btnOpenDaily = document.getElementById('btn-open-daily-workspace');
    if (btnOpenDaily) {
      btnOpenDaily.addEventListener('click', () => {
        navigateToTab('workspace-view');
      });
    }

    const btnBrowse = document.getElementById('btn-view-all-problems');
    if (btnBrowse) {
      btnBrowse.addEventListener('click', () => {
        navigateToTab('problems-view');
      });
    }
  },

  async loadFilterMetadata() {
    try {
      const res = await API.getFilterMetadata();
      const domainSelect = document.getElementById('filter-domain');
      const plagProblemSelect = document.getElementById('plagiarism-problem-filter');

      if (domainSelect && res.domains) {
        domainSelect.innerHTML = '<option value="All">All Domains</option>';
        res.domains.forEach(d => {
          const opt = document.createElement('option');
          opt.value = d;
          opt.textContent = d;
          domainSelect.appendChild(opt);
        });
      }

      if (plagProblemSelect && res.domains) {
        // Will also be filled with problems
      }
    } catch (err) {
      console.error('Failed to load filter metadata:', err);
    }
  },

  async loadDailyProblem() {
    try {
      const res = await API.getDailyProblem();
      if (res.problem) {
        document.getElementById('daily-problem-title').textContent = res.problem.title;
        document.getElementById('daily-problem-desc').textContent = res.problem.description.substring(0, 180) + '...';

        const diffBadge = document.getElementById('daily-problem-difficulty');
        diffBadge.textContent = res.problem.difficulty;
        diffBadge.className = `badge badge-${res.problem.difficulty.toLowerCase()}`;

        document.getElementById('daily-problem-tag').textContent = res.problem.domain_tag;

        const statusBadge = document.getElementById('daily-problem-status');
        if (res.problem.isSolved) {
          statusBadge.textContent = '✓ Solved';
          statusBadge.className = 'badge badge-success';
        } else {
          statusBadge.textContent = 'Unsolved';
          statusBadge.className = 'badge badge-neutral';
        }

        // Set as initial active problem in State
        State.setProblem(res.problem);
      }
    } catch (err) {
      console.error('Failed to load daily problem:', err);
    }
  },

  async loadProblems() {
    const tbody = document.getElementById('problems-table-body');
    tbody.innerHTML = '<tr><td colspan="6" class="text-center">Loading challenges...</td></tr>';

    const search = document.getElementById('problem-search')?.value || '';
    const difficulty = document.getElementById('filter-difficulty')?.value || 'All';
    const domain = document.getElementById('filter-domain')?.value || 'All';

    try {
      const res = await API.getProblems({
        page: this.currentPage,
        limit: this.limit,
        search,
        difficulty,
        domain
      });

      this.totalPages = res.pagination.totalPages || 1;
      this.updatePagination(res.pagination);

      // Populate plagiarism problem filter options if needed
      const plagSelect = document.getElementById('plagiarism-problem-filter');
      if (plagSelect && plagSelect.options.length <= 1) {
        res.problems.forEach(p => {
          const opt = document.createElement('option');
          opt.value = p.id;
          opt.textContent = `${p.id}. ${p.title}`;
          plagSelect.appendChild(opt);
        });
      }

      if (!res.problems.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">No problems found matching filters.</td></tr>';
        return;
      }

      tbody.innerHTML = '';
      res.problems.forEach(p => {
        let pts = 20;
        if (p.difficulty === 'Medium') pts = 50;
        if (p.difficulty === 'Hard') pts = 100;

        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>
            ${p.isSolved ? '<span class="badge badge-success">✓ Solved</span>' : '<span class="badge badge-neutral">Pending</span>'}
          </td>
          <td>
            <strong>${p.title}</strong>
            ${p.daily_date ? '<span class="badge badge-accent" style="margin-left: 6px; font-size: 0.65rem;">Daily</span>' : ''}
          </td>
          <td><span class="badge badge-secondary">${p.domain_tag}</span></td>
          <td><span class="badge badge-${p.difficulty.toLowerCase()}">${p.difficulty}</span></td>
          <td><strong style="color: #fbbf24;">${pts}</strong></td>
          <td>
            <button class="btn btn-xs btn-primary" onclick="Problems.selectAndOpen(${p.id})">
              Solve Code ➔
            </button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">Error loading problems: ${err.message}</td></tr>`;
    }
  },

  updatePagination(pagination) {
    const pageInfo = document.getElementById('problems-page-info');
    const pageInd = document.getElementById('problems-current-page');
    const btnPrev = document.getElementById('btn-problems-prev');
    const btnNext = document.getElementById('btn-problems-next');

    const start = (pagination.page - 1) * pagination.limit + 1;
    const end = Math.min(pagination.page * pagination.limit, pagination.total);

    if (pageInfo) pageInfo.textContent = `Showing ${pagination.total === 0 ? 0 : start}-${end} of ${pagination.total} challenges`;
    if (pageInd) pageInd.textContent = `Page ${pagination.page} of ${pagination.totalPages || 1}`;

    if (btnPrev) btnPrev.disabled = pagination.page <= 1;
    if (btnNext) btnNext.disabled = pagination.page >= pagination.totalPages;
  },

  async selectAndOpen(problemId) {
    try {
      const res = await API.getProblemById(problemId);
      State.setProblem(res.problem);
      navigateToTab('workspace-view');
      showToast(`Loaded "${res.problem.title}" in Code Workspace`, 'info');
    } catch (err) {
      showToast(`Failed to load problem: ${err.message}`, 'error');
    }
  }
};
