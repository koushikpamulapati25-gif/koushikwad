const vm = require('vm');
const config = require('../config');

/**
 * Deep equality comparison helper for test results
 */
function areOutputsEqual(actual, expected) {
  if (actual === expected) return true;

  // Handle number float comparisons with epsilon
  if (typeof actual === 'number' && typeof expected === 'number') {
    return Math.abs(actual - expected) < 1e-5;
  }

  // Handle null / undefined
  if (actual == null || expected == null) {
    return actual === expected;
  }

  // Compare arrays and objects
  try {
    const actStr = JSON.stringify(actual);
    const expStr = JSON.stringify(expected);
    if (actStr === expStr) return true;

    // Check if both are arrays with unordered elements (e.g. 3Sum, Group Anagrams)
    if (Array.isArray(actual) && Array.isArray(expected)) {
      if (actual.length !== expected.length) return false;
      const sortedAct = JSON.stringify([...actual].sort());
      const sortedExp = JSON.stringify([...expected].sort());
      if (sortedAct === sortedExp) return true;
    }
  } catch {
    // fallback
  }

  return false;
}

/**
 * Parses test case input arguments safely
 */
function parseInputs(inputStr) {
  try {
    const parsed = JSON.parse(inputStr);
    return Array.isArray(parsed) ? parsed : [parsed];
  } catch {
    return [inputStr];
  }
}

/**
 * Parses expected output safely
 */
function parseExpected(expectedStr) {
  try {
    return JSON.parse(expectedStr);
  } catch {
    return expectedStr;
  }
}

/**
 * Extracts candidate function name from user code or starter code
 */
function extractFunctionName(code) {
  const match = code.match(/function\s+([a-zA-Z0-9_$]+)\s*\(/);
  if (match) return match[1];

  const arrowMatch = code.match(/(?:const|let|var)\s+([a-zA-Z0-9_$]+)\s*=\s*(?:\([^)]*\)|[a-zA-Z0-9_$]+)\s*=>/);
  if (arrowMatch) return arrowMatch[1];

  return null;
}

/**
 * Evaluates JavaScript code against an array of test cases in an isolated VM sandbox
 */
async function runTestCases(code, testCases, timeoutMs = config.EXECUTION_TIMEOUT_MS) {
  // Static security check to prevent sandbox breakout attempts
  const blacklisted = [
    'child_process', 'require', 'process.mainModule',
    'process.binding', 'process.env', 'fs', 'net', 'http'
  ];
  for (const term of blacklisted) {
    if (code.includes(term)) {
      return {
        verdict: 'Security Violation',
        passedCount: 0,
        totalCount: testCases.length,
        totalExecutionTimeMs: 0,
        errorMessage: `Access to restricted identifier "${term}" is blocked by code sandbox policy.`,
        testCaseResults: []
      };
    }
  }

  const fnName = extractFunctionName(code);
  if (!fnName) {
    return {
      verdict: 'Compilation Error',
      passedCount: 0,
      totalCount: testCases.length,
      totalExecutionTimeMs: 0,
      errorMessage: 'Could not detect a valid entry function in your solution.',
      testCaseResults: []
    };
  }

  const testCaseResults = [];
  let passedCount = 0;
  let totalExecutionTimeMs = 0;
  let overallVerdict = 'Accepted';
  let firstErrorMessage = null;

  for (let i = 0; i < testCases.length; i++) {
    const tc = testCases[i];
    const args = parseInputs(tc.input);
    const expected = parseExpected(tc.expected_output);

    // Create locked isolated context
    const sandboxContext = {
      console: { log: () => {} },
      Math,
      Array,
      Object,
      String,
      Number,
      Boolean,
      Set,
      Map,
      Infinity,
      NaN,
      parseInt,
      parseFloat
    };

    const vmContext = vm.createContext(sandboxContext);

    // Build execution script
    const harnessCode = `
      ${code}
      __result = ${fnName}(...__args);
    `;

    sandboxContext.__args = args;
    sandboxContext.__result = undefined;

    const startTime = process.hrtime.bigint();
    let actualResult;
    let tcPassed = false;
    let tcError = null;

    try {
      const script = new vm.Script(harnessCode);
      script.runInContext(vmContext, { timeout: timeoutMs });
      actualResult = sandboxContext.__result;
      tcPassed = areOutputsEqual(actualResult, expected);

      if (!tcPassed && overallVerdict === 'Accepted') {
        overallVerdict = 'Wrong Answer';
      }
    } catch (err) {
      tcError = err.message || String(err);
      if (err.message && err.message.includes('timed out')) {
        overallVerdict = 'Time Limit Exceeded';
        tcError = `Time Limit Exceeded (${timeoutMs}ms limit exceeded)`;
      } else if (overallVerdict === 'Accepted') {
        overallVerdict = 'Runtime Error';
      }
      if (!firstErrorMessage) firstErrorMessage = tcError;
    }

    const endTime = process.hrtime.bigint();
    const elapsedMs = Number(endTime - startTime) / 1e6;
    totalExecutionTimeMs += elapsedMs;

    if (tcPassed) passedCount++;

    testCaseResults.push({
      testCaseIndex: i + 1,
      input: tc.is_hidden ? '[Hidden Test Case]' : tc.input,
      expected: tc.is_hidden ? '[Hidden Test Case]' : expected,
      actual: tc.is_hidden ? (tcPassed ? '[Hidden Passed]' : '[Hidden Failed]') : (tcError || actualResult),
      passed: tcPassed,
      isHidden: !!tc.is_hidden,
      executionTimeMs: Math.round(elapsedMs * 100) / 100,
      errorMessage: tcError,
      explanation: tc.explanation || null
    });
  }

  return {
    verdict: passedCount === testCases.length ? 'Accepted' : overallVerdict,
    passedCount,
    totalCount: testCases.length,
    totalExecutionTimeMs: Math.round(totalExecutionTimeMs * 100) / 100,
    errorMessage: firstErrorMessage,
    testCaseResults
  };
}

module.exports = {
  runTestCases,
  areOutputsEqual,
  parseInputs,
  parseExpected,
  extractFunctionName
};
