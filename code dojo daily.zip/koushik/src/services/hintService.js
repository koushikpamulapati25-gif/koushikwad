const db = require('../database/db');

/**
 * Retrieves hints based on user failed attempts
 */
function getProblemHintsForUser(problemId, userId) {
  // Check how many failed runs the user has made for this problem
  const failStats = db.get(
    `SELECT COUNT(*) as failed_count 
     FROM submissions 
     WHERE problem_id = ? AND user_id = ? AND status != 'Accepted'`,
    [problemId, userId]
  );

  const failedCount = failStats ? failStats.failed_count : 0;
  const hints = db.all(
    `SELECT level, title, hint_text 
     FROM hints 
     WHERE problem_id = ? 
     ORDER BY level ASC`,
    [problemId]
  );

  // Progressive unlocking policy:
  // 0 fails: Hints locked
  // 1-2 fails: Level 1 hint unlocked
  // 3-4 fails: Level 1 & 2 hints unlocked (satisfies requirement: "when user fails 3 test runs")
  // 5+ fails: All 3 hints unlocked
  const unlockedHints = hints.map(h => {
    let unlocked = false;
    let reason = 'Keep trying to unlock clues';

    if (h.level === 1 && failedCount >= 1) {
      unlocked = true;
    } else if (h.level === 2 && failedCount >= 3) {
      unlocked = true;
    } else if (h.level === 3 && failedCount >= 5) {
      unlocked = true;
    } else {
      const required = h.level === 1 ? 1 : (h.level === 2 ? 3 : 5);
      reason = `Requires ${required} failed attempts (currently ${failedCount})`;
    }

    return {
      level: h.level,
      title: h.title,
      text: unlocked ? h.hint_text : null,
      unlocked,
      reason
    };
  });

  return {
    problemId,
    failedRunsCount: failedCount,
    hintsUnlocked: unlockedHints.filter(h => h.unlocked).length,
    hints: unlockedHints
  };
}

module.exports = {
  getProblemHintsForUser
};
