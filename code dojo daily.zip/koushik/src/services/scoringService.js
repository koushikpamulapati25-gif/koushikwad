const db = require('../database/db');
const config = require('../config');

/**
 * Calculates user's active consecutive day streak
 */
function calculateUserStreak(userId) {
  const dates = db.all(
    `SELECT DISTINCT activity_date 
     FROM activity_log 
     WHERE user_id = ? 
     ORDER BY activity_date DESC`,
    [userId]
  );

  if (!dates.length) return 0;

  const todayStr = new Date().toISOString().split('T')[0];
  const yesterdayDate = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const yesterdayStr = yesterdayDate.toISOString().split('T')[0];

  // Most recent activity must be today or yesterday to maintain an active streak
  const mostRecent = dates[0].activity_date;
  if (mostRecent !== todayStr && mostRecent !== yesterdayStr) {
    return 0;
  }

  let streak = 0;
  let expected = new Date(mostRecent);

  for (const row of dates) {
    const current = new Date(row.activity_date);
    const diffDays = Math.round((expected.getTime() - current.getTime()) / (1000 * 3600 * 24));

    if (diffDays === 0) {
      streak++;
      expected.setDate(expected.getDate() - 1);
    } else {
      break;
    }
  }

  return streak;
}

/**
 * Checks if a live contest sprint is currently active
 */
function getActiveContest() {
  const now = new Date().toISOString();
  return db.get(
    `SELECT * FROM contests 
     WHERE is_active = 1 
       AND datetime(start_time) <= datetime(?) 
       AND datetime(end_time) >= datetime(?) 
     ORDER BY id DESC LIMIT 1`,
    [now, now]
  );
}

/**
 * Calculates points for a problem based on difficulty and contest multiplier
 */
function getProblemBasePoints(difficulty) {
  switch (difficulty) {
    case 'Easy': return config.POINTS_PER_EASY;
    case 'Medium': return config.POINTS_PER_MEDIUM;
    case 'Hard': return config.POINTS_PER_HARD;
    default: return config.POINTS_PER_EASY;
  }
}

/**
 * Computes individual user statistics and score
 */
function getUserScoreAndSolves(userId) {
  // Find all distinct problems user has solved with 'Accepted' status
  const acceptedSolves = db.all(
    `SELECT DISTINCT s.problem_id, p.difficulty, p.title, MIN(s.submitted_at) as solved_at
     FROM submissions s
     JOIN problems p ON s.problem_id = p.id
     WHERE s.user_id = ? AND s.status = 'Accepted'
     GROUP BY s.problem_id`,
    [userId]
  );

  let baseScore = 0;
  for (const solve of acceptedSolves) {
    baseScore += getProblemBasePoints(solve.difficulty);
  }

  const streak = calculateUserStreak(userId);
  const streakBonus = streak * config.STREAK_BONUS_PER_DAY;
  const totalScore = baseScore + streakBonus;

  return {
    userId,
    solveCount: acceptedSolves.length,
    baseScore,
    streak,
    streakBonus,
    totalScore,
    solvedProblems: acceptedSolves
  };
}

/**
 * Computes live squad leaderboard based on problem brief formula:
 * TeamScore = sum(MemberScores) + StreakBonus + ContestMultiplierBonus
 */
function getTeamLeaderboard() {
  const teams = db.all('SELECT * FROM teams ORDER BY id ASC');
  const activeContest = getActiveContest();
  const contestMultiplier = activeContest ? activeContest.multiplier : 1.0;

  const leaderboard = [];

  for (const team of teams) {
    const members = db.all(
      `SELECT u.id, u.username, u.avatar, tm.role, tm.joined_at
       FROM team_members tm
       JOIN users u ON tm.user_id = u.id
       WHERE tm.team_id = ?`,
      [team.id]
    );

    let teamSolveCount = 0;
    let sumMemberScores = 0;
    let totalTeamStreak = 0;
    const teamSolvedProblemIds = new Set();
    const memberStats = [];

    for (const member of members) {
      const stats = getUserScoreAndSolves(member.id);
      memberStats.push({
        id: member.id,
        username: member.username,
        avatar: member.avatar,
        role: member.role,
        solveCount: stats.solveCount,
        streak: stats.streak,
        score: stats.totalScore
      });

      sumMemberScores += stats.baseScore;
      totalTeamStreak += stats.streak;

      stats.solvedProblems.forEach(p => teamSolvedProblemIds.add(p.problem_id));
      teamSolveCount += stats.solveCount;
    }

    const teamStreakBonus = totalTeamStreak * config.STREAK_BONUS_PER_DAY;
    const finalScore = Math.round((sumMemberScores * contestMultiplier) + teamStreakBonus);

    // Latest submission timestamp for tie-breaking speed
    const latestSub = db.get(
      `SELECT MAX(submitted_at) as last_solve_time 
       FROM submissions 
       WHERE team_id = ? AND status = 'Accepted'`,
      [team.id]
    );

    leaderboard.push({
      teamId: team.id,
      teamName: team.name,
      teamAvatar: team.avatar,
      memberCount: members.length,
      members: memberStats,
      distinctProblemsSolved: teamSolvedProblemIds.size,
      totalSolves: teamSolveCount,
      sumMemberScores,
      contestMultiplier,
      streakBonus: teamStreakBonus,
      totalScore: finalScore,
      lastSolveTime: latestSub ? latestSub.last_solve_time : team.created_at
    });
  }

  // Sort by totalScore DESC, then lastSolveTime ASC (faster completion wins ties)
  leaderboard.sort((a, b) => {
    if (b.totalScore !== a.totalScore) return b.totalScore - a.totalScore;
    return new Date(a.lastSolveTime) - new Date(b.lastSolveTime);
  });

  // Assign ranks
  leaderboard.forEach((entry, idx) => {
    entry.rank = idx + 1;
  });

  return {
    leaderboard,
    activeContest: activeContest ? {
      id: activeContest.id,
      title: activeContest.title,
      multiplier: activeContest.multiplier,
      startTime: activeContest.start_time,
      endTime: activeContest.end_time
    } : null
  };
}

module.exports = {
  calculateUserStreak,
  getActiveContest,
  getProblemBasePoints,
  getUserScoreAndSolves,
  getTeamLeaderboard
};
