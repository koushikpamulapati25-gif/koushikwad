const db = require('../database/db');
const { calculateSimilarity } = require('../utils/levenshtein');

/**
 * Checks plagiarism similarity across all submissions for a problem or across teams
 */
function analyzeProblemSubmissions(problemId, threshold = 60) {
  // Get all accepted submissions for this problem
  const query = problemId 
    ? `SELECT s.id, s.problem_id, p.title as problem_title, s.user_id, u.username, 
              s.team_id, t.name as team_name, s.code, s.language, s.submitted_at
       FROM submissions s
       JOIN users u ON s.user_id = u.id
       JOIN problems p ON s.problem_id = p.id
       LEFT JOIN teams t ON s.team_id = t.id
       WHERE s.problem_id = ? AND s.status = 'Accepted'
       ORDER BY s.submitted_at ASC`
    : `SELECT s.id, s.problem_id, p.title as problem_title, s.user_id, u.username, 
              s.team_id, t.name as team_name, s.code, s.language, s.submitted_at
       FROM submissions s
       JOIN users u ON s.user_id = u.id
       JOIN problems p ON s.problem_id = p.id
       LEFT JOIN teams t ON s.team_id = t.id
       WHERE s.status = 'Accepted'
       ORDER BY s.submitted_at ASC LIMIT 100`;

  const submissions = problemId ? db.all(query, [problemId]) : db.all(query);
  const comparisons = [];

  for (let i = 0; i < submissions.length; i++) {
    for (let j = i + 1; j < submissions.length; j++) {
      const sub1 = submissions[i];
      const sub2 = submissions[j];

      // Compare only submissions from different users
      if (sub1.user_id === sub2.user_id) continue;
      // Compare only same problem and language
      if (sub1.problem_id !== sub2.problem_id) continue;
      if (sub1.language !== sub2.language) continue;

      const similarity = calculateSimilarity(sub1.code, sub2.code);

      let status = 'Clear';
      if (similarity >= 85) status = 'Severe Plagiarism';
      else if (similarity >= 70) status = 'High Similarity';
      else if (similarity >= 50) status = 'Moderate Similarity';

      comparisons.push({
        problemId: sub1.problem_id,
        problemTitle: sub1.problem_title,
        submissionA: {
          id: sub1.id,
          username: sub1.username,
          teamName: sub1.team_name || 'Individual',
          submittedAt: sub1.submitted_at,
          codeSnippet: sub1.code.substring(0, 180)
        },
        submissionB: {
          id: sub2.id,
          username: sub2.username,
          teamName: sub2.team_name || 'Individual',
          submittedAt: sub2.submitted_at,
          codeSnippet: sub2.code.substring(0, 180)
        },
        similarityPercentage: similarity,
        status,
        flagged: similarity >= threshold
      });
    }
  }

  // Sort by similarity percentage descending
  comparisons.sort((a, b) => b.similarityPercentage - a.similarityPercentage);

  return {
    problemId: problemId || 'All',
    totalCompared: comparisons.length,
    flaggedCount: comparisons.filter(c => c.flagged).length,
    comparisons
  };
}

module.exports = {
  analyzeProblemSubmissions
};
