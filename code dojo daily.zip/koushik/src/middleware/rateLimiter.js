const rateLimitStore = new Map();

/**
 * In-memory sliding window rate limiter middleware
 */
function createRateLimiter(windowMs = 60000, maxRequests = 60) {
  return (req, res, next) => {
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
    const key = `${ip}:${req.path}`;
    const now = Date.now();

    let record = rateLimitStore.get(key);
    if (!record) {
      record = { count: 1, resetTime: now + windowMs };
      rateLimitStore.set(key, record);
      return next();
    }

    if (now > record.resetTime) {
      record.count = 1;
      record.resetTime = now + windowMs;
      return next();
    }

    record.count++;
    if (record.count > maxRequests) {
      const retryAfterSec = Math.ceil((record.resetTime - now) / 1000);
      res.setHeader('Retry-After', retryAfterSec);
      return res.status(429).json({
        success: false,
        error: `Rate limit exceeded. Try again in ${retryAfterSec} seconds.`
      });
    }

    next();
  };
}

module.exports = {
  createRateLimiter
};
