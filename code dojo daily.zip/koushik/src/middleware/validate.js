/**
 * Request validation and input sanitization helpers
 */

function sanitizeString(str) {
  if (typeof str !== 'string') return '';
  return str.trim();
}

function validateRegistration(req, res, next) {
  let { username, email, password } = req.body;
  username = sanitizeString(username);
  email = sanitizeString(email).toLowerCase();

  if (!username || username.length < 3 || username.length > 30) {
    return res.status(400).json({
      success: false,
      error: 'Username must be between 3 and 30 characters.'
    });
  }

  if (!/^[a-zA-Z0-9_]+$/.test(username)) {
    return res.status(400).json({
      success: false,
      error: 'Username can only contain alphanumeric characters and underscores.'
    });
  }

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({
      success: false,
      error: 'A valid email address is required.'
    });
  }

  if (!password || password.length < 6) {
    return res.status(400).json({
      success: false,
      error: 'Password must be at least 6 characters long.'
    });
  }

  req.body.username = username;
  req.body.email = email;
  next();
}

function validateSubmission(req, res, next) {
  const { problemId, code, language } = req.body;

  if (!problemId || isNaN(Number(problemId))) {
    return res.status(400).json({
      success: false,
      error: 'A valid problemId is required.'
    });
  }

  if (!code || typeof code !== 'string' || !code.trim()) {
    return res.status(400).json({
      success: false,
      error: 'Code submission cannot be empty.'
    });
  }

  if (code.length > 50000) {
    return res.status(400).json({
      success: false,
      error: 'Code submission exceeds maximum allowed size (50KB).'
    });
  }

  const validLangs = ['javascript', 'python', 'cpp'];
  const lang = (language || 'javascript').toLowerCase();
  if (!validLangs.includes(lang)) {
    return res.status(400).json({
      success: false,
      error: `Unsupported language "${language}". Supported: ${validLangs.join(', ')}`
    });
  }

  req.body.language = lang;
  next();
}

function validateTeamCreation(req, res, next) {
  let { name, avatar } = req.body;
  name = sanitizeString(name);

  if (!name || name.length < 3 || name.length > 40) {
    return res.status(400).json({
      success: false,
      error: 'Squad name must be between 3 and 40 characters.'
    });
  }

  req.body.name = name;
  req.body.avatar = avatar || 'squad-tiger';
  next();
}

module.exports = {
  sanitizeString,
  validateRegistration,
  validateSubmission,
  validateTeamCreation
};
