const express = require('express');
const router = express.Router();
const plagiarismController = require('../controllers/plagiarismController');

router.get('/check', plagiarismController.checkPlagiarism);

module.exports = router;
