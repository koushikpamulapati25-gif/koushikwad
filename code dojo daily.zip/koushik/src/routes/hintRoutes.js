const express = require('express');
const router = express.Router();
const hintController = require('../controllers/hintController');
const { optionalAuth } = require('../middleware/auth');

router.get('/:problemId', optionalAuth, hintController.getProblemHints);

module.exports = router;
