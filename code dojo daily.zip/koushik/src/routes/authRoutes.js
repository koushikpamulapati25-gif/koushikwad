const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');
const { validateRegistration } = require('../middleware/validate');
const { createRateLimiter } = require('../middleware/rateLimiter');

// Rate limit login attempts to prevent brute force
const authLimiter = createRateLimiter(15 * 60 * 1000, 20);

router.post('/register', authLimiter, validateRegistration, authController.register);
router.post('/login', authLimiter, authController.login);
router.get('/profile', authenticate, authController.getProfile);

module.exports = router;
