const express = require('express');
const router = express.Router();
const teamController = require('../controllers/teamController');
const { authenticate } = require('../middleware/auth');
const { validateTeamCreation } = require('../middleware/validate');

router.get('/', teamController.listTeams);
router.get('/:id', teamController.getTeamDetails);
router.post('/create', authenticate, validateTeamCreation, teamController.createTeam);
router.post('/join', authenticate, teamController.joinTeam);
router.post('/leave', authenticate, teamController.leaveTeam);

module.exports = router;
