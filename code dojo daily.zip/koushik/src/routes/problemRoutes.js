const express = require('express');
const router = express.Router();
const problemController = require('../controllers/problemController');
const { optionalAuth } = require('../middleware/auth');

router.get('/daily', optionalAuth, problemController.getDailyProblem);
router.get('/metadata/filters', problemController.getProblemFilterMetadata);
router.get('/', optionalAuth, problemController.getProblems);
router.get('/:id', optionalAuth, problemController.getProblemById);

module.exports = router;
