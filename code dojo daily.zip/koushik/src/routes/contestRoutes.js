const express = require('express');
const router = express.Router();
const contestController = require('../controllers/contestController');

router.get('/active', contestController.getActiveContestDetails);
router.get('/leaderboard', contestController.getLeaderboard);

module.exports = router;
