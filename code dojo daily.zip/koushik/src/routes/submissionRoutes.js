const express = require('express');
const router = express.Router();
const submissionController = require('../controllers/submissionController');
const { authenticate, optionalAuth } = require('../middleware/auth');
const { validateSubmission } = require('../middleware/validate');
const { createRateLimiter } = require('../middleware/rateLimiter');

// Rate limit submissions to prevent spamming execution runner
const submissionLimiter = createRateLimiter(60 * 1000, 30);

router.post('/run', submissionLimiter, validateSubmission, submissionController.runSampleTests);
router.post('/submit', authenticate, submissionLimiter, validateSubmission, submissionController.submitCode);
router.get('/', optionalAuth, submissionController.getSubmissions);
router.get('/heatmap', optionalAuth, submissionController.getUserActivityHeatmap);
router.get('/heatmap/:userId', optionalAuth, submissionController.getUserActivityHeatmap);

module.exports = router;
