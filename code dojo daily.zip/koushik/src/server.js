const app = require('./app');
const config = require('./config');
const db = require('./database/db');
const { seedDatabase } = require('./database/seedData');
const logger = require('./utils/logger');

async function startServer() {
  try {
    // 1. Initialize SQLite Database
    await db.initDatabase();
    logger.info('SQLite database engine initialized.');

    // 2. Seed initial dataset (26 algorithmic challenges, teams, users, contests)
    await seedDatabase();

    // 3. Start listening
    const server = app.listen(config.PORT, () => {
      logger.info(`=======================================================`);
      logger.info(`CodeDojo Daily Server is live on http://localhost:${config.PORT}`);
      logger.info(`Environment: ${config.NODE_ENV}`);
      logger.info(`=======================================================`);
    });

    // Graceful shutdown handling
    function gracefulShutdown(signal) {
      logger.info(`Received ${signal}. Shutting down gracefully...`);
      db.persistToDisk();
      server.close(() => {
        logger.info('HTTP server closed. Exiting process.');
        process.exit(0);
      });
    }

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    return server;
  } catch (err) {
    logger.error('Failed to start server:', err);
    process.exit(1);
  }
}

if (require.main === module) {
  startServer();
}

module.exports = { startServer };
