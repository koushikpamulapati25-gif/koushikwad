/**
 * Levenshtein Distance & Code Plagiarism Analyzer
 * Normalizes code tokens and computes normalized Levenshtein similarity distance.
 */

function normalizeCode(code) {
  if (!code || typeof code !== 'string') return '';
  return code
    // Remove multi-line comments
    .replace(/\/\*[\s\S]*?\*\//g, '')
    // Remove single-line comments
    .replace(/\/\/.*$/gm, '')
    // Remove Python comments
    .replace(/#.*$/gm, '')
    // Normalize strings to string literals
    .replace(/"(?:[^"\\]|\\.)*"/g, '""')
    .replace(/'(?:[^'\\]|\\.)*'/g, "''")
    // Normalize numeric literals
    .replace(/\b\d+\b/g, '0')
    // Standardize whitespace
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Computes Levenshtein matrix distance between two strings
 */
function computeLevenshteinDistance(s1, s2) {
  const m = s1.length;
  const n = s2.length;
  if (m === 0) return n;
  if (n === 0) return m;

  // Use two-row space optimization
  let prevRow = new Array(n + 1);
  let currRow = new Array(n + 1);

  for (let j = 0; j <= n; j++) {
    prevRow[j] = j;
  }

  for (let i = 1; i <= m; i++) {
    currRow[0] = i;
    const char1 = s1[i - 1];
    for (let j = 1; j <= n; j++) {
      const cost = char1 === s2[j - 1] ? 0 : 1;
      currRow[j] = Math.min(
        currRow[j - 1] + 1,      // insertion
        prevRow[j] + 1,          // deletion
        prevRow[j - 1] + cost    // substitution
      );
    }
    for (let j = 0; j <= n; j++) {
      prevRow[j] = currRow[j];
    }
  }

  return currRow[n];
}

/**
 * Calculates similarity percentage between two code snippets (0 to 100%)
 */
function calculateSimilarity(code1, code2) {
  const norm1 = normalizeCode(code1);
  const norm2 = normalizeCode(code2);

  if (norm1 === norm2) return 100;
  if (!norm1 || !norm2) return 0;

  const maxLen = Math.max(norm1.length, norm2.length);
  if (maxLen === 0) return 100;

  const distance = computeLevenshteinDistance(norm1, norm2);
  const similarity = Math.max(0, (1 - distance / maxLen) * 100);
  return Math.round(similarity * 10) / 10;
}

module.exports = {
  normalizeCode,
  computeLevenshteinDistance,
  calculateSimilarity
};
