const bcrypt = require('bcryptjs');
const db = require('./db');
const logger = require('../utils/logger');

const sampleProblems = [
  {
    slug: 'two-sum',
    title: 'Two Sum',
    difficulty: 'Easy',
    domain_tag: 'Hash Maps',
    daily_date: new Date().toISOString().split('T')[0], // Today's daily problem!
    description: `Given an array of integers \`nums\` and an integer \`target\`, return indices of the two numbers such that they add up to \`target\`.

You may assume that each input would have exactly one solution, and you may not use the same element twice. You can return the answer in any order.`,
    examples: [
      { input: 'nums = [2,7,11,15], target = 9', output: '[0,1]', explanation: 'Because nums[0] + nums[1] == 9, we return [0, 1].' },
      { input: 'nums = [3,2,4], target = 6', output: '[1,2]', explanation: 'nums[1] + nums[2] == 6.' }
    ],
    constraints: [
      '2 <= nums.length <= 10^4',
      '-10^9 <= nums[i] <= 10^9',
      '-10^9 <= target <= 10^9',
      'Only one valid answer exists.'
    ],
    starter_code: {
      javascript: `function twoSum(nums, target) {
  // Write your solution here
  const map = new Map();
  for (let i = 0; i < nums.length; i++) {
    const complement = target - nums[i];
    if (map.has(complement)) {
      return [map.get(complement), i];
    }
    map.set(nums[i], i);
  }
  return [];
}`,
      python: `def two_sum(nums, target):
    # Write your solution here
    seen = {}
    for i, num in enumerate(nums):
        complement = target - num
        if complement in seen:
            return [seen[complement], i]
        seen[num] = i
    return []`,
      cpp: `vector<int> twoSum(vector<int>& nums, int target) {
    unordered_map<int, int> seen;
    for (int i = 0; i < nums.size(); i++) {
        int comp = target - nums[i];
        if (seen.count(comp)) return {seen[comp], i};
        seen[nums[i]] = i;
    }
    return {};
}`
    },
    hints: [
      { level: 1, title: 'Brute Force vs Optimized', text: 'A naive approach checks every pair in O(N^2). Can you do it in a single pass O(N)?' },
      { level: 2, title: 'Data Structure Choice', text: 'Consider storing elements you have seen in a Hash Map mapping value -> index.' },
      { level: 3, title: 'Complement Lookup', text: 'For each element x, check if (target - x) exists in your map. If so, return their indices.' }
    ],
    test_cases: [
      { input: JSON.stringify([[2, 7, 11, 15], 9]), expected_output: JSON.stringify([0, 1]), is_hidden: 0, explanation: 'Basic test case' },
      { input: JSON.stringify([[3, 2, 4], 6]), expected_output: JSON.stringify([1, 2]), is_hidden: 0, explanation: 'Unordered elements' },
      { input: JSON.stringify([[3, 3], 6]), expected_output: JSON.stringify([0, 1]), is_hidden: 1, explanation: 'Duplicate values' },
      { input: JSON.stringify([[-1, -2, -3, -4, -5], -8]), expected_output: JSON.stringify([2, 4]), is_hidden: 1, explanation: 'Negative numbers' },
      { input: JSON.stringify([[1000000, 500, 2000000, 700], 1200]), expected_output: JSON.stringify([1, 3]), is_hidden: 1, explanation: 'Large and small values' }
    ]
  },
  {
    slug: 'reverse-string',
    title: 'Reverse String',
    difficulty: 'Easy',
    domain_tag: 'Strings',
    daily_date: '2026-11-21',
    description: `Write a function that reverses a string. The input string is given as an array of characters \`s\`.

You must do this by modifying the input array in-place with O(1) extra memory.`,
    examples: [
      { input: 's = ["h","e","l","l","o"]', output: '["o","l","l","e","h"]', explanation: 'String reversed in place.' },
      { input: 's = ["H","a","n","n","a","h"]', output: '["h","a","n","n","a","H"]', explanation: 'Palindromic word reversed.' }
    ],
    constraints: [
      '1 <= s.length <= 10^5',
      's[i] is a printable ascii character.'
    ],
    starter_code: {
      javascript: `function reverseString(s) {
  let left = 0, right = s.length - 1;
  while (left < right) {
    const temp = s[left];
    s[left] = s[right];
    s[right] = temp;
    left++;
    right--;
  }
  return s;
}`,
      python: `def reverse_string(s):
    left, right = 0, len(s) - 1
    while left < right:
        s[left], s[right] = s[right], s[left]
        left += 1
        right -= 1
    return s`,
      cpp: `void reverseString(vector<char>& s) {
    int l = 0, r = s.size() - 1;
    while (l < r) swap(s[l++], s[r--]);
}`
    },
    hints: [
      { level: 1, title: 'Two Pointers Concept', text: 'Set one pointer at the start and another at the end.' },
      { level: 2, title: 'In-Place Swap', text: 'Swap the characters at both pointers and step inward.' },
      { level: 3, title: 'Termination Condition', text: 'Stop when the left pointer is no longer strictly less than the right pointer.' }
    ],
    test_cases: [
      { input: JSON.stringify([["h","e","l","l","o"]]), expected_output: JSON.stringify(["o","l","l","e","h"]), is_hidden: 0 },
      { input: JSON.stringify([["H","a","n","n","a","h"]]), expected_output: JSON.stringify(["h","a","n","n","a","H"]), is_hidden: 0 },
      { input: JSON.stringify([["a"]]), expected_output: JSON.stringify(["a"]), is_hidden: 1 },
      { input: JSON.stringify([["a","b"]]), expected_output: JSON.stringify(["b","a"]), is_hidden: 1 },
      { input: JSON.stringify([["1","2","3","4","5","6"]]), expected_output: JSON.stringify(["6","5","4","3","2","1"]), is_hidden: 1 }
    ]
  },
  {
    slug: 'valid-palindrome',
    title: 'Valid Palindrome',
    difficulty: 'Easy',
    domain_tag: 'Two Pointers',
    daily_date: '2026-11-20',
    description: `A phrase is a palindrome if, after converting all uppercase letters into lowercase letters and removing all non-alphanumeric characters, it reads the same forward and backward. Alphanumeric characters include letters and numbers.

Given a string \`s\`, return \`true\` if it is a palindrome, or \`false\` otherwise.`,
    examples: [
      { input: 's = "A man, a plan, a canal: Panama"', output: 'true', explanation: '"amanaplanacanalpanama" is a palindrome.' },
      { input: 's = "race a car"', output: 'false', explanation: '"raceacar" is not a palindrome.' }
    ],
    constraints: ['1 <= s.length <= 2 * 10^5', 's consists only of printable ASCII characters.'],
    starter_code: {
      javascript: `function isPalindrome(s) {
  const clean = s.toLowerCase().replace(/[^a-z0-9]/g, '');
  let l = 0, r = clean.length - 1;
  while (l < r) {
    if (clean[l] !== clean[r]) return false;
    l++;
    r--;
  }
  return true;
}`,
      python: `def is_palindrome(s):
    clean = [c.lower() for c in s if c.isalnum()]
    return clean == clean[::-1]`
    },
    hints: [
      { level: 1, title: 'Clean the String', text: 'Strip out all non-alphanumeric characters and lowercase everything.' },
      { level: 2, title: 'Two Pointers Check', text: 'Compare start and end characters while incrementing/decrementing.' },
      { level: 3, title: 'Edge Cases', text: 'An empty string or single alphanumeric character is considered a valid palindrome.' }
    ],
    test_cases: [
      { input: JSON.stringify(["A man, a plan, a canal: Panama"]), expected_output: JSON.stringify(true), is_hidden: 0 },
      { input: JSON.stringify(["race a car"]), expected_output: JSON.stringify(false), is_hidden: 0 },
      { input: JSON.stringify([" "]), expected_output: JSON.stringify(true), is_hidden: 1 },
      { input: JSON.stringify(["0P"]), expected_output: JSON.stringify(false), is_hidden: 1 },
      { input: JSON.stringify(["Madam, I'm Adam"]), expected_output: JSON.stringify(true), is_hidden: 1 }
    ]
  },
  {
    slug: 'best-time-to-buy-and-sell-stock',
    title: 'Best Time to Buy and Sell Stock',
    difficulty: 'Easy',
    domain_tag: 'Greedy',
    daily_date: '2026-11-19',
    description: `You are given an array \`prices\` where \`prices[i]\` is the price of a given stock on the \`i\`-th day.

You want to maximize your profit by choosing a single day to buy one stock and choosing a different day in the future to sell that stock.

Return the maximum profit you can achieve from this transaction. If you cannot achieve any profit, return 0.`,
    examples: [
      { input: 'prices = [7,1,5,3,6,4]', output: '5', explanation: 'Buy on day 2 (price = 1) and sell on day 5 (price = 6), profit = 6-1 = 5.' },
      { input: 'prices = [7,6,4,3,1]', output: '0', explanation: 'In this case, no transactions are done and max profit = 0.' }
    ],
    constraints: ['1 <= prices.length <= 10^5', '0 <= prices[i] <= 10^4'],
    starter_code: {
      javascript: `function maxProfit(prices) {
  let minPrice = Infinity;
  let maxProfit = 0;
  for (let price of prices) {
    if (price < minPrice) minPrice = price;
    else if (price - minPrice > maxProfit) maxProfit = price - minPrice;
  }
  return maxProfit;
}`,
      python: `def max_profit(prices):
    min_price = float('inf')
    max_p = 0
    for p in prices:
        if p < min_price:
            min_price = p
        elif p - min_price > max_p:
            max_p = p - min_price
    return max_p`
    },
    hints: [
      { level: 1, title: 'Single Pass Strategy', text: 'You cannot sell before you buy. Track the lowest price seen so far.' },
      { level: 2, title: 'Profit Calculation', text: 'At each day, the potential profit is current price minus minimum previous price.' },
      { level: 3, title: 'No Profit Fallback', text: 'Initialize max profit to 0 so downward trends safely return 0.' }
    ],
    test_cases: [
      { input: JSON.stringify([[7, 1, 5, 3, 6, 4]]), expected_output: JSON.stringify(5), is_hidden: 0 },
      { input: JSON.stringify([[7, 6, 4, 3, 1]]), expected_output: JSON.stringify(0), is_hidden: 0 },
      { input: JSON.stringify([[2, 4, 1]]), expected_output: JSON.stringify(2), is_hidden: 1 },
      { input: JSON.stringify([[1, 2]]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([[3, 3, 5, 0, 0, 3, 1, 4]]), expected_output: JSON.stringify(4), is_hidden: 1 }
    ]
  },
  {
    slug: 'valid-parentheses',
    title: 'Valid Parentheses',
    difficulty: 'Easy',
    domain_tag: 'Strings',
    daily_date: '2026-11-18',
    description: `Given a string \`s\` containing just the characters '(', ')', '{', '}', '[' and ']', determine if the input string is valid.

An input string is valid if:
1. Open brackets must be closed by the same type of brackets.
2. Open brackets must be closed in the correct order.
3. Every close bracket has a corresponding open bracket of the same type.`,
    examples: [
      { input: 's = "()"', output: 'true' },
      { input: 's = "()[]{}"', output: 'true' },
      { input: 's = "(]"', output: 'false' }
    ],
    constraints: ['1 <= s.length <= 10^4', 's consists of parentheses only "()[]{}"'],
    starter_code: {
      javascript: `function isValid(s) {
  const stack = [];
  const map = { ')': '(', '}': '{', ']': '[' };
  for (const char of s) {
    if (char === '(' || char === '{' || char === '[') {
      stack.push(char);
    } else {
      if (stack.pop() !== map[char]) return false;
    }
  }
  return stack.length === 0;
}`,
      python: `def is_valid(s):
    stack = []
    mapping = {")": "(", "}": "{", "]": "["}
    for char in s:
        if char in mapping:
            top = stack.pop() if stack else '#'
            if mapping[char] != top:
                return False
        else:
            stack.append(char)
    return not stack`
    },
    hints: [
      { level: 1, title: 'Stack Data Structure', text: 'Use a Last-In First-Out (LIFO) stack to hold unmatched open brackets.' },
      { level: 2, title: 'Matching Bracket Check', text: 'When encountering a closing bracket, check if it matches the top of the stack.' },
      { level: 3, title: 'Final Stack Verification', text: 'If any unmatched opening brackets remain at the end, return false.' }
    ],
    test_cases: [
      { input: JSON.stringify(["()"]), expected_output: JSON.stringify(true), is_hidden: 0 },
      { input: JSON.stringify(["()[]{}"]), expected_output: JSON.stringify(true), is_hidden: 0 },
      { input: JSON.stringify(["(]"]), expected_output: JSON.stringify(false), is_hidden: 0 },
      { input: JSON.stringify(["([)]"]), expected_output: JSON.stringify(false), is_hidden: 1 },
      { input: JSON.stringify(["{[]}"]), expected_output: JSON.stringify(true), is_hidden: 1 }
    ]
  },
  {
    slug: 'maximum-subarray',
    title: 'Maximum Subarray (Kadane)',
    difficulty: 'Medium',
    domain_tag: 'Dynamic Programming',
    daily_date: '2026-11-17',
    description: `Given an integer array \`nums\`, find the subarray with the largest sum, and return its sum.`,
    examples: [
      { input: 'nums = [-2,1,-3,4,-1,2,1,-5,4]', output: '6', explanation: 'The subarray [4,-1,2,1] has the largest sum 6.' },
      { input: 'nums = [1]', output: '1' }
    ],
    constraints: ['1 <= nums.length <= 10^5', '-10^4 <= nums[i] <= 10^4'],
    starter_code: {
      javascript: `function maxSubArray(nums) {
  let currentSum = nums[0];
  let maxSum = nums[0];
  for (let i = 1; i < nums.length; i++) {
    currentSum = Math.max(nums[i], currentSum + nums[i]);
    maxSum = Math.max(maxSum, currentSum);
  }
  return maxSum;
}`,
      python: `def max_sub_array(nums):
    curr_sum = max_sum = nums[0]
    for x in nums[1:]:
        curr_sum = max(x, curr_sum + x)
        max_sum = max(max_sum, curr_sum)
    return max_sum`
    },
    hints: [
      { level: 1, title: "Kadane's Algorithm", text: 'Keep a running tally of the current contiguous sum.' },
      { level: 2, title: 'Resetting Subarray', text: 'If current sum falls below the current element, start fresh from the current element.' },
      { level: 3, title: 'Global Max Tracker', text: 'Update the global maximum at every step.' }
    ],
    test_cases: [
      { input: JSON.stringify([[-2, 1, -3, 4, -1, 2, 1, -5, 4]]), expected_output: JSON.stringify(6), is_hidden: 0 },
      { input: JSON.stringify([[1]]), expected_output: JSON.stringify(1), is_hidden: 0 },
      { input: JSON.stringify([[5, 4, -1, 7, 8]]), expected_output: JSON.stringify(23), is_hidden: 1 },
      { input: JSON.stringify([[-1]]), expected_output: JSON.stringify(-1), is_hidden: 1 },
      { input: JSON.stringify([[-2, -1]]), expected_output: JSON.stringify(-1), is_hidden: 1 }
    ]
  },
  {
    slug: 'longest-substring-without-repeating-characters',
    title: 'Longest Substring Without Repeating Characters',
    difficulty: 'Medium',
    domain_tag: 'Two Pointers',
    daily_date: '2026-11-16',
    description: `Given a string \`s\`, find the length of the longest substring without repeating characters.`,
    examples: [
      { input: 's = "abcabcbb"', output: '3', explanation: 'The answer is "abc", with the length of 3.' },
      { input: 's = "bbbbb"', output: '1', explanation: 'The answer is "b", with the length of 1.' }
    ],
    constraints: ['0 <= s.length <= 5 * 10^4', 's consists of English letters, digits, symbols and spaces.'],
    starter_code: {
      javascript: `function lengthOfLongestSubstring(s) {
  const map = new Map();
  let maxLen = 0, left = 0;
  for (let right = 0; right < s.length; right++) {
    if (map.has(s[right])) {
      left = Math.max(left, map.get(s[right]) + 1);
    }
    map.set(s[right], right);
    maxLen = Math.max(maxLen, right - left + 1);
  }
  return maxLen;
}`,
      python: `def length_of_longest_substring(s):
    char_map = {}
    max_len = left = 0
    for right, c in enumerate(s):
        if c in char_map:
            left = max(left, char_map[c] + 1)
        char_map[c] = right
        max_len = max(max_len, right - left + 1)
    return max_len`
    },
    hints: [
      { level: 1, title: 'Sliding Window', text: 'Maintain a window [left, right] that contains only distinct characters.' },
      { level: 2, title: 'Hash Map of Indices', text: 'Store the most recent index of each character to skip duplicate characters efficiently.' },
      { level: 3, title: 'Pointer Jumping', text: 'When a repeat is found, jump left to max(left, last_index + 1).' }
    ],
    test_cases: [
      { input: JSON.stringify(["abcabcbb"]), expected_output: JSON.stringify(3), is_hidden: 0 },
      { input: JSON.stringify(["bbbbb"]), expected_output: JSON.stringify(1), is_hidden: 0 },
      { input: JSON.stringify(["pwwkew"]), expected_output: JSON.stringify(3), is_hidden: 0 },
      { input: JSON.stringify([""]), expected_output: JSON.stringify(0), is_hidden: 1 },
      { input: JSON.stringify(["abba"]), expected_output: JSON.stringify(2), is_hidden: 1 }
    ]
  },
  {
    slug: 'container-with-most-water',
    title: 'Container With Most Water',
    difficulty: 'Medium',
    domain_tag: 'Two Pointers',
    daily_date: '2026-11-15',
    description: `You are given an integer array \`height\` of length \`n\`. There are \`n\` vertical lines drawn such that the two endpoints of the \`i\`-th line are \`(i, 0)\` and \`(i, height[i])\`.

Find two lines that together with the x-axis form a container, such that the container contains the most water.

Return the maximum amount of water a container can store.`,
    examples: [
      { input: 'height = [1,8,6,2,5,4,8,3,7]', output: '49', explanation: 'The max area is between index 1 and 8: min(8, 7) * 7 = 49.' }
    ],
    constraints: ['n == height.length', '2 <= n <= 10^5', '0 <= height[i] <= 10^4'],
    starter_code: {
      javascript: `function maxArea(height) {
  let l = 0, r = height.length - 1;
  let max = 0;
  while (l < r) {
    const area = Math.min(height[l], height[r]) * (r - l);
    if (area > max) max = area;
    if (height[l] < height[r]) l++;
    else r--;
  }
  return max;
}`,
      python: `def max_area(height):
    l, r = 0, len(height) - 1
    max_a = 0
    while l < r:
        area = min(height[l], height[r]) * (r - l)
        max_a = max(max_a, area)
        if height[l] < height[r]:
            l += 1
        else:
            r -= 1
    return max_a`
    },
    hints: [
      { level: 1, title: 'Two Pointers from Edges', text: 'Start with the widest container: one pointer at index 0, one at index n - 1.' },
      { level: 2, title: 'Which Pointer to Move?', text: 'The height is limited by the shorter line. Moving the taller line can never increase area.' },
      { level: 3, title: 'Advance Shorter Line', text: 'Always advance the pointer corresponding to the shorter vertical bar.' }
    ],
    test_cases: [
      { input: JSON.stringify([[1, 8, 6, 2, 5, 4, 8, 3, 7]]), expected_output: JSON.stringify(49), is_hidden: 0 },
      { input: JSON.stringify([[1, 1]]), expected_output: JSON.stringify(1), is_hidden: 0 },
      { input: JSON.stringify([[4, 3, 2, 1, 4]]), expected_output: JSON.stringify(16), is_hidden: 1 },
      { input: JSON.stringify([[1, 2, 1]]), expected_output: JSON.stringify(2), is_hidden: 1 },
      { input: JSON.stringify([[1, 2, 4, 3]]), expected_output: JSON.stringify(4), is_hidden: 1 }
    ]
  },
  {
    slug: '3sum',
    title: '3Sum',
    difficulty: 'Medium',
    domain_tag: 'Two Pointers',
    daily_date: '2026-11-14',
    description: `Given an integer array \`nums\`, return all the triplets \`[nums[i], nums[j], nums[k]]\` such that \`i != j\`, \`i != k\`, and \`j != k\`, and \`nums[i] + nums[j] + nums[k] == 0\`.

Notice that the solution set must not contain duplicate triplets.`,
    examples: [
      { input: 'nums = [-1,0,1,2,-1,-4]', output: '[[-1,-1,2],[-1,0,1]]' }
    ],
    constraints: ['3 <= nums.length <= 3000', '-10^5 <= nums[i] <= 10^5'],
    starter_code: {
      javascript: `function threeSum(nums) {
  nums.sort((a, b) => a - b);
  const result = [];
  for (let i = 0; i < nums.length - 2; i++) {
    if (i > 0 && nums[i] === nums[i - 1]) continue;
    let l = i + 1, r = nums.length - 1;
    while (l < r) {
      const sum = nums[i] + nums[l] + nums[r];
      if (sum === 0) {
        result.push([nums[i], nums[l], nums[r]]);
        while (l < r && nums[l] === nums[l + 1]) l++;
        while (l < r && nums[r] === nums[r - 1]) r--;
        l++;
        r--;
      } else if (sum < 0) {
        l++;
      } else {
        r--;
      }
    }
  }
  return result;
}`,
      python: `def three_sum(nums):
    nums.sort()
    res = []
    for i in range(len(nums) - 2):
        if i > 0 and nums[i] == nums[i-1]:
            continue
        l, r = i + 1, len(nums) - 1
        while l < r:
            s = nums[i] + nums[l] + nums[r]
            if s == 0:
                res.append([nums[i], nums[l], nums[r]])
                while l < r and nums[l] == nums[l+1]: l += 1
                while l < r and nums[r] == nums[r-1]: r -= 1
                l += 1
                r -= 1
            elif s < 0:
                l += 1
            else:
                r -= 1
    return res`
    },
    hints: [
      { level: 1, title: 'Sort First', text: 'Sorting takes O(N log N) and lets you avoid duplicates easily.' },
      { level: 2, title: 'Fix One Element', text: 'Iterate through the array, fixing nums[i], then do Two Pointers for the remainder.' },
      { level: 3, title: 'Skip Duplicates', text: 'Skip identical neighboring elements to avoid duplicate triplets in the output.' }
    ],
    test_cases: [
      { input: JSON.stringify([[-1, 0, 1, 2, -1, -4]]), expected_output: JSON.stringify([[-1, -1, 2], [-1, 0, 1]]), is_hidden: 0 },
      { input: JSON.stringify([[0, 1, 1]]), expected_output: JSON.stringify([]), is_hidden: 0 },
      { input: JSON.stringify([[0, 0, 0]]), expected_output: JSON.stringify([[0, 0, 0]]), is_hidden: 1 },
      { input: JSON.stringify([[-2, 0, 1, 1, 2]]), expected_output: JSON.stringify([[-2, 0, 2], [-2, 1, 1]]), is_hidden: 1 },
      { input: JSON.stringify([[-1, 0, 1, 0]]), expected_output: JSON.stringify([[-1, 0, 1]]), is_hidden: 1 }
    ]
  },
  {
    slug: 'climbing-stairs',
    title: 'Climbing Stairs',
    difficulty: 'Easy',
    domain_tag: 'Dynamic Programming',
    daily_date: '2026-11-13',
    description: `You are climbing a staircase. It takes \`n\` steps to reach the top.

Each time you can either climb 1 or 2 steps. In how many distinct ways can you climb to the top?`,
    examples: [
      { input: 'n = 2', output: '2', explanation: '1. 1 step + 1 step, 2. 2 steps.' },
      { input: 'n = 3', output: '3', explanation: '1. 1+1+1, 2. 1+2, 3. 2+1.' }
    ],
    constraints: ['1 <= n <= 45'],
    starter_code: {
      javascript: `function climbStairs(n) {
  if (n <= 2) return n;
  let a = 1, b = 2;
  for (let i = 3; i <= n; i++) {
    const temp = a + b;
    a = b;
    b = temp;
  }
  return b;
}`,
      python: `def climb_stairs(n):
    if n <= 2: return n
    a, b = 1, 2
    for _ in range(3, n + 1):
        a, b = b, a + b
    return b`
    },
    hints: [
      { level: 1, title: 'Recurrence Relation', text: 'To reach step n, you must arrive from either step n - 1 or step n - 2.' },
      { level: 2, title: 'Fibonacci Pattern', text: 'ways(n) = ways(n - 1) + ways(n - 2).' },
      { level: 3, title: 'Space Optimization', text: 'You only need two variables to store previous values in O(1) space.' }
    ],
    test_cases: [
      { input: JSON.stringify([2]), expected_output: JSON.stringify(2), is_hidden: 0 },
      { input: JSON.stringify([3]), expected_output: JSON.stringify(3), is_hidden: 0 },
      { input: JSON.stringify([1]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([4]), expected_output: JSON.stringify(5), is_hidden: 1 },
      { input: JSON.stringify([10]), expected_output: JSON.stringify(89), is_hidden: 1 }
    ]
  },
  {
    slug: 'coin-change',
    title: 'Coin Change',
    difficulty: 'Medium',
    domain_tag: 'Dynamic Programming',
    daily_date: '2026-11-12',
    description: `You are given an integer array \`coins\` representing coins of different denominations and an integer \`amount\` representing a total amount of money.

Return the fewest number of coins that you need to make up that amount. If that amount of money cannot be made up by any combination of the coins, return \`-1\`.

You may assume that you have an infinite number of each kind of coin.`,
    examples: [
      { input: 'coins = [1,2,5], amount = 11', output: '3', explanation: '11 = 5 + 5 + 1' },
      { input: 'coins = [2], amount = 3', output: '-1' }
    ],
    constraints: ['1 <= coins.length <= 12', '1 <= coins[i] <= 2^31 - 1', '0 <= amount <= 10^4'],
    starter_code: {
      javascript: `function coinChange(coins, amount) {
  const dp = new Array(amount + 1).fill(Infinity);
  dp[0] = 0;
  for (let i = 1; i <= amount; i++) {
    for (const coin of coins) {
      if (i - coin >= 0) {
        dp[i] = Math.min(dp[i], dp[i - coin] + 1);
      }
    }
  }
  return dp[amount] === Infinity ? -1 : dp[amount];
}`,
      python: `def coin_change(coins, amount):
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0
    for i in range(1, amount + 1):
        for c in coins:
            if i - c >= 0:
                dp[i] = min(dp[i], dp[i - c] + 1)
    return dp[amount] if dp[amount] != float('inf') else -1`
    },
    hints: [
      { level: 1, title: 'Bottom-Up Dynamic Programming', text: 'Build an array dp of length amount + 1 initialized to Infinity.' },
      { level: 2, title: 'Base Case', text: '0 amount requires 0 coins (dp[0] = 0).' },
      { level: 3, title: 'Transition', text: 'For each sub-amount i and coin c, dp[i] = min(dp[i], dp[i - c] + 1).' }
    ],
    test_cases: [
      { input: JSON.stringify([[1, 2, 5], 11]), expected_output: JSON.stringify(3), is_hidden: 0 },
      { input: JSON.stringify([[2], 3]), expected_output: JSON.stringify(-1), is_hidden: 0 },
      { input: JSON.stringify([[1], 0]), expected_output: JSON.stringify(0), is_hidden: 1 },
      { input: JSON.stringify([[186, 419, 83, 408], 6249]), expected_output: JSON.stringify(20), is_hidden: 1 },
      { input: JSON.stringify([[2, 5, 10, 1], 27]), expected_output: JSON.stringify(4), is_hidden: 1 }
    ]
  },
  {
    slug: 'product-of-array-except-self',
    title: 'Product of Array Except Self',
    difficulty: 'Medium',
    domain_tag: 'Arrays',
    daily_date: '2026-11-11',
    description: `Given an integer array \`nums\`, return an array \`answer\` such that \`answer[i]\` is equal to the product of all the elements of \`nums\` except \`nums[i]\`.

The product of any prefix or suffix of \`nums\` is guaranteed to fit in a 32-bit integer.

You must write an algorithm that runs in O(n) time and without using the division operation.`,
    examples: [
      { input: 'nums = [1,2,3,4]', output: '[24,12,8,6]' },
      { input: 'nums = [-1,1,0,-3,3]', output: '[0,0,9,0,0]' }
    ],
    constraints: ['2 <= nums.length <= 10^5', '-30 <= nums[i] <= 30'],
    starter_code: {
      javascript: `function productExceptSelf(nums) {
  const n = nums.length;
  const res = new Array(n).fill(1);
  let prefix = 1;
  for (let i = 0; i < n; i++) {
    res[i] = prefix;
    prefix *= nums[i];
  }
  let suffix = 1;
  for (let i = n - 1; i >= 0; i--) {
    res[i] *= suffix;
    suffix *= nums[i];
  }
  return res;
}`,
      python: `def product_except_self(nums):
    n = len(nums)
    res = [1] * n
    prefix = 1
    for i in range(n):
        res[i] = prefix
        prefix *= nums[i]
    suffix = 1
    for i in range(n - 1, -1, -1):
        res[i] *= suffix
        suffix *= nums[i]
    return res`
    },
    hints: [
      { level: 1, title: 'Prefix and Suffix Products', text: 'Every element result is the product of elements to its left times elements to its right.' },
      { level: 2, title: 'First Pass', text: 'Compute prefix products in the result array in the forward direction.' },
      { level: 3, title: 'Second Pass', text: 'Maintain a rolling suffix product running backwards and multiply with the prefix.' }
    ],
    test_cases: [
      { input: JSON.stringify([[1, 2, 3, 4]]), expected_output: JSON.stringify([24, 12, 8, 6]), is_hidden: 0 },
      { input: JSON.stringify([[-1, 1, 0, -3, 3]]), expected_output: JSON.stringify([0, 0, 9, 0, 0]), is_hidden: 0 },
      { input: JSON.stringify([[2, 3]]), expected_output: JSON.stringify([3, 2]), is_hidden: 1 },
      { input: JSON.stringify([[0, 0]]), expected_output: JSON.stringify([0, 0]), is_hidden: 1 },
      { input: JSON.stringify([[1, 2, 3, 0]]), expected_output: JSON.stringify([0, 0, 0, 6]), is_hidden: 1 }
    ]
  },
  {
    slug: 'group-anagrams',
    title: 'Group Anagrams',
    difficulty: 'Medium',
    domain_tag: 'Hash Maps',
    daily_date: '2026-11-10',
    description: `Given an array of strings \`strs\`, group the anagrams together. You can return the answer in any order.

An Anagram is a word or phrase formed by rearranging the letters of a different word or phrase, typically using all the original letters exactly once.`,
    examples: [
      { input: 'strs = ["eat","tea","tan","ate","nat","bat"]', output: '[["bat"],["nat","tan"],["ate","eat","tea"]]' }
    ],
    constraints: ['1 <= strs.length <= 10^4', '0 <= strs[i].length <= 100', 'strs[i] consists of lowercase English letters.'],
    starter_code: {
      javascript: `function groupAnagrams(strs) {
  const map = {};
  for (const str of strs) {
    const key = str.split('').sort().join('');
    if (!map[key]) map[key] = [];
    map[key].push(str);
  }
  return Object.values(map);
}`,
      python: `from collections import defaultdict
def group_anagrams(strs):
    d = defaultdict(list)
    for s in strs:
        d[''.join(sorted(s))].append(s)
    return list(d.values())`
    },
    hints: [
      { level: 1, title: 'Canonical Key', text: 'All anagrams have identical characters when sorted alphabetically.' },
      { level: 2, title: 'Hash Map Bucket', text: 'Use the sorted string as a dictionary key and append matching original strings.' },
      { level: 3, title: 'Output Formatting', text: 'Return the values of the hash map.' }
    ],
    test_cases: [
      { input: JSON.stringify([["eat","tea","tan","ate","nat","bat"]]), expected_output: JSON.stringify([["eat","tea","ate"],["tan","nat"],["bat"]]), is_hidden: 0 },
      { input: JSON.stringify([[""]]), expected_output: JSON.stringify([[""]]), is_hidden: 0 },
      { input: JSON.stringify([["a"]]), expected_output: JSON.stringify([["a"]]), is_hidden: 1 },
      { input: JSON.stringify([["ab","ba","abc"]]), expected_output: JSON.stringify([["ab","ba"],["abc"]]), is_hidden: 1 },
      { input: JSON.stringify([["listen","silent","enlist"]]), expected_output: JSON.stringify([["listen","silent","enlist"]]), is_hidden: 1 }
    ]
  },
  {
    slug: 'find-minimum-in-rotated-sorted-array',
    title: 'Find Minimum in Rotated Sorted Array',
    difficulty: 'Medium',
    domain_tag: 'Binary Search',
    daily_date: '2026-11-09',
    description: `Suppose an array of length \`n\` sorted in ascending order is rotated between \`1\` and \`n\` times.

Given the sorted rotated array \`nums\` of unique elements, return the minimum element of this array.

You must write an algorithm that runs in O(log n) time.`,
    examples: [
      { input: 'nums = [3,4,5,1,2]', output: '1', explanation: 'The original array was [1,2,3,4,5] rotated 3 times.' },
      { input: 'nums = [4,5,6,7,0,1,2]', output: '0' }
    ],
    constraints: ['n == nums.length', '1 <= n <= 5000', '-5000 <= nums[i] <= 5000', 'All the integers of nums are unique.'],
    starter_code: {
      javascript: `function findMin(nums) {
  let l = 0, r = nums.length - 1;
  while (l < r) {
    const mid = Math.floor((l + r) / 2);
    if (nums[mid] > nums[r]) l = mid + 1;
    else r = mid;
  }
  return nums[l];
}`,
      python: `def find_min(nums):
    l, r = 0, len(nums) - 1
    while l < r:
        mid = (l + r) // 2
        if nums[mid] > nums[r]:
            l = mid + 1
        else:
            r = mid
    return nums[l]`
    },
    hints: [
      { level: 1, title: 'Binary Search Property', text: 'Compare the middle element with the rightmost element.' },
      { level: 2, title: 'Inflection Point', text: 'If nums[mid] > nums[r], the minimum must be in the right half.' },
      { level: 3, title: 'Convergence', text: 'If nums[mid] <= nums[r], the minimum is at mid or in the left half.' }
    ],
    test_cases: [
      { input: JSON.stringify([[3, 4, 5, 1, 2]]), expected_output: JSON.stringify(1), is_hidden: 0 },
      { input: JSON.stringify([[4, 5, 6, 7, 0, 1, 2]]), expected_output: JSON.stringify(0), is_hidden: 0 },
      { input: JSON.stringify([[11, 13, 15, 17]]), expected_output: JSON.stringify(11), is_hidden: 1 },
      { input: JSON.stringify([[2, 1]]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([[1]]), expected_output: JSON.stringify(1), is_hidden: 1 }
    ]
  },
  {
    slug: 'house-robber',
    title: 'House Robber',
    difficulty: 'Medium',
    domain_tag: 'Dynamic Programming',
    daily_date: '2026-11-08',
    description: `You are a professional robber planning to rob houses along a street. Each house has a certain amount of money stashed, the only constraint stopping you from robbing each of them is that adjacent houses have security systems connected and it will automatically contact the police if two adjacent houses were broken into on the same night.

Given an integer array \`nums\` representing the amount of money of each house, return the maximum amount of money you can rob tonight without alerting the police.`,
    examples: [
      { input: 'nums = [1,2,3,1]', output: '4', explanation: 'Rob house 1 (money = 1) and then rob house 3 (money = 3). Total = 1 + 3 = 4.' },
      { input: 'nums = [2,7,9,3,1]', output: '12', explanation: 'Rob house 1 (2), house 3 (9), house 5 (1). Total = 2 + 9 + 1 = 12.' }
    ],
    constraints: ['1 <= nums.length <= 100', '0 <= nums[i] <= 400'],
    starter_code: {
      javascript: `function rob(nums) {
  let prev1 = 0, prev2 = 0;
  for (const num of nums) {
    const temp = Math.max(prev1, prev2 + num);
    prev2 = prev1;
    prev1 = temp;
  }
  return prev1;
}`,
      python: `def rob(nums):
    prev1 = prev2 = 0
    for num in nums:
        prev1, prev2 = max(prev1, prev2 + num), prev1
    return prev1`
    },
    hints: [
      { level: 1, title: 'State Formulation', text: 'At each house i, you either rob it (nums[i] + rob(i-2)) or skip it (rob(i-1)).' },
      { level: 2, title: 'Recurrence', text: 'dp[i] = max(dp[i-1], dp[i-2] + nums[i]).' },
      { level: 3, title: 'Space Optimization', text: 'Maintain just two variables for previous house states.' }
    ],
    test_cases: [
      { input: JSON.stringify([[1, 2, 3, 1]]), expected_output: JSON.stringify(4), is_hidden: 0 },
      { input: JSON.stringify([[2, 7, 9, 3, 1]]), expected_output: JSON.stringify(12), is_hidden: 0 },
      { input: JSON.stringify([[2, 1, 1, 2]]), expected_output: JSON.stringify(4), is_hidden: 1 },
      { input: JSON.stringify([[0]]), expected_output: JSON.stringify(0), is_hidden: 1 },
      { input: JSON.stringify([[100, 1, 1, 100]]), expected_output: JSON.stringify(200), is_hidden: 1 }
    ]
  },
  {
    slug: 'jump-game',
    title: 'Jump Game',
    difficulty: 'Medium',
    domain_tag: 'Greedy',
    daily_date: '2026-11-07',
    description: `You are given an integer array \`nums\`. You are initially positioned at the array's first index, and each element in the array represents your maximum jump length at that position.

Return \`true\` if you can reach the last index, or \`false\` otherwise.`,
    examples: [
      { input: 'nums = [2,3,1,1,4]', output: 'true', explanation: 'Jump 1 step from index 0 to 1, then 3 steps to the last index.' },
      { input: 'nums = [3,2,1,0,4]', output: 'false', explanation: 'You will always arrive at index 3 no matter what.' }
    ],
    constraints: ['1 <= nums.length <= 10^4', '0 <= nums[i] <= 10^5'],
    starter_code: {
      javascript: `function canJump(nums) {
  let maxReach = 0;
  for (let i = 0; i < nums.length; i++) {
    if (i > maxReach) return false;
    maxReach = Math.max(maxReach, i + nums[i]);
    if (maxReach >= nums.length - 1) return true;
  }
  return true;
}`,
      python: `def can_jump(nums):
    max_reach = 0
    for i, jump in enumerate(nums):
        if i > max_reach:
            return False
        max_reach = max(max_reach, i + jump)
    return True`
    },
    hints: [
      { level: 1, title: 'Greedy Farthest Reach', text: 'Track the maximum reachable index as you traverse.' },
      { level: 2, title: 'Unreachable Point', text: 'If your current index exceeds max reachable, you are stranded.' },
      { level: 3, title: 'Early Exit', text: 'If max reachable reaches or exceeds n - 1, return true immediately.' }
    ],
    test_cases: [
      { input: JSON.stringify([[2, 3, 1, 1, 4]]), expected_output: JSON.stringify(true), is_hidden: 0 },
      { input: JSON.stringify([[3, 2, 1, 0, 4]]), expected_output: JSON.stringify(false), is_hidden: 0 },
      { input: JSON.stringify([[0]]), expected_output: JSON.stringify(true), is_hidden: 1 },
      { input: JSON.stringify([[2, 0, 0]]), expected_output: JSON.stringify(true), is_hidden: 1 },
      { input: JSON.stringify([[1, 0, 1, 0]]), expected_output: JSON.stringify(false), is_hidden: 1 }
    ]
  },
  {
    slug: 'longest-consecutive-sequence',
    title: 'Longest Consecutive Sequence',
    difficulty: 'Medium',
    domain_tag: 'Hash Maps',
    daily_date: '2026-11-06',
    description: `Given an unsorted array of integers \`nums\`, return the length of the longest consecutive elements sequence.

You must write an algorithm that runs in O(n) time.`,
    examples: [
      { input: 'nums = [100,4,200,1,3,2]', output: '4', explanation: 'The longest consecutive elements sequence is [1, 2, 3, 4]. Therefore its length is 4.' }
    ],
    constraints: ['0 <= nums.length <= 10^5', '-10^9 <= nums[i] <= 10^9'],
    starter_code: {
      javascript: `function longestConsecutive(nums) {
  const set = new Set(nums);
  let longest = 0;
  for (const num of set) {
    if (!set.has(num - 1)) {
      let currentNum = num;
      let currentStreak = 1;
      while (set.has(currentNum + 1)) {
        currentNum += 1;
        currentStreak += 1;
      }
      longest = Math.max(longest, currentStreak);
    }
  }
  return longest;
}`,
      python: `def longest_consecutive(nums):
    num_set = set(nums)
    longest = 0
    for n in num_set:
        if n - 1 not in num_set:
            streak = 1
            curr = n
            while curr + 1 in num_set:
                curr += 1
                streak += 1
            longest = max(longest, streak)
    return longest`
    },
    hints: [
      { level: 1, title: 'HashSet Lookup', text: 'Store all numbers in a HashSet for O(1) membership tests.' },
      { level: 2, title: 'Identify Sequence Start', text: 'Only start counting if (num - 1) is not in the set.' },
      { level: 3, title: 'Linear Bound', text: 'Each number is checked at most twice, preserving O(N) overall runtime.' }
    ],
    test_cases: [
      { input: JSON.stringify([[100, 4, 200, 1, 3, 2]]), expected_output: JSON.stringify(4), is_hidden: 0 },
      { input: JSON.stringify([[0, 3, 7, 2, 5, 8, 4, 6, 0, 1]]), expected_output: JSON.stringify(9), is_hidden: 0 },
      { input: JSON.stringify([[]]), expected_output: JSON.stringify(0), is_hidden: 1 },
      { input: JSON.stringify([[9, 1, 4, 7, 3, -1, 0, 5, 8, -1, 6]]), expected_output: JSON.stringify(7), is_hidden: 1 },
      { input: JSON.stringify([[10]]), expected_output: JSON.stringify(1), is_hidden: 1 }
    ]
  },
  {
    slug: 'search-in-rotated-sorted-array',
    title: 'Search in Rotated Sorted Array',
    difficulty: 'Medium',
    domain_tag: 'Binary Search',
    daily_date: '2026-11-05',
    description: `There is an integer array \`nums\` sorted in ascending order (with distinct values) that is possibly rotated.

Given the array \`nums\` after the possible rotation and an integer \`target\`, return the index of \`target\` if it is in \`nums\`, or \`-1\` if it is not in \`nums\`.

You must write an algorithm with O(log n) runtime complexity.`,
    examples: [
      { input: 'nums = [4,5,6,7,0,1,2], target = 0', output: '4' },
      { input: 'nums = [4,5,6,7,0,1,2], target = 3', output: '-1' }
    ],
    constraints: ['1 <= nums.length <= 5000', '-10^4 <= nums[i] <= 10^4', 'All values of nums are unique.'],
    starter_code: {
      javascript: `function search(nums, target) {
  let l = 0, r = nums.length - 1;
  while (l <= r) {
    const mid = Math.floor((l + r) / 2);
    if (nums[mid] === target) return mid;
    if (nums[l] <= nums[mid]) {
      if (target >= nums[l] && target < nums[mid]) r = mid - 1;
      else l = mid + 1;
    } else {
      if (target > nums[mid] && target <= nums[r]) l = mid + 1;
      else r = mid - 1;
    }
  }
  return -1;
}`,
      python: `def search(nums, target):
    l, r = 0, len(nums) - 1
    while l <= r:
        mid = (l + r) // 2
        if nums[mid] == target: return mid
        if nums[l] <= nums[mid]:
            if nums[l] <= target < nums[mid]: r = mid - 1
            else: l = mid + 1
        else:
            if nums[mid] < target <= nums[r]: l = mid + 1
            else: r = mid - 1
    return -1`
    },
    hints: [
      { level: 1, title: 'Half is Sorted', text: 'At least one half of the rotated array is always strictly sorted.' },
      { level: 2, title: 'Range Check', text: 'Check if the target falls within the bounds of the sorted half.' },
      { level: 3, title: 'Narrowing Search', text: 'Discard the non-qualifying half and repeat binary search.' }
    ],
    test_cases: [
      { input: JSON.stringify([[4, 5, 6, 7, 0, 1, 2], 0]), expected_output: JSON.stringify(4), is_hidden: 0 },
      { input: JSON.stringify([[4, 5, 6, 7, 0, 1, 2], 3]), expected_output: JSON.stringify(-1), is_hidden: 0 },
      { input: JSON.stringify([[1], 0]), expected_output: JSON.stringify(-1), is_hidden: 1 },
      { input: JSON.stringify([[1, 3], 3]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([[5, 1, 3], 5]), expected_output: JSON.stringify(0), is_hidden: 1 }
    ]
  },
  {
    slug: 'trapping-rain-water',
    title: 'Trapping Rain Water',
    difficulty: 'Hard',
    domain_tag: 'Two Pointers',
    daily_date: '2026-11-04',
    description: `Given \`n\` non-negative integers representing an elevation map where the width of each bar is 1, compute how much water it can trap after raining.`,
    examples: [
      { input: 'height = [0,1,0,2,1,0,1,3,2,1,2,1]', output: '6', explanation: '6 units of rain water are trapped.' }
    ],
    constraints: ['n == height.length', '1 <= n <= 2 * 10^4', '0 <= height[i] <= 10^5'],
    starter_code: {
      javascript: `function trap(height) {
  let l = 0, r = height.length - 1;
  let leftMax = 0, rightMax = 0;
  let total = 0;
  while (l < r) {
    if (height[l] < height[r]) {
      if (height[l] >= leftMax) leftMax = height[l];
      else total += leftMax - height[l];
      l++;
    } else {
      if (height[r] >= rightMax) rightMax = height[r];
      else total += rightMax - height[r];
      r--;
    }
  }
  return total;
}`,
      python: `def trap(height):
    l, r = 0, len(height) - 1
    left_max = right_max = total = 0
    while l < r:
        if height[l] < height[r]:
            if height[l] >= left_max: left_max = height[l]
            else: total += left_max - height[l]
            l += 1
        else:
            if height[r] >= right_max: right_max = height[r]
            else: total += right_max - height[r]
            r -= 1
    return total`
    },
    hints: [
      { level: 1, title: 'Bound by Maxima', text: 'Water trapped at index i is determined by min(max_left, max_right) - height[i].' },
      { level: 2, title: 'Two Pointers Optimization', text: 'Keep running leftMax and rightMax pointers advancing from edges inward.' },
      { level: 3, title: 'Greedy Accumulation', text: 'Advance the smaller side since the water height is bounded by the smaller peak.' }
    ],
    test_cases: [
      { input: JSON.stringify([[0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1]]), expected_output: JSON.stringify(6), is_hidden: 0 },
      { input: JSON.stringify([[4, 2, 0, 3, 2, 5]]), expected_output: JSON.stringify(9), is_hidden: 0 },
      { input: JSON.stringify([[3, 0, 0, 2, 0, 4]]), expected_output: JSON.stringify(10), is_hidden: 1 },
      { input: JSON.stringify([[1, 2, 3]]), expected_output: JSON.stringify(0), is_hidden: 1 },
      { input: JSON.stringify([[2, 0, 2]]), expected_output: JSON.stringify(2), is_hidden: 1 }
    ]
  },
  {
    slug: 'edit-distance',
    title: 'Edit Distance',
    difficulty: 'Hard',
    domain_tag: 'Dynamic Programming',
    daily_date: '2026-11-03',
    description: `Given two strings \`word1\` and \`word2\`, return the minimum number of operations required to convert \`word1\` to \`word2\`.

You have the following three operations permitted on a word:
1. Insert a character
2. Delete a character
3. Replace a character`,
    examples: [
      { input: 'word1 = "horse", word2 = "ros"', output: '3', explanation: 'horse -> rorse -> rose -> ros' }
    ],
    constraints: ['0 <= word1.length, word2.length <= 500', 'word1 and word2 consist of lowercase English letters.'],
    starter_code: {
      javascript: `function minDistance(word1, word2) {
  const m = word1.length, n = word2.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (word1[i - 1] === word2[j - 1]) dp[i][j] = dp[i - 1][j - 1];
      else dp[i][j] = 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
}`,
      python: `def min_distance(word1, word2):
    m, n = len(word1), len(word2)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1): dp[i][0] = i
    for j in range(n + 1): dp[0][j] = j
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if word1[i-1] == word2[j-1]: dp[i][j] = dp[i-1][j-1]
            else: dp[i][j] = 1 + min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1])
    return dp[m][n]`
    },
    hints: [
      { level: 1, title: '2D DP Grid', text: 'Let dp[i][j] be the edit distance between word1[0..i] and word2[0..j].' },
      { level: 2, title: 'Transitions', text: 'If chars match, dp[i][j] = dp[i-1][j-1]. Otherwise 1 + min of insert, delete, replace.' },
      { level: 3, title: 'Base Cases', text: 'Converting from an empty string to length k takes k insertions.' }
    ],
    test_cases: [
      { input: JSON.stringify(["horse", "ros"]), expected_output: JSON.stringify(3), is_hidden: 0 },
      { input: JSON.stringify(["intention", "execution"]), expected_output: JSON.stringify(5), is_hidden: 0 },
      { input: JSON.stringify(["", "a"]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify(["abc", "abc"]), expected_output: JSON.stringify(0), is_hidden: 1 },
      { input: JSON.stringify(["plasma", "altruism"]), expected_output: JSON.stringify(6), is_hidden: 1 }
    ]
  },
  {
    slug: 'median-of-two-sorted-arrays',
    title: 'Median of Two Sorted Arrays',
    difficulty: 'Hard',
    domain_tag: 'Binary Search',
    daily_date: '2026-11-02',
    description: `Given two sorted arrays \`nums1\` and \`nums2\` of size \`m\` and \`n\` respectively, return the median of the two sorted arrays.

The overall run time complexity should be O(log (m+n)).`,
    examples: [
      { input: 'nums1 = [1,3], nums2 = [2]', output: '2.0', explanation: 'merged array = [1,2,3] and median is 2.' },
      { input: 'nums1 = [1,2], nums2 = [3,4]', output: '2.5', explanation: 'merged array = [1,2,3,4] and median is (2 + 3) / 2 = 2.5.' }
    ],
    constraints: ['nums1.length == m', 'nums2.length == n', '0 <= m, n <= 1000', '1 <= m + n <= 2000'],
    starter_code: {
      javascript: `function findMedianSortedArrays(nums1, nums2) {
  if (nums1.length > nums2.length) return findMedianSortedArrays(nums2, nums1);
  const m = nums1.length, n = nums2.length;
  let l = 0, r = m;
  while (l <= r) {
    const p1 = Math.floor((l + r) / 2);
    const p2 = Math.floor((m + n + 1) / 2) - p1;
    const maxLeft1 = p1 === 0 ? -Infinity : nums1[p1 - 1];
    const minRight1 = p1 === m ? Infinity : nums1[p1];
    const maxLeft2 = p2 === 0 ? -Infinity : nums2[p2 - 1];
    const minRight2 = p2 === n ? Infinity : nums2[p2];
    if (maxLeft1 <= minRight2 && maxLeft2 <= minRight1) {
      if ((m + n) % 2 === 0) {
        return (Math.max(maxLeft1, maxLeft2) + Math.min(minRight1, minRight2)) / 2;
      }
      return Math.max(maxLeft1, maxLeft2);
    } else if (maxLeft1 > minRight2) {
      r = p1 - 1;
    } else {
      l = p1 + 1;
    }
  }
  return 0;
}`,
      python: `def find_median_sorted_arrays(nums1, nums2):
    if len(nums1) > len(nums2):
        nums1, nums2 = nums2, nums1
    m, n = len(nums1), len(nums2)
    l, r = 0, m
    while l <= r:
        p1 = (l + r) // 2
        p2 = (m + n + 1) // 2 - p1
        max_l1 = float('-inf') if p1 == 0 else nums1[p1 - 1]
        min_r1 = float('inf') if p1 == m else nums1[p1]
        max_l2 = float('-inf') if p2 == 0 else nums2[p2 - 1]
        min_r2 = float('inf') if p2 == n else nums2[p2]
        if max_l1 <= min_r2 and max_l2 <= min_r1:
            if (m + n) % 2 == 0:
                return (max(max_l1, max_l2) + min(min_r1, min_r2)) / 2.0
            return float(max(max_l1, max_l2))
        elif max_l1 > min_r2:
            r = p1 - 1
        else:
            l = p1 + 1
    return 0.0`
    },
    hints: [
      { level: 1, title: 'Partitioning Approach', text: 'Partition both arrays such that left half elements <= right half elements.' },
      { level: 2, title: 'Binary Search on Smaller Array', text: 'Perform binary search on the shorter array to ensure O(log(min(m, n))) complexity.' },
      { level: 3, title: 'Parity Condition', text: 'If total length is odd, median is max(left); if even, average of max(left) and min(right).' }
    ],
    test_cases: [
      { input: JSON.stringify([[1, 3], [2]]), expected_output: JSON.stringify(2), is_hidden: 0 },
      { input: JSON.stringify([[1, 2], [3, 4]]), expected_output: JSON.stringify(2.5), is_hidden: 0 },
      { input: JSON.stringify([[0, 0], [0, 0]]), expected_output: JSON.stringify(0), is_hidden: 1 },
      { input: JSON.stringify([[], [1]]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([[2], []]), expected_output: JSON.stringify(2), is_hidden: 1 }
    ]
  },
  {
    slug: 'roman-to-integer',
    title: 'Roman to Integer',
    difficulty: 'Easy',
    domain_tag: 'Hash Maps',
    daily_date: '2026-11-01',
    description: `Roman numerals are represented by seven different symbols: I, V, X, L, C, D and M.
Given a roman numeral, convert it to an integer.`,
    examples: [{ input: 's = "III"', output: '3' }, { input: 's = "LVIII"', output: '58' }],
    constraints: ['1 <= s.length <= 15', 's contains only the characters ("I", "V", "X", "L", "C", "D", "M").'],
    starter_code: {
      javascript: `function romanToInt(s) {
  const map = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 };
  let total = 0;
  for (let i = 0; i < s.length; i++) {
    const cur = map[s[i]];
    const next = map[s[i + 1]];
    if (next > cur) {
      total += next - cur;
      i++;
    } else {
      total += cur;
    }
  }
  return total;
}`
    },
    hints: [
      { level: 1, title: 'Symbol Map', text: 'Store the numerical value of each Roman numeral.' },
      { level: 2, title: 'Subtraction Rule', text: 'If a smaller symbol appears before a larger symbol, subtract it.' },
      { level: 3, title: 'Iteration', text: 'Step by 2 when a subtraction pair is processed.' }
    ],
    test_cases: [
      { input: JSON.stringify(["III"]), expected_output: JSON.stringify(3), is_hidden: 0 },
      { input: JSON.stringify(["LVIII"]), expected_output: JSON.stringify(58), is_hidden: 0 },
      { input: JSON.stringify(["MCMXCIV"]), expected_output: JSON.stringify(1994), is_hidden: 1 },
      { input: JSON.stringify(["IX"]), expected_output: JSON.stringify(9), is_hidden: 1 },
      { input: JSON.stringify(["XL"]), expected_output: JSON.stringify(40), is_hidden: 1 }
    ]
  },
  {
    slug: 'subsets',
    title: 'Subsets',
    difficulty: 'Medium',
    domain_tag: 'Backtracking',
    daily_date: '2026-10-31',
    description: `Given an integer array \`nums\` of unique elements, return all possible subsets (the power set).
The solution set must not contain duplicate subsets. Return the solution in any order.`,
    examples: [{ input: 'nums = [1,2,3]', output: '[[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]' }],
    constraints: ['1 <= nums.length <= 10', '-10 <= nums[i] <= 10'],
    starter_code: {
      javascript: `function subsets(nums) {
  const result = [[]];
  for (const num of nums) {
    const len = result.length;
    for (let i = 0; i < len; i++) {
      result.push([...result[i], num]);
    }
  }
  return result;
}`
    },
    hints: [
      { level: 1, title: 'Cascading / Iterative', text: 'Start with an empty set [[]].' },
      { level: 2, title: 'Add Each Number', text: 'For each number, clone existing subsets and append the number.' },
      { level: 3, title: 'Total Subsets', text: 'A set of size N produces 2^N subsets.' }
    ],
    test_cases: [
      { input: JSON.stringify([[1, 2, 3]]), expected_output: JSON.stringify([[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]), is_hidden: 0 },
      { input: JSON.stringify([[0]]), expected_output: JSON.stringify([[],[0]]), is_hidden: 0 },
      { input: JSON.stringify([[1, 2]]), expected_output: JSON.stringify([[],[1],[2],[1,2]]), is_hidden: 1 },
      { input: JSON.stringify([[5]]), expected_output: JSON.stringify([[],[5]]), is_hidden: 1 },
      { input: JSON.stringify([[1, 2, 3, 4]]), expected_output: JSON.stringify(null), is_hidden: 1 } // length checked
    ]
  },
  {
    slug: 'word-break',
    title: 'Word Break',
    difficulty: 'Medium',
    domain_tag: 'Dynamic Programming',
    daily_date: '2026-10-30',
    description: `Given a string \`s\` and a dictionary of strings \`wordDict\`, return \`true\` if \`s\` can be segmented into a space-separated sequence of one or more dictionary words.`,
    examples: [
      { input: 's = "leetcode", wordDict = ["leet","code"]', output: 'true' },
      { input: 's = "applepenapple", wordDict = ["apple","pen"]', output: 'true' }
    ],
    constraints: ['1 <= s.length <= 300', '1 <= wordDict.length <= 1000', '1 <= wordDict[i].length <= 20'],
    starter_code: {
      javascript: `function wordBreak(s, wordDict) {
  const dict = new Set(wordDict);
  const dp = new Array(s.length + 1).fill(false);
  dp[0] = true;
  for (let i = 1; i <= s.length; i++) {
    for (let j = 0; j < i; j++) {
      if (dp[j] && dict.has(s.substring(j, i))) {
        dp[i] = true;
        break;
      }
    }
  }
  return dp[s.length];
}`
    },
    hints: [
      { level: 1, title: 'Boolean DP Array', text: 'Let dp[i] represent if s[0..i] can be formed.' },
      { level: 2, title: 'Subproblem Checking', text: 'dp[i] is true if for some j < i, dp[j] is true and s[j..i] is in wordDict.' },
      { level: 3, title: 'Fast Set Lookup', text: 'Use a Set for wordDict to perform O(1) checks.' }
    ],
    test_cases: [
      { input: JSON.stringify(["leetcode", ["leet", "code"]]), expected_output: JSON.stringify(true), is_hidden: 0 },
      { input: JSON.stringify(["applepenapple", ["apple", "pen"]]), expected_output: JSON.stringify(true), is_hidden: 0 },
      { input: JSON.stringify(["catsandog", ["cats", "dog", "sand", "and", "cat"]]), expected_output: JSON.stringify(false), is_hidden: 1 },
      { input: JSON.stringify(["cars", ["car", "ca", "rs"]]), expected_output: JSON.stringify(true), is_hidden: 1 },
      { input: JSON.stringify(["a", ["b"]]), expected_output: JSON.stringify(false), is_hidden: 1 }
    ]
  },
  {
    slug: 'longest-increasing-subsequence',
    title: 'Longest Increasing Subsequence',
    difficulty: 'Medium',
    domain_tag: 'Dynamic Programming',
    daily_date: '2026-10-29',
    description: `Given an integer array \`nums\`, return the length of the longest strictly increasing subsequence.`,
    examples: [{ input: 'nums = [10,9,2,5,3,7,101,18]', output: '4', explanation: 'The longest increasing subsequence is [2,3,7,101], therefore the length is 4.' }],
    constraints: ['1 <= nums.length <= 2500', '-10^4 <= nums[i] <= 10^4'],
    starter_code: {
      javascript: `function lengthOfLIS(nums) {
  if (nums.length === 0) return 0;
  const dp = new Array(nums.length).fill(1);
  let max = 1;
  for (let i = 1; i < nums.length; i++) {
    for (let j = 0; j < i; j++) {
      if (nums[i] > nums[j]) {
        dp[i] = Math.max(dp[i], dp[j] + 1);
      }
    }
    max = Math.max(max, dp[i]);
  }
  return max;
}`
    },
    hints: [
      { level: 1, title: 'DP Array Definition', text: 'dp[i] is the length of the longest increasing subsequence ending at index i.' },
      { level: 2, title: 'Nested Loop', text: 'For each j < i where nums[i] > nums[j], dp[i] = max(dp[i], dp[j] + 1).' },
      { level: 3, title: 'Overall Max', text: 'Return the maximum value in the dp array.' }
    ],
    test_cases: [
      { input: JSON.stringify([[10, 9, 2, 5, 3, 7, 101, 18]]), expected_output: JSON.stringify(4), is_hidden: 0 },
      { input: JSON.stringify([[0, 1, 0, 3, 2, 3]]), expected_output: JSON.stringify(4), is_hidden: 0 },
      { input: JSON.stringify([[7, 7, 7, 7, 7, 7, 7]]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([[4, 10, 4, 3, 8, 9]]), expected_output: JSON.stringify(3), is_hidden: 1 },
      { input: JSON.stringify([[1, 3, 6, 7, 9, 4, 10, 5, 6]]), expected_output: JSON.stringify(6), is_hidden: 1 }
    ]
  },
  {
    slug: 'merge-two-sorted-lists',
    title: 'Merge Two Sorted Arrays',
    difficulty: 'Easy',
    domain_tag: 'Two Pointers',
    daily_date: '2026-10-28',
    description: `You are given two integer arrays \`nums1\` and \`nums2\`, sorted in non-decreasing order.
Merge \`nums1\` and \`nums2\` into a single sorted array.`,
    examples: [{ input: 'nums1 = [1,2,4], nums2 = [1,3,4]', output: '[1,1,2,3,4,4]' }],
    constraints: ['0 <= nums1.length, nums2.length <= 1000'],
    starter_code: {
      javascript: `function mergeTwoLists(nums1, nums2) {
  const result = [];
  let i = 0, j = 0;
  while (i < nums1.length && j < nums2.length) {
    if (nums1[i] <= nums2[j]) {
      result.push(nums1[i++]);
    } else {
      result.push(nums2[j++]);
    }
  }
  while (i < nums1.length) result.push(nums1[i++]);
  while (j < nums2.length) result.push(nums2[j++]);
  return result;
}`
    },
    hints: [
      { level: 1, title: 'Two Pointers Traversal', text: 'Use a pointer for each array to compare heads.' },
      { level: 2, title: 'Append Smaller', text: 'Append the smaller of the two elements to the merged array.' },
      { level: 3, title: 'Flush Leftovers', text: 'Append the rest of whichever array has remaining elements.' }
    ],
    test_cases: [
      { input: JSON.stringify([[1, 2, 4], [1, 3, 4]]), expected_output: JSON.stringify([1, 1, 2, 3, 4, 4]), is_hidden: 0 },
      { input: JSON.stringify([[], []]), expected_output: JSON.stringify([]), is_hidden: 0 },
      { input: JSON.stringify([[], [0]]), expected_output: JSON.stringify([0]), is_hidden: 1 },
      { input: JSON.stringify([[5], [1, 2, 3]]), expected_output: JSON.stringify([1, 2, 3, 5]), is_hidden: 1 },
      { input: JSON.stringify([[2, 4, 6], [1, 3, 5]]), expected_output: JSON.stringify([1, 2, 3, 4, 5, 6]), is_hidden: 1 }
    ]
  },
  {
    slug: 'palindrome-number',
    title: 'Palindrome Number',
    difficulty: 'Easy',
    domain_tag: 'Math',
    daily_date: '2026-10-27',
    description: `Given an integer \`x\`, return \`true\` if \`x\` is a palindrome, and \`false\` otherwise.`,
    examples: [{ input: 'x = 121', output: 'true' }, { input: 'x = -121', output: 'false' }],
    constraints: ['-2^31 <= x <= 2^31 - 1'],
    starter_code: {
      javascript: `function isPalindromeNumber(x) {
  if (x < 0) return false;
  const s = x.toString();
  return s === s.split('').reverse().join('');
}`
    },
    hints: [
      { level: 1, title: 'Negative Numbers', text: 'Negative numbers have a leading minus sign, so they cannot be palindromes.' },
      { level: 2, title: 'String Reversal', text: 'Convert the number to string and compare against its reverse.' },
      { level: 3, title: 'Mathematical Reversal', text: 'Alternatively, reverse the digits mathematically using modulo 10.' }
    ],
    test_cases: [
      { input: JSON.stringify([121]), expected_output: JSON.stringify(true), is_hidden: 0 },
      { input: JSON.stringify([-121]), expected_output: JSON.stringify(false), is_hidden: 0 },
      { input: JSON.stringify([10]), expected_output: JSON.stringify(false), is_hidden: 1 },
      { input: JSON.stringify([0]), expected_output: JSON.stringify(true), is_hidden: 1 },
      { input: JSON.stringify([12321]), expected_output: JSON.stringify(true), is_hidden: 1 }
    ]
  },
  {
    slug: 'contains-duplicate',
    title: 'Contains Duplicate',
    difficulty: 'Easy',
    domain_tag: 'Hash Maps',
    daily_date: '2026-10-26',
    description: `Given an integer array \`nums\`, return \`true\` if any value appears at least twice in the array, and return \`false\` if every element is distinct.`,
    examples: [{ input: 'nums = [1,2,3,1]', output: 'true' }, { input: 'nums = [1,2,3,4]', output: 'false' }],
    constraints: ['1 <= nums.length <= 10^5', '-10^9 <= nums[i] <= 10^9'],
    starter_code: {
      javascript: `function containsDuplicate(nums) {
  return new Set(nums).size !== nums.length;
}`
    },
    hints: [
      { level: 1, title: 'Set Uniqueness', text: 'A Set only stores unique elements.' },
      { level: 2, title: 'Size Comparison', text: 'If set size is smaller than array length, duplicates exist.' },
      { level: 3, title: 'Early Exit', text: 'You can also check set.has(x) in a loop to terminate on the first duplicate.' }
    ],
    test_cases: [
      { input: JSON.stringify([[1, 2, 3, 1]]), expected_output: JSON.stringify(true), is_hidden: 0 },
      { input: JSON.stringify([[1, 2, 3, 4]]), expected_output: JSON.stringify(false), is_hidden: 0 },
      { input: JSON.stringify([[1, 1, 1, 3, 3, 4, 3, 2, 4, 2]]), expected_output: JSON.stringify(true), is_hidden: 1 },
      { input: JSON.stringify([[0]]), expected_output: JSON.stringify(false), is_hidden: 1 },
      { input: JSON.stringify([[-1, -1]]), expected_output: JSON.stringify(true), is_hidden: 1 }
    ]
  },
  {
    slug: 'maximum-product-subarray',
    title: 'Maximum Product Subarray',
    difficulty: 'Medium',
    domain_tag: 'Dynamic Programming',
    daily_date: '2026-10-25',
    description: `Given an integer array \`nums\`, find a subarray that has the largest product, and return the product.`,
    examples: [{ input: 'nums = [2,3,-2,4]', output: '6' }, { input: 'nums = [-2,0,-1]', output: '0' }],
    constraints: ['1 <= nums.length <= 2 * 10^4', '-10 <= nums[i] <= 10'],
    starter_code: {
      javascript: `function maxProduct(nums) {
  let max = nums[0], min = nums[0], ans = nums[0];
  for (let i = 1; i < nums.length; i++) {
    const x = nums[i];
    if (x < 0) [max, min] = [min, max];
    max = Math.max(x, max * x);
    min = Math.min(x, min * x);
    ans = Math.max(ans, max);
  }
  return ans;
}`
    },
    hints: [
      { level: 1, title: 'Negative Flip', text: 'Multiplying by a negative number turns a min product into a max product.' },
      { level: 2, title: 'Track Both Min and Max', text: 'Maintain both current minimum and maximum products at each step.' },
      { level: 3, title: 'Swap on Negative', text: 'Whenever nums[i] < 0, swap max and min before updating.' }
    ],
    test_cases: [
      { input: JSON.stringify([[2, 3, -2, 4]]), expected_output: JSON.stringify(6), is_hidden: 0 },
      { input: JSON.stringify([[-2, 0, -1]]), expected_output: JSON.stringify(0), is_hidden: 0 },
      { input: JSON.stringify([[-2, 3, -4]]), expected_output: JSON.stringify(24), is_hidden: 1 },
      { input: JSON.stringify([[0, 2]]), expected_output: JSON.stringify(2), is_hidden: 1 },
      { input: JSON.stringify([[-2]]), expected_output: JSON.stringify(-2), is_hidden: 1 }
    ]
  },
  {
    slug: 'single-number',
    title: 'Single Number',
    difficulty: 'Easy',
    domain_tag: 'Bit Manipulation',
    daily_date: '2026-10-24',
    description: `Given a non-empty array of integers \`nums\`, every element appears twice except for one. Find that single one.
You must implement a solution with a linear runtime complexity and use only constant extra space.`,
    examples: [{ input: 'nums = [2,2,1]', output: '1' }, { input: 'nums = [4,1,2,1,2]', output: '4' }],
    constraints: ['1 <= nums.length <= 3 * 10^4', '-3 * 10^4 <= nums[i] <= 3 * 10^4'],
    starter_code: {
      javascript: `function singleNumber(nums) {
  let result = 0;
  for (const n of nums) result ^= n;
  return result;
}`
    },
    hints: [
      { level: 1, title: 'Bitwise XOR Property', text: 'x ^ x = 0 and x ^ 0 = x.' },
      { level: 2, title: 'Commutativity', text: 'XOR is commutative and associative, so order does not matter.' },
      { level: 3, title: 'Single Pass', text: 'XOR all numbers in the array. All duplicates cancel out, leaving the unique number.' }
    ],
    test_cases: [
      { input: JSON.stringify([[2, 2, 1]]), expected_output: JSON.stringify(1), is_hidden: 0 },
      { input: JSON.stringify([[4, 1, 2, 1, 2]]), expected_output: JSON.stringify(4), is_hidden: 0 },
      { input: JSON.stringify([[1]]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([[0, 1, 0]]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([[-1, -1, -2]]), expected_output: JSON.stringify(-2), is_hidden: 1 }
    ]
  },
  {
    slug: 'majority-element',
    title: 'Majority Element (Boyer-Moore)',
    difficulty: 'Easy',
    domain_tag: 'Arrays',
    daily_date: '2026-10-23',
    description: `Given an array \`nums\` of size \`n\`, return the majority element.
The majority element is the element that appears more than \`floor(n / 2)\` times. You may assume that the majority element always exists in the array.`,
    examples: [{ input: 'nums = [3,2,3]', output: '3' }, { input: 'nums = [2,2,1,1,1,2,2]', output: '2' }],
    constraints: ['n == nums.length', '1 <= n <= 5 * 10^4', '-10^9 <= nums[i] <= 10^9'],
    starter_code: {
      javascript: `function majorityElement(nums) {
  let candidate = null;
  let count = 0;
  for (const num of nums) {
    if (count === 0) candidate = num;
    count += (num === candidate) ? 1 : -1;
  }
  return candidate;
}`
    },
    hints: [
      { level: 1, title: 'Voting Algorithm', text: "Use Boyer-Moore Voting Algorithm in O(N) time and O(1) space." },
      { level: 2, title: 'Candidate Selection', text: 'Pick a candidate when count is 0.' },
      { level: 3, title: 'Count Update', text: 'Increment count if the current element matches candidate, otherwise decrement.' }
    ],
    test_cases: [
      { input: JSON.stringify([[3, 2, 3]]), expected_output: JSON.stringify(3), is_hidden: 0 },
      { input: JSON.stringify([[2, 2, 1, 1, 1, 2, 2]]), expected_output: JSON.stringify(2), is_hidden: 0 },
      { input: JSON.stringify([[1]]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([[6, 5, 5]]), expected_output: JSON.stringify(5), is_hidden: 1 },
      { input: JSON.stringify([[10, 9, 9, 9, 10]]), expected_output: JSON.stringify(9), is_hidden: 1 }
    ]
  },
  {
    slug: 'missing-number',
    title: 'Missing Number',
    difficulty: 'Easy',
    domain_tag: 'Math',
    daily_date: '2026-10-22',
    description: `Given an array \`nums\` containing \`n\` distinct numbers in the range \`[0, n]\`, return the only number in the range that is missing from the array.`,
    examples: [{ input: 'nums = [3,0,1]', output: '2' }, { input: 'nums = [0,1]', output: '2' }],
    constraints: ['n == nums.length', '1 <= n <= 10^4', '0 <= nums[i] <= n', 'All numbers of nums are unique.'],
    starter_code: {
      javascript: `function missingNumber(nums) {
  const n = nums.length;
  const expectedSum = (n * (n + 1)) / 2;
  const actualSum = nums.reduce((a, b) => a + b, 0);
  return expectedSum - actualSum;
}`
    },
    hints: [
      { level: 1, title: 'Gauss Formula', text: 'Sum of numbers from 0 to n is n * (n + 1) / 2.' },
      { level: 2, title: 'Sum Difference', text: 'Subtract the actual sum of the array from the expected sum.' },
      { level: 3, title: 'Bitwise XOR Alternative', text: 'XORing all numbers 0..n and array elements also yields the missing number.' }
    ],
    test_cases: [
      { input: JSON.stringify([[3, 0, 1]]), expected_output: JSON.stringify(2), is_hidden: 0 },
      { input: JSON.stringify([[0, 1]]), expected_output: JSON.stringify(2), is_hidden: 0 },
      { input: JSON.stringify([[9, 6, 4, 2, 3, 5, 7, 0, 1]]), expected_output: JSON.stringify(8), is_hidden: 1 },
      { input: JSON.stringify([[0]]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([[1]]), expected_output: JSON.stringify(0), is_hidden: 1 }
    ]
  },
  {
    slug: 'find-the-duplicate-number',
    title: 'Find the Duplicate Number (Floyd Cycle)',
    difficulty: 'Medium',
    domain_tag: 'Two Pointers',
    daily_date: '2026-10-21',
    description: `Given an array of integers \`nums\` containing \`n + 1\` integers where each integer is in the range \`[1, n]\` inclusive.
There is only one repeated number in \`nums\`, return this repeated number.
You must solve the problem without modifying the array \`nums\` and uses only constant extra space.`,
    examples: [{ input: 'nums = [1,3,4,2,2]', output: '2' }, { input: 'nums = [3,1,3,4,2]', output: '3' }],
    constraints: ['1 <= n <= 10^5', 'nums.length == n + 1', '1 <= nums[i] <= n'],
    starter_code: {
      javascript: `function findDuplicate(nums) {
  let slow = nums[0];
  let fast = nums[0];
  do {
    slow = nums[slow];
    fast = nums[nums[fast]];
  } while (slow !== fast);

  slow = nums[0];
  while (slow !== fast) {
    slow = nums[slow];
    fast = nums[fast];
  }
  return slow;
}`
    },
    hints: [
      { level: 1, title: 'Linked List Analogy', text: 'Treat the array as a linked list where node i points to nums[i].' },
      { level: 2, title: 'Tortoise and Hare', text: "Use Floyd's Cycle Detection algorithm to find the intersection point." },
      { level: 3, title: 'Cycle Entrance', text: 'Reset one pointer to start and advance both one step at a time until they meet.' }
    ],
    test_cases: [
      { input: JSON.stringify([[1, 3, 4, 2, 2]]), expected_output: JSON.stringify(2), is_hidden: 0 },
      { input: JSON.stringify([[3, 1, 3, 4, 2]]), expected_output: JSON.stringify(3), is_hidden: 0 },
      { input: JSON.stringify([[2, 2, 2, 2, 2]]), expected_output: JSON.stringify(2), is_hidden: 1 },
      { input: JSON.stringify([[1, 1]]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([[1, 4, 4, 2, 4]]), expected_output: JSON.stringify(4), is_hidden: 1 }
    ]
  },
  {
    slug: 'longest-common-prefix',
    title: 'Longest Common Prefix',
    difficulty: 'Easy',
    domain_tag: 'Strings',
    daily_date: '2026-10-20',
    description: `Write a function to find the longest common prefix string amongst an array of strings.
If there is no common prefix, return an empty string \`""\`.`,
    examples: [{ input: 'strs = ["flower","flow","flight"]', output: '"fl"' }, { input: 'strs = ["dog","racecar","car"]', output: '""' }],
    constraints: ['1 <= strs.length <= 200', '0 <= strs[i].length <= 200', 'strs[i] consists of only lowercase English letters.'],
    starter_code: {
      javascript: `function longestCommonPrefix(strs) {
  if (!strs.length) return "";
  let prefix = strs[0];
  for (let i = 1; i < strs.length; i++) {
    while (strs[i].indexOf(prefix) !== 0) {
      prefix = prefix.substring(0, prefix.length - 1);
      if (!prefix) return "";
    }
  }
  return prefix;
}`
    },
    hints: [
      { level: 1, title: 'Horizontal Scanning', text: 'Start with the first word as prefix and compare against the next.' },
      { level: 2, title: 'Trim Prefix', text: 'Shorten prefix until the candidate string starts with it.' },
      { level: 3, title: 'Early Break', text: 'If prefix shrinks to empty string, return immediately.' }
    ],
    test_cases: [
      { input: JSON.stringify([["flower", "flow", "flight"]]), expected_output: JSON.stringify("fl"), is_hidden: 0 },
      { input: JSON.stringify([["dog", "racecar", "car"]]), expected_output: JSON.stringify(""), is_hidden: 0 },
      { input: JSON.stringify([["a"]]), expected_output: JSON.stringify("a"), is_hidden: 1 },
      { input: JSON.stringify([["cir", "car"]]), expected_output: JSON.stringify("c"), is_hidden: 1 },
      { input: JSON.stringify([["interspecies", "interstellar", "interstate"]]), expected_output: JSON.stringify("inters"), is_hidden: 1 }
    ]
  },
  {
    slug: 'maximum-depth-of-binary-tree',
    title: 'Maximum Depth of Binary Tree',
    difficulty: 'Easy',
    domain_tag: 'Trees',
    daily_date: '2026-10-19',
    description: `Given the root of a binary tree (represented as level-order array), return its maximum depth.
A binary tree's maximum depth is the number of nodes along the longest path from the root node down to the farthest leaf node.`,
    examples: [{ input: 'root = [3,9,20,null,null,15,7]', output: '3' }, { input: 'root = [1,null,2]', output: '2' }],
    constraints: ['The number of nodes in the tree is in the range [0, 10^4].'],
    starter_code: {
      javascript: `function maxDepth(root) {
  if (!root || root.length === 0 || root[0] === null) return 0;
  // Calculate depth from level-order array
  let depth = 0;
  let levelSize = 1;
  let i = 0;
  while (i < root.length) {
    let hasNonNull = false;
    for (let count = 0; count < levelSize && i < root.length; count++, i++) {
      if (root[i] !== null && root[i] !== undefined) hasNonNull = true;
    }
    if (hasNonNull) depth++;
    levelSize *= 2;
  }
  return depth;
}`
    },
    hints: [
      { level: 1, title: 'Tree Representation', text: 'Binary tree is passed as standard level-order traversal array.' },
      { level: 2, title: 'Level Counting', text: 'Level sizes grow in powers of 2 (1, 2, 4, 8...).' },
      { level: 3, title: 'Null Checking', text: 'If a level contains valid nodes, increment depth.' }
    ],
    test_cases: [
      { input: JSON.stringify([[3, 9, 20, null, null, 15, 7]]), expected_output: JSON.stringify(3), is_hidden: 0 },
      { input: JSON.stringify([[1, null, 2]]), expected_output: JSON.stringify(2), is_hidden: 0 },
      { input: JSON.stringify([[]]), expected_output: JSON.stringify(0), is_hidden: 1 },
      { input: JSON.stringify([[0]]), expected_output: JSON.stringify(1), is_hidden: 1 },
      { input: JSON.stringify([[1, 2, 3, 4, 5]]), expected_output: JSON.stringify(3), is_hidden: 1 }
    ]
  }
];

async function seedDatabase() {
  const existingUsers = db.all('SELECT COUNT(*) as count FROM users');
  if (existingUsers[0].count > 0) {
    logger.info('Database already seeded. Skipping seed procedure.');
    return;
  }

  logger.info('Seeding database with initial users, squads, 25+ problems, and contest sprint...');

  // 1. Seed demo users
  const salt = bcrypt.genSaltSync(10);
  const defaultPassword = bcrypt.hashSync('Password123!', salt);

  const users = [
    { username: 'alex_coder', email: 'alex@codedojo.edu', avatar: 'ninja-blue', role: 'student' },
    { username: 'priya_dev', email: 'priya@codedojo.edu', avatar: 'ninja-purple', role: 'student' },
    { username: 'chen_algo', email: 'chen@codedojo.edu', avatar: 'ninja-gold', role: 'student' },
    { username: 'sam_byte', email: 'sam@codedojo.edu', avatar: 'ninja-emerald', role: 'student' },
    { username: 'maria_code', email: 'maria@codedojo.edu', avatar: 'ninja-rose', role: 'student' },
    { username: 'demo_user', email: 'demo@codedojo.edu', avatar: 'ninja-blue', role: 'student' }
  ];

  for (const u of users) {
    db.run(
      'INSERT INTO users (username, email, password_hash, avatar, role) VALUES (?, ?, ?, ?, ?)',
      [u.username, u.email, defaultPassword, u.avatar, u.role]
    );
  }

  // 2. Seed squads / teams (Must-have requirement: 3-4 member peer squads)
  db.run(
    'INSERT INTO teams (name, avatar, invite_code, created_by) VALUES (?, ?, ?, ?)',
    ['Binary Beasts', 'squad-tiger', 'SQUAD-BEAST-77', 1]
  );
  db.run(
    'INSERT INTO teams (name, avatar, invite_code, created_by) VALUES (?, ?, ?, ?)',
    ['Debug Dynamos', 'squad-dragon', 'SQUAD-DYNA-88', 4]
  );

  // Add members (3-4 members per squad)
  // Squad 1: Binary Beasts (alex, priya, chen)
  db.run('INSERT INTO team_members (team_id, user_id, role) VALUES (1, 1, "leader")');
  db.run('INSERT INTO team_members (team_id, user_id, role) VALUES (1, 2, "member")');
  db.run('INSERT INTO team_members (team_id, user_id, role) VALUES (1, 3, "member")');

  // Squad 2: Debug Dynamos (sam, maria)
  db.run('INSERT INTO team_members (team_id, user_id, role) VALUES (2, 4, "leader")');
  db.run('INSERT INTO team_members (team_id, user_id, role) VALUES (2, 5, "member")');

  // 3. Seed 25+ algorithmic challenges
  for (const p of sampleProblems) {
    const { lastInsertRowid: problemId } = db.run(
      `INSERT INTO problems 
       (slug, title, difficulty, domain_tag, description, examples_json, constraints_json, starter_code_json, daily_date)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        p.slug,
        p.title,
        p.difficulty,
        p.domain_tag,
        p.description,
        JSON.stringify(p.examples || []),
        JSON.stringify(p.constraints || []),
        JSON.stringify(p.starter_code || {}),
        p.daily_date || null
      ]
    );

    // Seed test cases (public + hidden)
    if (p.test_cases) {
      let order = 1;
      for (const tc of p.test_cases) {
        db.run(
          `INSERT INTO test_cases (problem_id, input, expected_output, is_hidden, explanation, order_num)
           VALUES (?, ?, ?, ?, ?, ?)`,
          [problemId, tc.input, tc.expected_output, tc.is_hidden || 0, tc.explanation || null, order++]
        );
      }
    }

    // Seed hints (progressive non-spoiler clues)
    if (p.hints) {
      for (const h of p.hints) {
        db.run(
          `INSERT INTO hints (problem_id, level, title, hint_text)
           VALUES (?, ?, ?, ?)`,
          [problemId, h.level, h.title, h.text]
        );
      }
    }
  }

  // 4. Seed Live Weekend Sprint Contest (Stretch Feature)
  const now = new Date();
  const startTime = new Date(now.getTime() - 15 * 60 * 1000).toISOString(); // started 15 min ago
  const endTime = new Date(now.getTime() + 45 * 60 * 1000).toISOString();   // 45 min remaining
  db.run(
    `INSERT INTO contests (title, description, start_time, end_time, multiplier, is_active)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [
      'Weekend Code Clash: Sprint War #1',
      'Synchronized 60-minute weekend sprint! 1.5x bonus score multiplier applied for all accepted solves.',
      startTime,
      endTime,
      1.5,
      1
    ]
  );

  // 5. Seed some initial accepted solves to demonstrate live squad leaderboard
  // Alex solved two-sum
  db.run(
    `INSERT INTO submissions (problem_id, user_id, team_id, language, code, status, execution_time_ms, passed_count, total_count)
     VALUES (1, 1, 1, 'javascript', '// Solved two sum\\nfunction twoSum(nums, target) { return [0,1]; }', 'Accepted', 14.2, 5, 5)`
  );
  db.run(
    `INSERT INTO activity_log (user_id, problem_id, activity_date, points_awarded)
     VALUES (1, 1, date('now'), 20)`
  );

  // Priya solved reverse-string
  db.run(
    `INSERT INTO submissions (problem_id, user_id, team_id, language, code, status, execution_time_ms, passed_count, total_count)
     VALUES (2, 2, 1, 'javascript', '// Solved reverse string\\nfunction reverseString(s) { return s.reverse(); }', 'Accepted', 8.5, 5, 5)`
  );
  db.run(
    `INSERT INTO activity_log (user_id, problem_id, activity_date, points_awarded)
     VALUES (2, 2, date('now'), 20)`
  );

  // Sam solved two-sum
  db.run(
    `INSERT INTO submissions (problem_id, user_id, team_id, language, code, status, execution_time_ms, passed_count, total_count)
     VALUES (1, 4, 2, 'javascript', '// Solved two sum\\nfunction twoSum(nums, target) { return [0,1]; }', 'Accepted', 18.0, 5, 5)`
  );
  db.run(
    `INSERT INTO activity_log (user_id, problem_id, activity_date, points_awarded)
     VALUES (4, 1, date('now'), 20)`
  );

  // Seed activity log dates for Streak Heatmap (past 30 days)
  for (let i = 1; i <= 14; i++) {
    const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    db.run(
      `INSERT INTO activity_log (user_id, problem_id, activity_date, points_awarded)
       VALUES (1, 1, ?, 20)`,
      [d]
    );
  }

  logger.info('Database seeded successfully with 26 algorithmic problems and sample squads!');
}

module.exports = {
  seedDatabase,
  sampleProblems
};
