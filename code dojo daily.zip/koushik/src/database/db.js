const fs = require('fs');
const path = require('path');
const initSqlJs = require('sql.js');
const config = require('../config');
const logger = require('../utils/logger');

let db = null;
let SQL = null;

// Ensure data directory exists
const dbDir = path.dirname(config.DB_PATH);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

function persistToDisk() {
  if (!db) return;
  try {
    const binaryArray = db.export();
    const buffer = Buffer.from(binaryArray);
    fs.writeFileSync(config.DB_PATH, buffer);
  } catch (err) {
    logger.error('Failed to persist database to disk:', err.message);
  }
}

async function initDatabase() {
  if (db) return db;

  SQL = await initSqlJs();

  if (fs.existsSync(config.DB_PATH)) {
    try {
      const fileBuffer = fs.readFileSync(config.DB_PATH);
      db = new SQL.Database(fileBuffer);
      logger.info('Loaded existing SQLite database from disk:', config.DB_PATH);
    } catch (err) {
      logger.warn('Corrupted database file detected. Initializing fresh database.', err.message);
      db = new SQL.Database();
    }
  } else {
    db = new SQL.Database();
    logger.info('Created fresh SQLite database in memory');
  }

  // Execute schema
  const schemaPath = path.join(__dirname, 'schema.sql');
  const schemaSql = fs.readFileSync(schemaPath, 'utf8');
  db.exec(schemaSql);
  persistToDisk();

  return db;
}

/**
 * Parameter binding helper for sql.js
 */
function prepareParams(params) {
  if (!params) return [];
  if (Array.isArray(params)) return params;
  if (typeof params === 'object') return params;
  return [params];
}

/**
 * Execute query returning all rows as array of objects
 */
function all(query, params = []) {
  if (!db) throw new Error('Database not initialized');
  const stmt = db.prepare(query);
  try {
    stmt.bind(prepareParams(params));
    const results = [];
    while (stmt.step()) {
      results.push(stmt.getAsObject());
    }
    return results;
  } finally {
    stmt.free();
  }
}

/**
 * Execute query returning the first matching row as an object
 */
function get(query, params = []) {
  if (!db) throw new Error('Database not initialized');
  const stmt = db.prepare(query);
  try {
    stmt.bind(prepareParams(params));
    if (stmt.step()) {
      return stmt.getAsObject();
    }
    return null;
  } finally {
    stmt.free();
  }
}

/**
 * Execute INSERT/UPDATE/DELETE query
 */
function run(query, params = []) {
  if (!db) throw new Error('Database not initialized');
  const stmt = db.prepare(query);
  try {
    stmt.bind(prepareParams(params));
    stmt.step();
  } finally {
    stmt.free();
  }

  const lastIdRes = db.exec('SELECT last_insert_rowid() AS id;');
  const changesRes = db.exec('SELECT changes() AS changed;');

  const lastInsertRowid = lastIdRes.length && lastIdRes[0].values.length ? lastIdRes[0].values[0][0] : 0;
  const changes = changesRes.length && changesRes[0].values.length ? changesRes[0].values[0][0] : 0;

  persistToDisk();
  return { lastInsertRowid, changes };
}

/**
 * Execute multi-statement raw SQL
 */
function exec(query) {
  if (!db) throw new Error('Database not initialized');
  db.exec(query);
  persistToDisk();
}

module.exports = {
  initDatabase,
  all,
  get,
  run,
  exec,
  persistToDisk,
  getDbInstance: () => db
};
