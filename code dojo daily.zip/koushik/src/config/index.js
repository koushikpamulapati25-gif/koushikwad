const path = require('path');

module.exports = {
  PORT: process.env.PORT || 3000,
  NODE_ENV: process.env.NODE_ENV || 'development',
  JWT_SECRET: process.env.JWT_SECRET || 'codedojo_super_secret_jwt_key_2026_secure',
  JWT_EXPIRES_IN: '24h',
  DB_PATH: path.join(__dirname, '..', '..', 'data', 'codedojo.sqlite'),
  EXECUTION_TIMEOUT_MS: 3000,
  RATE_LIMIT_WINDOW_MS: 15 * 60 * 1000,
  RATE_LIMIT_MAX_REQUESTS: 100,
  SUBMISSION_RATE_LIMIT_MAX: 30,
  TEAM_MIN_MEMBERS: 1,
  TEAM_MAX_MEMBERS: 4,
  POINTS_PER_EASY: 20,
  POINTS_PER_MEDIUM: 50,
  POINTS_PER_HARD: 100,
  STREAK_BONUS_PER_DAY: 15,
  CONTEST_MULTIPLIER: 1.5
};
