const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../database/db');
const config = require('../config');
const { getUserScoreAndSolves } = require('../services/scoringService');

function generateToken(user) {
  return jwt.sign(
    { id: user.id, username: user.username, email: user.email, role: user.role },
    config.JWT_SECRET,
    { expiresIn: config.JWT_EXPIRES_IN }
  );
}

function register(req, res) {
  const { username, email, password, avatar } = req.body;

  const existingUser = db.get('SELECT id FROM users WHERE username = ? OR email = ?', [username, email]);
  if (existingUser) {
    return res.status(409).json({
      success: false,
      error: 'Username or email already in use.'
    });
  }

  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(password, salt);

  const { lastInsertRowid: userId } = db.run(
    'INSERT INTO users (username, email, password_hash, avatar, role) VALUES (?, ?, ?, ?, ?)',
    [username, email, passwordHash, avatar || 'ninja-blue', 'student']
  );

  const user = { id: userId, username, email, role: 'student', avatar: avatar || 'ninja-blue' };
  const token = generateToken(user);

  res.status(201).json({
    success: true,
    message: 'User registered successfully.',
    token,
    user
  });
}

function login(req, res) {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({
      success: false,
      error: 'Username and password are required.'
    });
  }

  const user = db.get('SELECT * FROM users WHERE username = ? OR email = ?', [username, username]);
  if (!user) {
    return res.status(401).json({
      success: false,
      error: 'Invalid credentials.'
    });
  }

  const isMatch = bcrypt.compareSync(password, user.password_hash);
  if (!isMatch) {
    return res.status(401).json({
      success: false,
      error: 'Invalid credentials.'
    });
  }

  const safeUser = { id: user.id, username: user.username, email: user.email, role: user.role, avatar: user.avatar };
  const token = generateToken(safeUser);

  res.json({
    success: true,
    message: 'Authentication successful.',
    token,
    user: safeUser
  });
}

function getProfile(req, res) {
  const userId = req.user.id;
  const user = db.get('SELECT id, username, email, avatar, role, created_at FROM users WHERE id = ?', [userId]);

  if (!user) {
    return res.status(404).json({ success: false, error: 'User not found.' });
  }

  const stats = getUserScoreAndSolves(userId);

  // Check team membership
  const teamMember = db.get(
    `SELECT t.id, t.name, t.avatar, t.invite_code, tm.role as member_role
     FROM team_members tm
     JOIN teams t ON tm.team_id = t.id
     WHERE tm.user_id = ?`,
    [userId]
  );

  res.json({
    success: true,
    user: {
      ...user,
      stats,
      team: teamMember || null
    }
  });
}

module.exports = {
  register,
  login,
  getProfile
};
