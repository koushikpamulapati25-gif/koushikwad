const db = require('../database/db');
const { runTestCases } = require('../services/codeRunnerService');
const { getActiveContest, getProblemBasePoints, calculateUserStreak, getUserScoreAndSolves } = require('../services/scoringService');

/**
 * Run code against public sample test cases without persisting a submission
 */
async function runSampleTests(req, res) {
  const { problemId, code, language } = req.body;

  const problem = db.get('SELECT * FROM problems WHERE id = ?', [problemId]);
  if (!problem) {
    return res.status(404).json({ success: false, error: 'Problem not found.' });
  }

  const sampleTestCases = db.all(
    'SELECT * FROM test_cases WHERE problem_id = ? AND is_hidden = 0 ORDER BY order_num ASC',
    [problemId]
  );

  if (!sampleTestCases.length) {
    return res.status(400).json({ success: false, error: 'No test cases configured for this problem.' });
  }

  const result = await runTestCases(code, sampleTestCases);

  res.json({
    success: true,
    runType: 'sample_run',
    result
  });
}

/**
 * Submit code for full evaluation against ALL test cases (public + hidden)
 */
async function submitCode(req, res) {
  const userId = req.user.id;
  const { problemId, code, language } = req.body;

  const problem = db.get('SELECT * FROM problems WHERE id = ?', [problemId]);
  if (!problem) {
    return res.status(404).json({ success: false, error: 'Problem not found.' });
  }

  // Retrieve user's team if any
  const teamMember = db.get('SELECT team_id FROM team_members WHERE user_id = ?', [userId]);
  const teamId = teamMember ? teamMember.team_id : null;

  // Retrieve ALL test cases (both public and hidden)
  const allTestCases = db.all(
    'SELECT * FROM test_cases WHERE problem_id = ? ORDER BY order_num ASC',
    [problemId]
  );

  if (!allTestCases.length) {
    return res.status(400).json({ success: false, error: 'No test cases available for evaluation.' });
  }

  // Execute in isolated sandbox
  const evalResult = await runTestCases(code, allTestCases);

  // Record submission in database
  const { lastInsertRowid: submissionId } = db.run(
    `INSERT INTO submissions 
     (problem_id, user_id, team_id, language, code, status, execution_time_ms, passed_count, total_count, error_message)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      problemId,
      userId,
      teamId,
      language || 'javascript',
      code,
      evalResult.verdict,
      evalResult.totalExecutionTimeMs,
      evalResult.passedCount,
      evalResult.totalCount,
      evalResult.errorMessage || null
    ]
  );

  let pointsAwarded = 0;
  let isFirstAcceptedSolve = false;
  let contestMultiplier = 1.0;

  // If passed all test cases, process scoring and anti-duplication
  if (evalResult.verdict === 'Accepted') {
    // Check if user already had an accepted submission for this problem prior to this one
    const priorAccept = db.get(
      'SELECT id FROM submissions WHERE problem_id = ? AND user_id = ? AND status = "Accepted" AND id != ? LIMIT 1',
      [problemId, userId, submissionId]
    );

    if (!priorAccept) {
      isFirstAcceptedSolve = true;
      const basePoints = getProblemBasePoints(problem.difficulty);
      const activeContest = getActiveContest();
      if (activeContest) {
        contestMultiplier = activeContest.multiplier;
      }
      pointsAwarded = Math.round(basePoints * contestMultiplier);

      const todayStr = new Date().toISOString().split('T')[0];
      db.run(
        `INSERT INTO activity_log (user_id, problem_id, activity_date, points_awarded)
         VALUES (?, ?, ?, ?)`,
        [userId, problemId, todayStr, pointsAwarded]
      );
    }
  }

  const updatedStats = getUserScoreAndSolves(userId);

  res.json({
    success: true,
    submissionId,
    verdict: evalResult.verdict,
    passedCount: evalResult.passedCount,
    totalCount: evalResult.totalCount,
    executionTimeMs: evalResult.totalExecutionTimeMs,
    errorMessage: evalResult.errorMessage,
    testCaseResults: evalResult.testCaseResults,
    scoring: {
      isFirstAcceptedSolve,
      pointsAwarded,
      contestMultiplier,
      userTotalScore: updatedStats.totalScore,
      userStreak: updatedStats.streak
    }
  });
}

/**
 * Paginated submissions history
 */
function getSubmissions(req, res) {
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(50, Math.max(1, parseInt(req.query.limit) || 15));
  const offset = (page - 1) * limit;

  const { problemId, userId, teamId, status } = req.query;

  const conditions = [];
  const params = [];

  if (problemId) {
    conditions.push('s.problem_id = ?');
    params.push(problemId);
  }

  if (userId) {
    conditions.push('s.user_id = ?');
    params.push(userId);
  }

  if (teamId) {
    conditions.push('s.team_id = ?');
    params.push(teamId);
  }

  if (status && status !== 'All') {
    conditions.push('s.status = ?');
    params.push(status);
  }

  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const totalRow = db.get(`SELECT COUNT(*) as total FROM submissions s ${whereClause}`, params);
  const total = totalRow ? totalRow.total : 0;
  const totalPages = Math.ceil(total / limit);

  const queryParams = [...params, limit, offset];
  const submissions = db.all(
    `SELECT s.id, s.problem_id, p.title as problem_title, p.difficulty,
            s.user_id, u.username, s.team_id, t.name as team_name,
            s.language, s.status, s.execution_time_ms, s.passed_count, 
            s.total_count, s.submitted_at
     FROM submissions s
     JOIN problems p ON s.problem_id = p.id
     JOIN users u ON s.user_id = u.id
     LEFT JOIN teams t ON s.team_id = t.id
     ${whereClause}
     ORDER BY s.id DESC
     LIMIT ? OFFSET ?`,
    queryParams
  );

  res.json({
    success: true,
    pagination: {
      page,
      limit,
      total,
      totalPages
    },
    submissions
  });
}

/**
 * Returns GitHub-style daily activity heatmap data for user
 */
function getUserActivityHeatmap(req, res) {
  const targetUserId = parseInt(req.params.userId) || (req.user ? req.user.id : null);
  if (!targetUserId) {
    return res.status(400).json({ success: false, error: 'User ID is required.' });
  }

  const activity = db.all(
    `SELECT activity_date, COUNT(*) as solve_count, SUM(points_awarded) as points
     FROM activity_log
     WHERE user_id = ?
     GROUP BY activity_date
     ORDER BY activity_date ASC`,
    [targetUserId]
  );

  const streak = calculateUserStreak(targetUserId);

  res.json({
    success: true,
    userId: targetUserId,
    currentStreak: streak,
    activity
  });
}

module.exports = {
  runSampleTests,
  submitCode,
  getSubmissions,
  getUserActivityHeatmap
};
