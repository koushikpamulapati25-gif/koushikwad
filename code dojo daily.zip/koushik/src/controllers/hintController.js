const { getProblemHintsForUser } = require('../services/hintService');

function getProblemHints(req, res) {
  const problemId = parseInt(req.params.problemId);
  const userId = req.user ? req.user.id : 0;

  if (!problemId || isNaN(problemId)) {
    return res.status(400).json({ success: false, error: 'A valid problemId is required.' });
  }

  const result = getProblemHintsForUser(problemId, userId);

  res.json({
    success: true,
    data: result
  });
}

module.exports = {
  getProblemHints
};
