const db = require('../database/db');

function getDailyProblem(req, res) {
  const today = new Date().toISOString().split('T')[0];

  // Try to find problem assigned to today
  let problem = db.get('SELECT * FROM problems WHERE daily_date = ? LIMIT 1', [today]);

  // Fallback to the latest problem if no problem is specifically tagged for today
  if (!problem) {
    problem = db.get('SELECT * FROM problems ORDER BY id ASC LIMIT 1');
  }

  if (!problem) {
    return res.status(404).json({ success: false, error: 'No daily problem available.' });
  }

  const testCases = db.all(
    'SELECT id, input, expected_output, is_hidden, explanation FROM test_cases WHERE problem_id = ? AND is_hidden = 0 ORDER BY order_num ASC',
    [problem.id]
  );

  let isSolved = false;
  if (req.user) {
    const solved = db.get(
      'SELECT id FROM submissions WHERE problem_id = ? AND user_id = ? AND status = "Accepted" LIMIT 1',
      [problem.id, req.user.id]
    );
    isSolved = !!solved;
  }

  res.json({
    success: true,
    problem: {
      id: problem.id,
      slug: problem.slug,
      title: problem.title,
      difficulty: problem.difficulty,
      domain_tag: problem.domain_tag,
      description: problem.description,
      examples: JSON.parse(problem.examples_json || '[]'),
      constraints: JSON.parse(problem.constraints_json || '[]'),
      starterCode: JSON.parse(problem.starter_code_json || '{}'),
      dailyDate: problem.daily_date,
      sampleTestCases: testCases,
      isSolved
    }
  });
}

function getProblems(req, res) {
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(50, Math.max(1, parseInt(req.query.limit) || 12));
  const offset = (page - 1) * limit;

  const { difficulty, domain, search } = req.query;

  const conditions = [];
  const params = [];

  if (difficulty && difficulty !== 'All') {
    conditions.push('difficulty = ?');
    params.push(difficulty);
  }

  if (domain && domain !== 'All') {
    conditions.push('domain_tag = ?');
    params.push(domain);
  }

  if (search) {
    conditions.push('(title LIKE ? OR description LIKE ?)');
    params.push(`%${search}%`);
    params.push(`%${search}%`);
  }

  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const totalRow = db.get(`SELECT COUNT(*) as total FROM problems ${whereClause}`, params);
  const total = totalRow ? totalRow.total : 0;
  const totalPages = Math.ceil(total / limit);

  const queryParams = [...params, limit, offset];
  const problems = db.all(
    `SELECT id, slug, title, difficulty, domain_tag, daily_date, created_at 
     FROM problems 
     ${whereClause} 
     ORDER BY id ASC 
     LIMIT ? OFFSET ?`,
    queryParams
  );

  // If user is authenticated, determine solve status for each problem
  let userSolvedIds = new Set();
  if (req.user) {
    const solvedRows = db.all(
      'SELECT DISTINCT problem_id FROM submissions WHERE user_id = ? AND status = "Accepted"',
      [req.user.id]
    );
    userSolvedIds = new Set(solvedRows.map(r => r.problem_id));
  }

  const enriched = problems.map(p => ({
    ...p,
    isSolved: userSolvedIds.has(p.id)
  }));

  res.json({
    success: true,
    pagination: {
      page,
      limit,
      total,
      totalPages
    },
    problems: enriched
  });
}

function getProblemById(req, res) {
  const problemId = parseInt(req.params.id);
  const problem = db.get('SELECT * FROM problems WHERE id = ?', [problemId]);

  if (!problem) {
    return res.status(404).json({ success: false, error: 'Problem not found.' });
  }

  const publicTestCases = db.all(
    'SELECT id, input, expected_output, is_hidden, explanation FROM test_cases WHERE problem_id = ? AND is_hidden = 0 ORDER BY order_num ASC',
    [problem.id]
  );

  let isSolved = false;
  if (req.user) {
    const solved = db.get(
      'SELECT id FROM submissions WHERE problem_id = ? AND user_id = ? AND status = "Accepted" LIMIT 1',
      [problem.id, req.user.id]
    );
    isSolved = !!solved;
  }

  res.json({
    success: true,
    problem: {
      id: problem.id,
      slug: problem.slug,
      title: problem.title,
      difficulty: problem.difficulty,
      domain_tag: problem.domain_tag,
      description: problem.description,
      examples: JSON.parse(problem.examples_json || '[]'),
      constraints: JSON.parse(problem.constraints_json || '[]'),
      starterCode: JSON.parse(problem.starter_code_json || '{}'),
      dailyDate: problem.daily_date,
      sampleTestCases: publicTestCases,
      isSolved
    }
  });
}

function getProblemFilterMetadata(req, res) {
  const domains = db.all('SELECT DISTINCT domain_tag FROM problems ORDER BY domain_tag ASC');
  const difficulties = db.all('SELECT difficulty, COUNT(*) as count FROM problems GROUP BY difficulty');
  const total = db.get('SELECT COUNT(*) as total FROM problems');

  res.json({
    success: true,
    domains: domains.map(d => d.domain_tag),
    difficulties: difficulties.map(d => ({ difficulty: d.difficulty, count: d.count })),
    totalProblems: total ? total.total : 0
  });
}

module.exports = {
  getDailyProblem,
  getProblems,
  getProblemById,
  getProblemFilterMetadata
};
