const { analyzeProblemSubmissions } = require('../services/plagiarismService');

function checkPlagiarism(req, res) {
  const problemId = req.query.problemId ? parseInt(req.query.problemId) : null;
  const threshold = req.query.threshold ? parseInt(req.query.threshold) : 60;

  const result = analyzeProblemSubmissions(problemId, threshold);

  res.json({
    success: true,
    data: result
  });
}

module.exports = {
  checkPlagiarism
};
