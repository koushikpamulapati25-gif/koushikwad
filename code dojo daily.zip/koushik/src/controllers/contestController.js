const db = require('../database/db');
const { getActiveContest, getTeamLeaderboard } = require('../services/scoringService');

function getActiveContestDetails(req, res) {
  const activeContest = getActiveContest();

  if (!activeContest) {
    return res.json({
      success: true,
      hasActiveContest: false,
      contest: null
    });
  }

  const now = new Date();
  const end = new Date(activeContest.end_time);
  const remainingSeconds = Math.max(0, Math.floor((end.getTime() - now.getTime()) / 1000));

  res.json({
    success: true,
    hasActiveContest: true,
    contest: {
      id: activeContest.id,
      title: activeContest.title,
      description: activeContest.description,
      startTime: activeContest.start_time,
      endTime: activeContest.end_time,
      multiplier: activeContest.multiplier,
      remainingSeconds,
      isExpired: remainingSeconds <= 0
    }
  });
}

function getLeaderboard(req, res) {
  const data = getTeamLeaderboard();
  res.json({
    success: true,
    timestamp: new Date().toISOString(),
    ...data
  });
}

module.exports = {
  getActiveContestDetails,
  getLeaderboard
};
