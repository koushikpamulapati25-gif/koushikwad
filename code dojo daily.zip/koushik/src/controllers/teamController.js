const db = require('../database/db');
const config = require('../config');
const { getUserScoreAndSolves } = require('../services/scoringService');

function generateInviteCode(teamName) {
  const prefix = teamName.replace(/[^a-zA-Z0-9]/g, '').substring(0, 5).toUpperCase();
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `SQUAD-${prefix}-${rand}`;
}

function createTeam(req, res) {
  const userId = req.user.id;
  const { name, avatar } = req.body;

  // Check if user is already in a team
  const existingMembership = db.get('SELECT * FROM team_members WHERE user_id = ?', [userId]);
  if (existingMembership) {
    return res.status(400).json({
      success: false,
      error: 'You are already a member of a squad. Please leave your current squad before creating a new one.'
    });
  }

  // Check name uniqueness
  const existingTeam = db.get('SELECT id FROM teams WHERE name = ?', [name]);
  if (existingTeam) {
    return res.status(409).json({
      success: false,
      error: 'A squad with this name already exists. Please choose a unique name.'
    });
  }

  const inviteCode = generateInviteCode(name);

  const { lastInsertRowid: teamId } = db.run(
    'INSERT INTO teams (name, avatar, invite_code, created_by) VALUES (?, ?, ?, ?)',
    [name, avatar || 'squad-tiger', inviteCode, userId]
  );

  // Add creator as leader
  db.run(
    'INSERT INTO team_members (team_id, user_id, role) VALUES (?, ?, ?)',
    [teamId, userId, 'leader']
  );

  res.status(201).json({
    success: true,
    message: 'Squad successfully created.',
    team: {
      id: teamId,
      name,
      avatar: avatar || 'squad-tiger',
      inviteCode,
      role: 'leader',
      memberCount: 1
    }
  });
}

function joinTeam(req, res) {
  const userId = req.user.id;
  const { inviteCode } = req.body;

  if (!inviteCode) {
    return res.status(400).json({
      success: false,
      error: 'Invite code is required.'
    });
  }

  // Check if user is already in a team
  const existingMembership = db.get('SELECT * FROM team_members WHERE user_id = ?', [userId]);
  if (existingMembership) {
    return res.status(400).json({
      success: false,
      error: 'You are already a member of a squad. Please leave your current squad first.'
    });
  }

  const team = db.get('SELECT * FROM teams WHERE invite_code = ?', [inviteCode.trim()]);
  if (!team) {
    return res.status(404).json({
      success: false,
      error: 'Invalid squad invite code. No matching squad found.'
    });
  }

  // Enforce max 4 member roster limit
  const memberCountRow = db.get('SELECT COUNT(*) as count FROM team_members WHERE team_id = ?', [team.id]);
  const currentCount = memberCountRow ? memberCountRow.count : 0;

  if (currentCount >= config.TEAM_MAX_MEMBERS) {
    return res.status(400).json({
      success: false,
      error: `This squad has reached its maximum roster capacity of ${config.TEAM_MAX_MEMBERS} members.`
    });
  }

  db.run(
    'INSERT INTO team_members (team_id, user_id, role) VALUES (?, ?, ?)',
    [team.id, userId, 'member']
  );

  res.json({
    success: true,
    message: `Successfully joined ${team.name}!`,
    team: {
      id: team.id,
      name: team.name,
      avatar: team.avatar,
      role: 'member',
      memberCount: currentCount + 1
    }
  });
}

function leaveTeam(req, res) {
  const userId = req.user.id;

  const membership = db.get('SELECT * FROM team_members WHERE user_id = ?', [userId]);
  if (!membership) {
    return res.status(400).json({
      success: false,
      error: 'You are not currently in any squad.'
    });
  }

  db.run('DELETE FROM team_members WHERE team_id = ? AND user_id = ?', [membership.team_id, userId]);

  // If squad now has 0 members, delete squad
  const remaining = db.get('SELECT COUNT(*) as count FROM team_members WHERE team_id = ?', [membership.team_id]);
  if (remaining && remaining.count === 0) {
    db.run('DELETE FROM teams WHERE id = ?', [membership.team_id]);
  }

  res.json({
    success: true,
    message: 'You have left the squad.'
  });
}

function getTeamDetails(req, res) {
  const teamId = parseInt(req.params.id);
  const team = db.get('SELECT * FROM teams WHERE id = ?', [teamId]);

  if (!team) {
    return res.status(404).json({ success: false, error: 'Squad not found.' });
  }

  const members = db.all(
    `SELECT u.id, u.username, u.avatar, tm.role, tm.joined_at
     FROM team_members tm
     JOIN users u ON tm.user_id = u.id
     WHERE tm.team_id = ?`,
    [teamId]
  );

  const enrichedMembers = members.map(m => {
    const stats = getUserScoreAndSolves(m.id);
    return {
      ...m,
      solveCount: stats.solveCount,
      streak: stats.streak,
      score: stats.totalScore
    };
  });

  res.json({
    success: true,
    team: {
      id: team.id,
      name: team.name,
      avatar: team.avatar,
      inviteCode: team.invite_code,
      createdAt: team.created_at,
      memberCount: members.length,
      members: enrichedMembers
    }
  });
}

function listTeams(req, res) {
  const teams = db.all('SELECT * FROM teams ORDER BY id ASC');
  const enriched = teams.map(t => {
    const countRow = db.get('SELECT COUNT(*) as count FROM team_members WHERE team_id = ?', [t.id]);
    return {
      id: t.id,
      name: t.name,
      avatar: t.avatar,
      inviteCode: t.invite_code,
      memberCount: countRow ? countRow.count : 0,
      createdAt: t.created_at
    };
  });

  res.json({
    success: true,
    teams: enriched
  });
}

module.exports = {
  createTeam,
  joinTeam,
  leaveTeam,
  getTeamDetails,
  listTeams
};
